package pe.edu.upeu.sysventas;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.config.DatabaseConfig;
import pe.edu.upeu.sysventas.dto.CartLine;
import pe.edu.upeu.sysventas.dto.Payment;
import pe.edu.upeu.sysventas.dto.PurchaseLine;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.util.Passwords;

class RecepcionTest {
  @TempDir static Path home;
  private static AppContext app;

  @BeforeAll
  static void prepareDatabase() {
    System.setProperty("moda.home", home.toString());
    System.setProperty("moda.config", home.resolve("database.properties").toString());
    System.setProperty("moda.db.url", "jdbc:h2:mem:recepcion;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE");
    app = AppContext.getInstance();
  }

  @AfterEach
  void clearSession() {
    app.auth.logout();
  }

  @AfterAll
  static void closeDatabase() {
    DatabaseConfig.shutdown();
    for (String key : List.of("moda.home", "moda.config", "moda.db.url")) System.clearProperty(key);
  }

  @Test
  void personalPasswordsAndProfiles() {
    for (String[] account :
        new String[][] {{"admin", "ADM"}, {"vendedor", "VEN"}, {"almacen", "ALM"}}) {
      app.auth.login(account[0], "admin123");
      assertEquals(account[1], SessionManager.getInstance().getRole());
    }
    assertThrows(IllegalArgumentException.class, () -> app.auth.login("admin", "incorrecta"));
    assertThrows(IllegalArgumentException.class, () -> app.auth.login("", ""));
    assertThrows(IllegalArgumentException.class, () -> app.auth.login("cliente", "admin123"));
    assertNull(SessionManager.getInstance().getUserId());
  }

  @Test
  void passwordHashUsesRandomSaltAndRejectsIncorrectKeys() {
    String first = Passwords.hash("Demostracion21");
    String second = Passwords.hash("Demostracion21");
    assertTrue(first.startsWith("pbkdf2$210000$"));
    assertNotEquals(first, second);
    assertTrue(Passwords.verify("Demostracion21", first));
    assertTrue(Passwords.verify("Demostracion21", second));
    assertFalse(Passwords.verify("Demostracion22", first));
    assertFalse(Passwords.verify("Demostracion21", "dato-invalido"));
    assertThrows(IllegalArgumentException.class, () -> Passwords.hash("corta"));
  }

  @Test
  void warehouseReceiptUpdatesStockCostAndAudit() {
    app.auth.login("almacen", "admin123");
    long actor = SessionManager.getInstance().getUserId();
    long sku = firstId("variante", "id_variante");
    long supplier = firstId("proveedor", "id_proveedor");
    long before = stock(sku);
    long receipt = app.compras.buy(supplier, "F900", "001", LocalDate.now(),
        List.of(new PurchaseLine(sku, 3, new BigDecimal("25.50"))));

    assertEquals(before + 3, stock(sku));
    assertEquals(new BigDecimal("25.50"), app.db.query("SELECT costo FROM variante WHERE id_variante=?", sku).getFirst().get("costo"));
    assertEquals(new BigDecimal("76.50"), app.db.query("SELECT precio_total FROM compra WHERE id_compra=?", receipt).getFirst().get("precio_total"));
    assertEquals(3, number("SELECT cantidad FROM compra_detalle WHERE id_compra=?", receipt));
    assertEquals(1, number("SELECT COUNT(*) AS n FROM movimiento_stock WHERE tipo_movimiento='ENTRADA_COMPRA' AND referencia=? AND id_usuario=? AND cantidad=3", "COMPRA:" + receipt, actor));
    assertEquals(1, number("SELECT COUNT(*) AS n FROM auditoria WHERE entidad='compra' AND accion='CONFIRMAR' AND id_registro=? AND id_usuario=?", receipt, actor));
    assertFalse(app.reports.report("Compras por proveedor", LocalDate.now(), LocalDate.now(), null).isEmpty());
  }

  @Test
  void repeatedReceiptDoesNotDuplicateStock() {
    app.auth.login("admin", "admin123");
    long sku = firstId("variante", "id_variante");
    long supplier = firstId("proveedor", "id_proveedor");
    var lines = List.of(new PurchaseLine(sku, 2, new BigDecimal("14.00")));
    long before = stock(sku);
    app.compras.buy(supplier, "F900", "002", LocalDate.now(), lines);
    assertThrows(IllegalArgumentException.class,
        () -> app.compras.buy(supplier, "F900", "002", LocalDate.now(), lines));
    assertEquals(before + 2, stock(sku));
  }

  @Test
  void missingSecondSkuRollsBackFirstLineAndReceipt() {
    app.auth.login("admin", "admin123");
    long sku = firstId("variante", "id_variante");
    long supplier = firstId("proveedor", "id_proveedor");
    long before = stock(sku);
    long movements = number("SELECT COUNT(*) AS n FROM movimiento_stock");
    long lines = number("SELECT COUNT(*) AS n FROM compra_detalle");
    assertThrows(IllegalArgumentException.class,
        () -> app.compras.buy(supplier, "F900", "003", LocalDate.now(),
            List.of(new PurchaseLine(sku, 2, BigDecimal.TEN),
                new PurchaseLine(Long.MAX_VALUE, 1, BigDecimal.TEN))));
    assertEquals(before, stock(sku));
    assertEquals(movements, number("SELECT COUNT(*) AS n FROM movimiento_stock"));
    assertEquals(lines, number("SELECT COUNT(*) AS n FROM compra_detalle"));
    assertEquals(0, number("SELECT COUNT(*) AS n FROM compra WHERE serie='F900' AND num_doc='003'"));
  }

  @Test
  void salesProfileCannotReceiveProducts() {
    app.auth.login("vendedor", "admin123");
    long sku = firstId("variante", "id_variante");
    long supplier = firstId("proveedor", "id_proveedor");
    long before = stock(sku);
    assertThrows(SecurityException.class,
        () -> app.compras.buy(supplier, "F900", "004", LocalDate.now(),
            List.of(new PurchaseLine(sku, 1, BigDecimal.TEN))));
    assertEquals(before, stock(sku));
  }

  @Test
  void invalidReceiptAndLineFieldsFail() {
    app.auth.login("almacen", "admin123");
    var date = LocalDate.now();
    long sku = firstId("variante", "id_variante");
    long supplier = firstId("proveedor", "id_proveedor");
    var line = new PurchaseLine(sku, 2, BigDecimal.TEN);
    var lines = List.of(line);
    assertThrows(IllegalArgumentException.class, () -> new PurchaseLine(sku, -1, BigDecimal.TEN));
    assertThrows(IllegalArgumentException.class, () -> new PurchaseLine(sku, 0, BigDecimal.TEN));
    assertThrows(IllegalArgumentException.class, () -> new PurchaseLine(sku, 1, new BigDecimal("1.234")));
    assertThrows(IllegalArgumentException.class, () -> new PurchaseLine(sku, 1, new BigDecimal("-0.01")));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(0, "F900", "005", date, lines));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(supplier, " ", "005", date, lines));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(supplier, "F900", " ", date, lines));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(supplier, "F900", "005", date.plusDays(1), lines));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(supplier, "F900", "005", date, List.of()));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(supplier, "F900", "005", date, List.of(line, line)));
    assertThrows(IllegalArgumentException.class, () -> app.compras.buy(supplier, "F900", "005", date,
        List.of(new PurchaseLine(sku, 2, new BigDecimal("9999999999.99")))));
    assertEquals(0, number("SELECT COUNT(*) AS n FROM compra WHERE serie='F900' AND num_doc='005'"));
  }

  @Test
  void saleNeedsMatchingPaymentsAndProducesReceipt() {
    app.auth.login("vendedor", "admin123");
    long sku = number("SELECT MIN(id_variante) AS id FROM variante WHERE stock_actual > 1");
    long method = firstId("metodo_pago", "id_metodo_pago");
    var cart = List.of(new CartLine(sku, 1));
    BigDecimal total = app.ventas.quote(cart, null, BigDecimal.ZERO).getTotal();
    long before = stock(sku);
    assertThrows(IllegalArgumentException.class, () -> app.ventas.sell(
        cart, null, List.of(new Payment(method, total.add(BigDecimal.ONE), "")), BigDecimal.ZERO));
    assertEquals(before, stock(sku));

    long sale = app.ventas.sell(
        cart, null, List.of(new Payment(method, total, "")), BigDecimal.ZERO);
    assertEquals(before - 1, stock(sku));
    assertEquals(sale, app.reports.comprobante(sale).getVenta().getIdVenta());
    assertEquals(total, app.db.query("SELECT monto FROM venta_pago WHERE id_venta=?", sale)
        .getFirst().get("monto"));
  }

  private static long stock(long id) {
    return number("SELECT stock_actual FROM variante WHERE id_variante=?", id);
  }

  private static long firstId(String table, String key) {
    return number("SELECT MIN(" + key + ") AS id FROM " + table);
  }

  private static long number(String sql, Object... args) {
    return ((Number) app.db.query(sql, args).getFirst().values().iterator().next()).longValue();
  }
}
