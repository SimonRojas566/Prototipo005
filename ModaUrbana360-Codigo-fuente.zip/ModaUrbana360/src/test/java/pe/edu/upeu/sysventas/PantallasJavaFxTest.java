package pe.edu.upeu.sysventas;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.stage.Window;
import javax.imageio.ImageIO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.io.TempDir;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.config.DatabaseConfig;
import pe.edu.upeu.sysventas.dto.Choice;

@EnabledIfSystemProperty(named = "moda.fx.tests", matches = "true")
class PantallasJavaFxTest {
  @TempDir Path home;

  @Test
  void employeeMenusAndReceiptForm() throws Exception {
    System.setProperty("moda.home", home.toString());
    System.setProperty("moda.db.url", "jdbc:h2:mem:interfaz;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE");
    FutureTask<Void> flow = new FutureTask<>(() -> {
      SysVentas application = new SysVentas();
      Stage stage = new Stage();
      try {
        application.start(stage);
        stage.setWidth(1250);
        stage.setHeight(820);
        assertNotNull(stage.getScene().lookup("#usuario"));
        capture(stage, "acceso");

        signIn(stage, "vendedor");
        assertTrue(menuNames(stage).contains("Venta"));
        assertFalse(menuNames(stage).contains("Compras"));
        openMenu(stage, "Venta");
        assertNotNull(stage.getScene().lookup("#cartTable"));

        SysVentas.login();
        signIn(stage, "admin");
        assertTrue(menuNames(stage).containsAll(List.of("Venta", "Compras", "Administración")));
        createBrand(stage);

        SysVentas.login();
        signIn(stage, "almacen");
        assertFalse(menuNames(stage).contains("Venta"));
        openMenu(stage, "Compras");
        stage.setWidth(1310);
        stage.setHeight(820);
        Parent form = stage.getScene().getRoot();
        selectFirst(form, "#supplier");
        Choice sku = (Choice) selectFirst(form, "#variant");
        ((TextField) form.lookup("#document")).setText("PRUEBA-FX-001");
        TextField quantity = (TextField) form.lookup("#quantity");
        TextField cost = (TextField) form.lookup("#cost");
        quantity.setText("2");
        cost.setText("25,50");
        Button add = button(form, "Agregar al detalle");
        add.fire();
        TableView<?> detail = (TableView<?>) form.lookup("#table");
        assertEquals(1, detail.getItems().size());
        assertEquals(2, ((Map<?, ?>) detail.getItems().getFirst()).get("cantidad"));

        List<String> messages = new ArrayList<>();
        quantity.setText("-1");
        Platform.runLater(() -> closeDialog(ButtonType.OK, messages));
        add.fire();
        assertTrue(messages.getLast().contains("cantidad entera mayor que cero"));
        assertEquals(2, ((Map<?, ?>) detail.getItems().getFirst()).get("cantidad"));
        quantity.setText("1");
        cost.setText("25,501");
        Platform.runLater(() -> closeDialog(ButtonType.OK, messages));
        add.fire();
        assertTrue(messages.getLast().contains("hasta dos decimales"));
        assertEquals(2, ((Map<?, ?>) detail.getItems().getFirst()).get("cantidad"));
        cost.setText("25,50");
        capture(stage, "recepcion");

        long before = stock(sku.getId());
        Button confirm = button(form, "Confirmar recepción");
        Platform.runLater(() -> closeDialog(ButtonType.CANCEL, messages));
        confirm.fire();
        assertEquals(before, stock(sku.getId()));
        assertEquals(1, detail.getItems().size());

        Platform.runLater(() -> {
          closeDialog(ButtonType.OK, messages);
          Platform.runLater(() -> closeDialog(ButtonType.OK, messages));
        });
        confirm.fire();
        assertTrue(messages.getLast().contains("El inventario se actualizó"));
        assertEquals(before + 2, stock(sku.getId()));
        assertTrue(detail.getItems().isEmpty());

        openMenu(stage, "Consultas");
        ComboBox<?> reports = (ComboBox<?>) stage.getScene().lookup("#report");
        reports.getSelectionModel().select(reports.getItems().indexOf("Movimientos de inventario"));
        TableView<?> results = (TableView<?>) stage.getScene().lookup("#table");
        assertTrue(results.getItems().stream()
            .anyMatch(row -> ((Map<?, ?>) row).containsValue("ENTRADA_COMPRA")));
        return null;
      } finally {
        stage.close();
        application.stop();
      }
    });
    try {
      Platform.startup(flow);
      flow.get(25, TimeUnit.SECONDS);
    } finally {
      Platform.exit();
      System.clearProperty("moda.db.url");
      System.clearProperty("moda.home");
      DatabaseConfig.shutdown();
    }
  }

  private static void signIn(Stage stage, String username) {
    Parent root = stage.getScene().getRoot();
    ((TextField) root.lookup("#usuario")).setText(username);
    ((PasswordField) root.lookup("#clave")).setText("admin123");
    button(root, "Iniciar sesión").fire();
    assertNotNull(stage.getScene().lookup("#navigation"));
  }

  private static void createBrand(Stage stage) {
    openMenu(stage, "Administración");
    Parent root = stage.getScene().getRoot();
    ComboBox<?> entity = (ComboBox<?>) root.lookup("#entity");
    entity.getSelectionModel().select(entity.getItems().indexOf("marca"));
    List<String> messages = new ArrayList<>();
    Platform.runLater(() -> {
      DialogPane dialog = currentDialog();
      dialog.applyCss();
      TextField name = dialog.lookupAll(".text-field").stream()
          .filter(TextField.class::isInstance).map(TextField.class::cast).findFirst().orElseThrow();
      name.setText("Marca de prueba JavaFX");
      ((Button) dialog.lookupButton(ButtonType.OK)).fire();
      Platform.runLater(() -> closeDialog(ButtonType.OK, messages));
    });
    button(root, "Nuevo").fire();
    assertEquals(List.of("Registro creado correctamente."), messages);
    TableView<?> records = (TableView<?>) root.lookup("#table");
    assertTrue(records.getItems().stream()
        .anyMatch(row -> ((Map<?, ?>) row).containsValue("Marca de prueba JavaFX")));
  }

  private static List<String> menuNames(Stage stage) {
    return ((MenuBar) stage.getScene().lookup("#navigation")).getMenus().stream()
        .map(Menu::getText).toList();
  }

  private static void openMenu(Stage stage, String title) {
    ((MenuBar) stage.getScene().lookup("#navigation")).getMenus().stream()
        .filter(menu -> menu.getText().equals(title)).findFirst().orElseThrow()
        .getItems().getFirst().fire();
    stage.getScene().getRoot().applyCss();
    stage.getScene().getRoot().layout();
  }

  private static Object selectFirst(Parent root, String id) {
    ComboBox<?> combo = (ComboBox<?>) root.lookup(id);
    combo.getSelectionModel().selectFirst();
    return combo.getValue();
  }

  private static Button button(Parent root, String label) {
    return root.lookupAll(".button").stream().filter(Button.class::isInstance).map(Button.class::cast)
        .filter(button -> button.getText().contains(label)).findFirst().orElseThrow();
  }

  private static void closeDialog(ButtonType choice, List<String> messages) {
    DialogPane dialog = currentDialog();
    messages.add(dialog.getContentText());
    ((Button) dialog.lookupButton(choice)).fire();
  }

  private static DialogPane currentDialog() {
    return List.copyOf(Window.getWindows()).stream()
        .filter(Window::isShowing).map(window -> window.getScene().getRoot())
        .filter(DialogPane.class::isInstance).map(DialogPane.class::cast).findFirst().orElseThrow();
  }

  private static long stock(long sku) {
    return ((Number) AppContext.getInstance().db.query(
        "SELECT stock_actual FROM variante WHERE id_variante=?", sku).getFirst().get("stock_actual"))
        .longValue();
  }

  private static void capture(Stage stage, String name) throws Exception {
    String out = System.getProperty("moda.fx.evidence");
    if (out != null) {
      Parent root = stage.getScene().getRoot();
      root.applyCss();
      root.layout();
      ImageIO.write(SwingFXUtils.fromFXImage(root.snapshot(null, null), null), "png",
          Path.of(out, name + ".png").toFile());
    }
  }
}
