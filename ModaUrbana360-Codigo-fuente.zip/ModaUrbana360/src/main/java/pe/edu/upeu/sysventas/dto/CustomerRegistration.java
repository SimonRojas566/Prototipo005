package pe.edu.upeu.sysventas.dto;

/** Datos de identificación de un cliente registrado durante el cobro, sin cuenta de acceso. */
public record CustomerRegistration(String nombres, String tipoDocumento, String documento) {}
