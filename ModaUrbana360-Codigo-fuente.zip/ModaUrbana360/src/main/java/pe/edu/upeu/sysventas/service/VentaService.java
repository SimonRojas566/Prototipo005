package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;

/** Contrato de negocio para venta. */
public interface VentaService {
  Quote quote(List<CartLine> cart, Long client, BigDecimal manual);

  default long sell(List<CartLine> cart, Long client, List<Payment> payments, BigDecimal manual) {
    return sell(cart, client, payments, manual, TipoDocumento.BOLETA);
  }

  long sell(
      List<CartLine> cart,
      Long client,
      List<Payment> payments,
      BigDecimal manual,
      TipoDocumento documento);

  default long sell(
      List<CartLine> cart,
      Long client,
      List<Payment> payments,
      BigDecimal manual,
      TipoDocumento documento,
      CustomerRegistration newCustomer) {
    if (newCustomer != null)
      throw new UnsupportedOperationException("El registro de cliente no está disponible.");
    return sell(cart, client, payments, manual, documento);
  }

  void cancel(long sale, String reason);
}
