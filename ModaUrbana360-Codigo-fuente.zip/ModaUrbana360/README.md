# Moda Urbana 360

Sistema interno de escritorio para registrar ventas, recibir mercadería y consultar el inventario de una tienda de ropa. Usa Java 21, JavaFX 21, JDBC y H2 embebido.

## Abrir en Windows

1. Instala Java 21 de 64 bits o usa una instalación existente. Comprueba la versión con `java -version`.
2. Extrae todo el paquete de Windows en una carpeta donde puedas guardar archivos.
3. Ejecuta `Iniciar Moda Urbana.cmd` o abre esa carpeta en la terminal y ejecuta `java -jar ModaUrbana360-2.1.0.jar`. El JAR necesita la carpeta `lib` que viene a su lado.

En la primera ejecución se prepara una base local en `data/moda_urbana.mv.db` con datos de demostración.

| Perfil | Usuario de demostración | Contraseña de demostración |
| --- | --- | --- |
| Administrador | `admin` | `admin123` |
| Vendedor | `vendedor` | `admin123` |
| Almacenero | `almacen` | `admin123` |

Si ya tienes operaciones, cierra ambas versiones y conserva un respaldo del archivo H2. Copia `moda_urbana.mv.db` en la carpeta `data` de la versión nueva antes de iniciarla. Para el uso de tienda, configura cuentas y contraseñas individuales desde **Administración**.

## Compilar y probar

Con JDK 21 y Maven, abre la raíz del repositorio y ejecuta:

```powershell
mvn clean package
mvn "-Dmoda.fx.tests=true" test
```

El primer comando incluye las pruebas de servicios y base de datos. El segundo ejecuta también la prueba con ventanas JavaFX y requiere un escritorio gráfico. `mvnw.cmd` se puede usar en lugar de `mvn`.

El build genera `target/ModaUrbana360-2.1.0.jar` y `target/lib/`. Para arrancar desde la raíz del proyecto, usa `java -jar target/ModaUrbana360-2.1.0.jar`. El modo `--check` verifica las tablas y los tres accesos en una base con las cuentas de demostración.

## Modelo y capas

Abre [Modelo Moda Urbana 360](database/Modelo_ModaUrbana360.architect) en SQL Power Architect. El esquema y los datos que carga el programa al iniciar están en [src/main/resources/db](src/main/resources/db). Las consultas de conciliación para H2 están en [03_validacion.sql](database/03_validacion.sql).

- `controller/` enlaza pantallas FXML, valida la entrada y muestra el resultado.
- `service/` y `service/impl/` aplican permisos y reglas de negocio.
- `repository/` persiste las entidades con JDBC y parametriza las consultas.

La recepción de mercadería se abre desde **Compras**. La confirmación guarda el documento del proveedor y sus líneas, actualiza el stock y el costo, y escribe un movimiento `ENTRADA_COMPRA` por SKU junto con la auditoría, dentro de una transacción.
