@echo off
setlocal
pushd "%~dp0" || exit /b 1
set "JAVA_EXE=java"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
set "APP_JAR=ModaUrbana360-2.1.0.jar"
if not exist "%APP_JAR%" if exist "target\%APP_JAR%" set "APP_JAR=target\%APP_JAR%"
"%JAVA_EXE%" -jar "%APP_JAR%" %*
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" if "%~1"=="" (
    echo Comprueba que Java 21 de 64 bits este instalado y que la carpeta lib siga junto al JAR.
    pause
)
popd
exit /b %RESULT%
