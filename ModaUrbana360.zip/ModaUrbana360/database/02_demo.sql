-- Usuarios de demostración: admin, vendedor, almacen y cliente. Clave inicial: admin123.

INSERT INTO perfil (id_perfil,nombre,codigo) VALUES
(1,'Administrador','ADM'),
(2,'Vendedor','VEN'),
(3,'Almacenero','ALM'),
(4,'Cliente','CLI');

INSERT INTO usuario (id_usuario,nombre_usuario,hash_clave,estado,id_perfil) VALUES
(1,'admin','pbkdf2$210000$UJPRUK+GVeFcQZjdJhnJ9Q==$gQx/37wgh7Epn7tHkJG6fq345HjjIE7EFGH4dOjV7Qw=','Activo',1),
(2,'vendedor','pbkdf2$210000$702JcD4kxC4T3gKmSzC5Tg==$0eAXJPGl2/4Ntujkgdi2QLeqsn3KQCkCAaWVwn+JMGI=','Activo',2),
(3,'almacen','pbkdf2$210000$vI16CeZlbSH9oQr8eCTYfA==$0il2LEaycXejDdmgch1lo9bohzj8Pthg4zbNYmTaWZk=','Activo',3),
(4,'cliente','pbkdf2$210000$3yZJFrJF0q48kb5OLCkFMQ==$6vZvjZbp7YO1HaTP/rUxk/CT8arA+UyK/Snnjtzn+nE=','Activo',4);

INSERT INTO nivel_cliente (id_nivel,nombre,descuento_pct,puntos_minimos) VALUES
(1,'Regular',0,0),
(2,'Frecuente',5,200),
(3,'VIP',10,500);

INSERT INTO cliente (id_cliente,id_usuario,documento,nombres,celular,correo,id_nivel,puntos_acumulados) VALUES
(1,4,'00000001','Lucía Demo','900000001','lucia@example.test',1,0);

INSERT INTO marca (id_marca,nombre) VALUES
(1,'Urban Wear'),
(2,'Atelier Norte'),
(3,'Nébula');

INSERT INTO categoria (id_categoria,nombre) VALUES
(1,'Polos'),
(2,'Polerones'),
(3,'Pantalones'),
(4,'Casacas');

INSERT INTO unid_medida (id_unidad,nombre_medida) VALUES
(1,'Unidad'),
(2,'Docena');

INSERT INTO genero (id_genero,nombre) VALUES
(1,'Hombre'),
(2,'Mujer'),
(3,'Unisex');

INSERT INTO temporada (id_temporada,nombre,fecha_inicio,fecha_fin) VALUES
(1,'Colección permanente','2026-01-01','2027-12-31');

INSERT INTO producto (id_producto,codigo,nombre,descripcion,id_marca,id_categoria,id_unidad,id_genero,id_temporada,url_imagen,estado) VALUES
(1,'MU-001','Polo Essential','Algodón suave, corte regular.',1,1,1,3,1,'/images/prenda-1.png','Activo'),
(2,'MU-002','Polo Aura','Corte oversize y textura premium.',2,1,1,3,1,'/images/prenda-2.png','Activo'),
(3,'MU-003','Polo Studio','Un básico para todos los días.',3,1,1,3,1,'/images/prenda-3.png','Activo'),
(4,'MU-004','Hoodie Eclipse','Polerón con capucha y bolsillo canguro.',1,2,1,3,1,'/images/prenda-4.png','Activo'),
(5,'MU-005','Hoodie Nébula','Abrigo ligero de tacto suave.',3,2,1,3,1,'/images/prenda-5.png','Activo'),
(6,'MU-006','Sweatshirt Norte','Diseño limpio, comodidad urbana.',2,2,1,3,1,'/images/prenda-6.png','Activo'),
(7,'MU-007','Jean Night','Denim recto de uso diario.',1,3,1,3,1,'/images/prenda-7.png','Activo'),
(8,'MU-008','Cargo District','Bolsillos funcionales, corte relajado.',2,3,1,3,1,'/images/prenda-8.png','Activo'),
(9,'MU-009','Pantalón Flow','Tela ligera y cintura cómoda.',3,3,1,3,1,'/images/prenda-9.png','Activo'),
(10,'MU-010','Casaca Orbit','Una capa ligera para la ciudad.',3,4,1,3,1,'/images/prenda-10.png','Activo'),
(11,'MU-011','Bomber Metro','Silueta bomber con cierre frontal.',1,4,1,3,1,'/images/prenda-11.png','Activo'),
(12,'MU-012','Casaca Alba','Líneas simples y acabado mate.',2,4,1,3,1,'/images/prenda-12.png','Activo');

INSERT INTO variante (id_variante,id_producto,talla,color,sku,costo,precio_venta,stock_actual,stock_minimo) VALUES
(1,1,'S','Negro','MU001-S',30.0,60,19,5),
(2,1,'M','Negro','MU001-M',30.0,60,20,5),
(3,1,'L','Negro','MU001-L',30.0,60,20,5),
(4,2,'S','Lila','MU002-S',37.5,75,20,5),
(5,2,'M','Lila','MU002-M',37.5,75,20,5),
(6,2,'L','Lila','MU002-L',37.5,75,20,5),
(7,3,'S','Crema','MU003-S',32.5,65,20,5),
(8,3,'M','Crema','MU003-M',32.5,65,20,5),
(9,3,'L','Crema','MU003-L',32.5,65,20,5),
(10,4,'S','Carbón','MU004-S',70.0,140,20,5),
(11,4,'M','Carbón','MU004-M',70.0,140,20,5),
(12,4,'L','Carbón','MU004-L',70.0,140,20,5),
(13,5,'S','Morado','MU005-S',77.5,155,20,5),
(14,5,'M','Morado','MU005-M',77.5,155,20,5),
(15,5,'L','Morado','MU005-L',77.5,155,20,5),
(16,6,'S','Gris','MU006-S',60.0,120,20,5),
(17,6,'M','Gris','MU006-M',60.0,120,20,5),
(18,6,'L','Gris','MU006-L',60.0,120,20,5),
(19,7,'S','Azul','MU007-S',67.5,135,20,5),
(20,7,'M','Azul','MU007-M',67.5,135,20,5),
(21,7,'L','Azul','MU007-L',67.5,135,20,5),
(22,8,'S','Oliva','MU008-S',75.0,150,20,5),
(23,8,'M','Oliva','MU008-M',75.0,150,20,5),
(24,8,'L','Oliva','MU008-L',75.0,150,20,5),
(25,9,'S','Negro','MU009-S',55.0,110,20,5),
(26,9,'M','Negro','MU009-M',55.0,110,20,5),
(27,9,'L','Negro','MU009-L',55.0,110,20,5),
(28,10,'S','Morado','MU010-S',110.0,220,20,5),
(29,10,'M','Morado','MU010-M',110.0,220,20,5),
(30,10,'L','Morado','MU010-L',110.0,220,20,5),
(31,11,'S','Negro','MU011-S',120.0,240,20,5),
(32,11,'M','Negro','MU011-M',120.0,240,20,5),
(33,11,'L','Negro','MU011-L',120.0,240,20,5),
(34,12,'S','Crema','MU012-S',97.5,195,20,5),
(35,12,'M','Crema','MU012-M',97.5,195,20,5),
(36,12,'L','Crema','MU012-L',97.5,195,20,5);

INSERT INTO proveedor (id_proveedor,documento,razon_social,celular,correo,direccion) VALUES
(1,'20000000001','Textiles Demo SAC','900000002','textiles@example.test','Av. Colección 120, Lima');

INSERT INTO canal_venta (id_canal,nombre) VALUES
(1,'Tienda'),
(2,'Catálogo escritorio');

INSERT INTO metodo_pago (id_metodo_pago,nombre) VALUES
(1,'Efectivo'),
(2,'Yape'),
(3,'Plin'),
(4,'Tarjeta'),
(5,'Transferencia');

INSERT INTO promocion (id_promocion,nombre,tipo,valor,fecha_inicio,fecha_fin,id_categoria,id_marca,id_producto,estado) VALUES
(1,'Essential de bienvenida','PORCENTAJE',10,'2026-01-01','2027-12-31',NULL,NULL,1,'Activo');

INSERT INTO venta (id_venta,serie,num_doc,tipo_doc,fecha_gener,precio_base,igv,descuento_total,precio_total,id_cliente,id_usuario,id_canal,estado) VALUES
(1,'B001','00000001','Boleta demo','2026-10-30 10:00:00',91.53,16.47,12,108,1,2,1,'Confirmada');

INSERT INTO venta_detalle (id_venta_detalle,id_venta,id_variante,pu,cantidad,descuento,subtotal,id_promocion) VALUES
(1,1,1,60,2,12,108,1);

INSERT INTO venta_pago (id_venta_pago,id_venta,id_metodo_pago,monto,referencia) VALUES
(1,1,1,50,'Efectivo demo'),
(2,1,2,58,'YAPE-DEMO-001');

INSERT INTO compra (id_compra,serie,num_doc,tipo_doc,fecha_comp,fecha_reg,precio_base,igv,precio_total,id_proveedor,id_usuario,estado) VALUES
(1,'F001','DEMO-001','Factura','2026-10-29','2026-10-29',42330.51,7619.49,49950.0,1,3,'Confirmada');

INSERT INTO compra_detalle (id_compra_detalle,id_compra,id_variante,pu,cantidad,subtotal) VALUES
(1,1,1,30.0,20,600.0),
(2,1,2,30.0,20,600.0),
(3,1,3,30.0,20,600.0),
(4,1,4,37.5,20,750.0),
(5,1,5,37.5,20,750.0),
(6,1,6,37.5,20,750.0),
(7,1,7,32.5,20,650.0),
(8,1,8,32.5,20,650.0),
(9,1,9,32.5,20,650.0),
(10,1,10,70.0,20,1400.0),
(11,1,11,70.0,20,1400.0),
(12,1,12,70.0,20,1400.0),
(13,1,13,77.5,20,1550.0),
(14,1,14,77.5,20,1550.0),
(15,1,15,77.5,20,1550.0),
(16,1,16,60.0,20,1200.0),
(17,1,17,60.0,20,1200.0),
(18,1,18,60.0,20,1200.0),
(19,1,19,67.5,20,1350.0),
(20,1,20,67.5,20,1350.0),
(21,1,21,67.5,20,1350.0),
(22,1,22,75.0,20,1500.0),
(23,1,23,75.0,20,1500.0),
(24,1,24,75.0,20,1500.0),
(25,1,25,55.0,20,1100.0),
(26,1,26,55.0,20,1100.0),
(27,1,27,55.0,20,1100.0),
(28,1,28,110.0,20,2200.0),
(29,1,29,110.0,20,2200.0),
(30,1,30,110.0,20,2200.0),
(31,1,31,120.0,20,2400.0),
(32,1,32,120.0,20,2400.0),
(33,1,33,120.0,20,2400.0),
(34,1,34,97.5,20,1950.0),
(35,1,35,97.5,20,1950.0),
(36,1,36,97.5,20,1950.0);

INSERT INTO devolucion (id_devolucion,id_venta,fecha,motivo,tipo,id_usuario,estado) VALUES
(1,1,'2026-10-30 11:00:00','Talla no adecuada','DEVOLUCION',1,'Confirmada');

INSERT INTO devolucion_detalle (id_dev_detalle,id_devolucion,id_venta_detalle,id_variante_devuelta,cantidad,id_variante_cambio) VALUES
(1,1,1,1,1,NULL);

INSERT INTO movimiento_stock (id_movimiento,id_variante,tipo_movimiento,cantidad,fecha,referencia,id_usuario) VALUES
(1,1,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(2,2,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(3,3,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(4,4,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(5,5,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(6,6,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(7,7,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(8,8,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(9,9,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(10,10,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(11,11,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(12,12,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(13,13,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(14,14,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(15,15,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(16,16,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(17,17,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(18,18,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(19,19,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(20,20,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(21,21,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(22,22,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(23,23,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(24,24,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(25,25,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(26,26,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(27,27,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(28,28,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(29,29,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(30,30,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(31,31,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(32,32,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(33,33,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(34,34,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(35,35,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(36,36,'ENTRADA_COMPRA',20,'2026-10-29 09:00:00','COMPRA:1',3),
(37,1,'SALIDA_VENTA',-2,'2026-10-30 10:00:00','VENTA:1',2),
(38,1,'ENTRADA_DEVOLUCION',1,'2026-10-30 11:00:00','DEVOLUCION:1',1);

INSERT INTO auditoria (id_auditoria,id_usuario,accion,entidad,id_registro,fecha,detalle) VALUES
(1,3,'CONFIRMAR','compra',1,'2026-10-29 09:00:00','Carga demostrativa de mercadería'),
(2,2,'CONFIRMAR','venta',1,'2026-10-30 10:00:00','Venta demostrativa con pago mixto'),
(3,1,'CONFIRMAR','devolucion',1,'2026-10-30 11:00:00','Reembolso demostrativo S/ 54.00; efectivo');

ALTER TABLE perfil ALTER COLUMN id_perfil RESTART WITH 5;

ALTER TABLE usuario ALTER COLUMN id_usuario RESTART WITH 5;

ALTER TABLE nivel_cliente ALTER COLUMN id_nivel RESTART WITH 4;

ALTER TABLE cliente ALTER COLUMN id_cliente RESTART WITH 2;

ALTER TABLE marca ALTER COLUMN id_marca RESTART WITH 4;

ALTER TABLE categoria ALTER COLUMN id_categoria RESTART WITH 5;

ALTER TABLE unid_medida ALTER COLUMN id_unidad RESTART WITH 3;

ALTER TABLE genero ALTER COLUMN id_genero RESTART WITH 4;

ALTER TABLE temporada ALTER COLUMN id_temporada RESTART WITH 2;

ALTER TABLE producto ALTER COLUMN id_producto RESTART WITH 13;

ALTER TABLE variante ALTER COLUMN id_variante RESTART WITH 37;

ALTER TABLE proveedor ALTER COLUMN id_proveedor RESTART WITH 2;

ALTER TABLE canal_venta ALTER COLUMN id_canal RESTART WITH 3;

ALTER TABLE metodo_pago ALTER COLUMN id_metodo_pago RESTART WITH 6;

ALTER TABLE promocion ALTER COLUMN id_promocion RESTART WITH 2;

ALTER TABLE venta ALTER COLUMN id_venta RESTART WITH 2;

ALTER TABLE venta_detalle ALTER COLUMN id_venta_detalle RESTART WITH 2;

ALTER TABLE venta_pago ALTER COLUMN id_venta_pago RESTART WITH 3;

ALTER TABLE compra ALTER COLUMN id_compra RESTART WITH 2;

ALTER TABLE compra_detalle ALTER COLUMN id_compra_detalle RESTART WITH 37;

ALTER TABLE devolucion ALTER COLUMN id_devolucion RESTART WITH 2;

ALTER TABLE devolucion_detalle ALTER COLUMN id_dev_detalle RESTART WITH 2;

ALTER TABLE movimiento_stock ALTER COLUMN id_movimiento RESTART WITH 39;

ALTER TABLE auditoria ALTER COLUMN id_auditoria RESTART WITH 4;