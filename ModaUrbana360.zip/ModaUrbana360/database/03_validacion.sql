-- Consultas de control de solo lectura. Las cuatro primeras deben devolver cero filas.
SELECT v.id_variante,v.stock_actual,COALESCE(SUM(m.cantidad),0) AS stock_movimientos
FROM variante v LEFT JOIN movimiento_stock m USING(id_variante)
GROUP BY v.id_variante HAVING v.stock_actual<>COALESCE(SUM(m.cantidad),0);

SELECT v.id_venta,v.precio_total,SUM(d.subtotal) AS suma_detalles
FROM venta v JOIN venta_detalle d USING(id_venta)
GROUP BY v.id_venta HAVING v.precio_total<>SUM(d.subtotal);

SELECT v.id_venta,v.precio_total,SUM(p.monto) AS suma_pagos
FROM venta v JOIN venta_pago p USING(id_venta)
GROUP BY v.id_venta HAVING v.precio_total<>SUM(p.monto);

SELECT c.id_compra,c.precio_total,SUM(d.subtotal) AS suma_detalles
FROM compra c JOIN compra_detalle d USING(id_compra)
GROUP BY c.id_compra HAVING c.precio_total<>SUM(d.subtotal);

SELECT 'tablas' AS control,COUNT(*) AS cantidad FROM information_schema.tables WHERE table_schema=current_schema();
SELECT 'claves foraneas' AS control,COUNT(*) AS cantidad FROM information_schema.table_constraints WHERE table_schema=current_schema() AND constraint_type='FOREIGN KEY';
