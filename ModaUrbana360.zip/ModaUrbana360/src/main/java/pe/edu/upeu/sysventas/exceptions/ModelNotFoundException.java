package pe.edu.upeu.sysventas.exceptions;

public class ModelNotFoundException extends IllegalArgumentException {
  public ModelNotFoundException(String entity, long id) {
    super("No existe " + entity + " con identificador " + id + ".");
  }
}
