package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.ProductoCatalogoDto;
import pe.edu.upeu.sysventas.model.*;

/** Contrato de la capa de negocio utilizado por los controladores. */
public interface CatalogService {

  List<ProductoCatalogoDto> search(
      String text,
      Long brand,
      Long category,
      String size,
      String color,
      BigDecimal min,
      BigDecimal max,
      boolean available);

  List<Map<String, Object>> choices(String table);
}
