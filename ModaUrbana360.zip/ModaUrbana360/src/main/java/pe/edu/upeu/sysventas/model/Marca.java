package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla marca. Las relaciones se identifican mediante sus claves foráneas. */
public class Marca {
  private Long idMarca = null;
  private String nombre = null;

  public Marca() {}

  public Long getIdMarca() {
    return idMarca;
  }

  public void setIdMarca(Long idMarca) {
    this.idMarca = idMarca;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
}
