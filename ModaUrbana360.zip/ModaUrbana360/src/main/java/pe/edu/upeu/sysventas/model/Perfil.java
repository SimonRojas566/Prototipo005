package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla perfil. Las relaciones se identifican mediante sus claves foráneas. */
public class Perfil {
  private Long idPerfil = null;
  private String nombre = null;
  private String codigo = null;

  public Perfil() {}

  public Long getIdPerfil() {
    return idPerfil;
  }

  public void setIdPerfil(Long idPerfil) {
    this.idPerfil = idPerfil;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getCodigo() {
    return codigo;
  }

  public void setCodigo(String codigo) {
    this.codigo = codigo;
  }
}
