package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.*;

/** Contrato de la capa de negocio utilizado por los controladores. */
public interface AuthService {

  void login(String name, String password);

  void logout();

  void guest();

  long require(Connection c, String... roles) throws SQLException;

  long register(
      String username, String password, String document, String name, String phone, String email);
}
