package pe.edu.upeu.sysventas.controller;

import java.math.*;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.Choice;
import pe.edu.upeu.sysventas.dto.Quote;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.util.*;

public class VentaController {
  @FXML private ComboBox<pe.edu.upeu.sysventas.enums.TipoDocumento> documentType;
  @FXML private TableView<Map<String, Object>> cartTable, paymentTable;
  @FXML private ComboBox<Choice> client, variant, method;
  @FXML private TextField quantity, manual, amount, reference;
  @FXML private Label base, tax, discount, total, summary, manualLabel;
  private final List<Payment> payments = new ArrayList<>();
  private Quote quote;

  @FXML
  public void initialize() {
    Ui.run(
        () -> {
          var ctx = AppContext.getInstance();
          documentType.getItems().setAll(pe.edu.upeu.sysventas.enums.TipoDocumento.values());
          documentType.setValue(pe.edu.upeu.sysventas.enums.TipoDocumento.BOLETA);
          boolean customer =
              "CLI".equals(SessionManager.getInstance().getRole())
                  || SessionManager.getInstance().isGuest();
          client
              .getItems()
              .add(
                  new Choice(
                      0,
                      SessionManager.getInstance().isGuest()
                          ? "Invitado · sin cuenta"
                          : customer ? "Tu cuenta de cliente" : "Consumidor final"));
          if (!customer)
            for (var c : ctx.catalog.choices("cliente"))
              client
                  .getItems()
                  .add(
                      new Choice(
                          ((Number) c.get("id_cliente")).longValue(), c.get("nombre").toString()));
          client.getSelectionModel().selectFirst();
          client.setDisable(customer);
          for (var v : ctx.catalog.search("", null, null, "", "", null, null, true))
            variant
                .getItems()
                .add(
                    new Choice(
                        v.getIdVariante(),
                        v.getSku()
                            + " · "
                            + v.getNombre()
                            + " · "
                            + v.getTalla()
                            + " / "
                            + v.getColor()));
          for (var m : ctx.catalog.choices("metodo_pago"))
            method
                .getItems()
                .add(
                    new Choice(
                        ((Number) m.get("id_metodo_pago")).longValue(),
                        m.get("nombre").toString()));
          method.getSelectionModel().selectFirst();
          boolean admin = "ADM".equals(SessionManager.getInstance().getRole());
          manual.setVisible(admin);
          manual.setManaged(admin);
          manualLabel.setVisible(admin);
          manualLabel.setManaged(admin);
          client.setOnAction(e -> refresh());
          refresh();
        });
  }

  private Long clientId() {
    return client.getValue() == null || client.getValue().getId() == 0
        ? null
        : client.getValue().getId();
  }

  private BigDecimal manualValue() {
    return manual.getText().isBlank() ? BigDecimal.ZERO : Money.parse(manual.getText());
  }

  @FXML
  public void add() {
    Ui.run(
        () -> {
          if (variant.getValue() == null)
            throw new IllegalArgumentException("Selecciona una variante.");
          CartState.add(variant.getValue().getId(), Integer.parseInt(quantity.getText()));
          try {
            refreshOrThrow();
          } catch (Exception ex) {
            CartState.lines.removeLast();
            throw ex;
          }
        });
  }

  @FXML
  public void remove() {
    Ui.run(
        () -> {
          long id = Ui.id(cartTable.getSelectionModel().getSelectedItem(), "id_variante");
          CartState.lines.removeIf(l -> l.getVariante() == id);
          refreshOrThrow();
        });
  }

  @FXML
  public void clear() {
    if (Ui.confirm("¿Vaciar el carrito y sus pagos?")) {
      CartState.clear();
      payments.clear();
      refresh();
    }
  }

  @FXML
  public void refresh() {
    Ui.run(this::refreshOrThrow);
  }

  private void refreshOrThrow() {
    if (CartState.lines.isEmpty()) {
      quote = null;
      Ui.table(cartTable, List.of());
      base.setText("S/ 0.00");
      tax.setText("S/ 0.00");
      discount.setText("S/ 0.00");
      total.setText("S/ 0.00");
      summary.setText("Agrega prendas desde la colección o por SKU.");
      paymentRows();
      return;
    }
    quote = AppContext.getInstance().ventas.quote(CartState.lines, clientId(), manualValue());
    List<Map<String, Object>> rows = new ArrayList<>();
    for (var l : quote.getLines()) {
      Map<String, Object> r = new LinkedHashMap<>();
      r.put("id_variante", l.getVariant());
      r.put("sku", l.getSku());
      r.put("producto", l.getName());
      r.put("cantidad", l.getQuantity());
      r.put("pu", l.getPrice());
      r.put("descuento", l.getDiscount());
      r.put("subtotal", l.getSubtotal());
      rows.add(r);
    }
    Ui.table(cartTable, rows);
    base.setText(Money.soles(quote.getBase()));
    tax.setText(Money.soles(quote.getTax()));
    discount.setText(Money.soles(quote.getDiscount()));
    total.setText(Money.soles(quote.getTotal()));
    summary.setText(
        quote.getLines().size() + " variantes · promociones vigentes aplicadas automáticamente");
    paymentRows();
  }

  private void paymentRows() {
    List<Map<String, Object>> rows = new ArrayList<>();
    BigDecimal paid = Money.ZERO;
    for (int i = 0; i < payments.size(); i++) {
      var p = payments.get(i);
      Map<String, Object> r = new LinkedHashMap<>();
      r.put("fila", i + 1);
      r.put(
          "metodo_pago",
          method.getItems().stream()
              .filter(m -> m.getId() == p.getMetodo())
              .findFirst()
              .orElseThrow()
              .getName());
      r.put("monto", p.getMonto());
      r.put("referencia", p.getReferencia());
      rows.add(r);
      paid = paid.add(p.getMonto());
    }
    Ui.table(paymentTable, rows);
    amount.setText(
        quote == null
            ? "0.00"
            : quote.getTotal().subtract(paid).max(BigDecimal.ZERO).toPlainString());
  }

  @FXML
  public void addPayment() {
    Ui.run(
        () -> {
          if (quote == null) throw new IllegalArgumentException("El carrito está vacío.");
          payments.add(
              new Payment(
                  method.getValue().getId(), Money.parse(amount.getText()), reference.getText()));
          reference.clear();
          paymentRows();
        });
  }

  @FXML
  public void removePayment() {
    Ui.run(
        () -> {
          int i = (int) Ui.id(paymentTable.getSelectionModel().getSelectedItem(), "fila") - 1;
          payments.remove(i);
          paymentRows();
        });
  }

  @FXML
  public void confirm() {
    Ui.run(
        () -> {
          if (quote == null) throw new IllegalArgumentException("El carrito está vacío.");
          if (!Ui.confirm(
              "Confirmar venta por "
                  + Money.soles(quote.getTotal())
                  + ". Los métodos de pago son registros demostrativos.")) return;
          long id =
              AppContext.getInstance()
                  .ventas
                  .sell(
                      CartState.lines,
                      clientId(),
                      List.copyOf(payments),
                      manualValue(),
                      documentType.getValue());
          CartState.clear();
          payments.clear();
          refreshOrThrow();
          new pe.edu.upeu.sysventas.components.comprob.ComprobanteView()
              .show(AppContext.getInstance().reports.comprobante(id));
        });
  }
}
