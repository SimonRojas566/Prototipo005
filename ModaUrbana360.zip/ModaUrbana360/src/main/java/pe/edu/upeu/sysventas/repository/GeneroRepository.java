package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Genero;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para genero. No abre conexiones dentro de una transacción. */
public class GeneroRepository extends AbstractJdbcRepository<Genero> {
  public GeneroRepository(SqlRepository db) {
    super(db, "genero", "id_genero");
  }

  @Override
  public Genero fromRow(Map<String, Object> row) {
    Genero entity = new Genero();
    if (row.containsKey("id_genero")) entity.setIdGenero(SqlHelper.longValue(row.get("id_genero")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Genero entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_genero", entity.getIdGenero());
    row.put("nombre", entity.getNombre());
    return row;
  }
}
