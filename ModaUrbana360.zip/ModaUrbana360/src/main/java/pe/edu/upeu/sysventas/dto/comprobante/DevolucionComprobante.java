package pe.edu.upeu.sysventas.dto.comprobante;

import java.util.*;

/** Proyección tipada utilizada para consultar y presentar un comprobante. */
public final class DevolucionComprobante {
  private final Long idDevolucion;
  private final String tipo;
  private final Integer cantidad;
  private final String sku;

  public DevolucionComprobante(Long idDevolucion, String tipo, Integer cantidad, String sku) {
    this.idDevolucion = idDevolucion;
    this.tipo = tipo;
    this.cantidad = cantidad;
    this.sku = sku;
  }

  public Long getIdDevolucion() {
    return idDevolucion;
  }

  public String getTipo() {
    return tipo;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public String getSku() {
    return sku;
  }
}
