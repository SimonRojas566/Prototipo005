package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Variante;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para variante. No abre conexiones dentro de una transacción. */
public class VarianteRepository extends AbstractJdbcRepository<Variante> {
  public VarianteRepository(SqlRepository db) {
    super(db, "variante", "id_variante");
  }

  @Override
  public Variante fromRow(Map<String, Object> row) {
    Variante entity = new Variante();
    if (row.containsKey("id_variante"))
      entity.setIdVariante(SqlHelper.longValue(row.get("id_variante")));
    if (row.containsKey("id_producto"))
      entity.setIdProducto(SqlHelper.longValue(row.get("id_producto")));
    if (row.containsKey("talla")) entity.setTalla(SqlHelper.textValue(row.get("talla")));
    if (row.containsKey("color")) entity.setColor(SqlHelper.textValue(row.get("color")));
    if (row.containsKey("sku")) entity.setSku(SqlHelper.textValue(row.get("sku")));
    if (row.containsKey("costo")) entity.setCosto(SqlHelper.decimalValue(row.get("costo")));
    if (row.containsKey("precio_venta"))
      entity.setPrecioVenta(SqlHelper.decimalValue(row.get("precio_venta")));
    if (row.containsKey("stock_actual"))
      entity.setStockActual(SqlHelper.integerValue(row.get("stock_actual")));
    if (row.containsKey("stock_minimo"))
      entity.setStockMinimo(SqlHelper.integerValue(row.get("stock_minimo")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Variante entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_variante", entity.getIdVariante());
    row.put("id_producto", entity.getIdProducto());
    row.put("talla", entity.getTalla());
    row.put("color", entity.getColor());
    row.put("sku", entity.getSku());
    row.put("costo", entity.getCosto());
    row.put("precio_venta", entity.getPrecioVenta());
    row.put("stock_actual", entity.getStockActual());
    row.put("stock_minimo", entity.getStockMinimo());
    return row;
  }
}
