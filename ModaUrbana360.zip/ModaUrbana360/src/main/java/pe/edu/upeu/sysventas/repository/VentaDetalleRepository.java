package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.VentaDetalle;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para venta_detalle. No abre conexiones dentro de una transacción. */
public class VentaDetalleRepository extends AbstractJdbcRepository<VentaDetalle> {
  public VentaDetalleRepository(SqlRepository db) {
    super(db, "venta_detalle", "id_venta_detalle");
  }

  @Override
  public VentaDetalle fromRow(Map<String, Object> row) {
    VentaDetalle entity = new VentaDetalle();
    if (row.containsKey("id_venta_detalle"))
      entity.setIdVentaDetalle(SqlHelper.longValue(row.get("id_venta_detalle")));
    if (row.containsKey("id_venta")) entity.setIdVenta(SqlHelper.longValue(row.get("id_venta")));
    if (row.containsKey("id_variante"))
      entity.setIdVariante(SqlHelper.longValue(row.get("id_variante")));
    if (row.containsKey("pu")) entity.setPu(SqlHelper.decimalValue(row.get("pu")));
    if (row.containsKey("cantidad"))
      entity.setCantidad(SqlHelper.integerValue(row.get("cantidad")));
    if (row.containsKey("descuento"))
      entity.setDescuento(SqlHelper.decimalValue(row.get("descuento")));
    if (row.containsKey("subtotal"))
      entity.setSubtotal(SqlHelper.decimalValue(row.get("subtotal")));
    if (row.containsKey("id_promocion"))
      entity.setIdPromocion(SqlHelper.longValue(row.get("id_promocion")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(VentaDetalle entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_venta_detalle", entity.getIdVentaDetalle());
    row.put("id_venta", entity.getIdVenta());
    row.put("id_variante", entity.getIdVariante());
    row.put("pu", entity.getPu());
    row.put("cantidad", entity.getCantidad());
    row.put("descuento", entity.getDescuento());
    row.put("subtotal", entity.getSubtotal());
    row.put("id_promocion", entity.getIdPromocion());
    return row;
  }
}
