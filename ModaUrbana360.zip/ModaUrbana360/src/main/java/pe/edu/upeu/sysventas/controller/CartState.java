package pe.edu.upeu.sysventas.controller;

import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.CartLine;

/** Solo el carrito es temporal; los registros confirmados siempre persisten en H2. */
public final class CartState {
  public static final List<CartLine> lines = new ArrayList<>();

  private CartState() {}

  public static void add(long id, int qty) {
    lines.add(new CartLine(id, qty));
  }

  public static void clear() {
    lines.clear();
  }
}
