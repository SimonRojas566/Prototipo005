package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.exceptions.ModelNotFoundException;

/** Reutiliza únicamente la mecánica JDBC. Cada repositorio declara su mapeo explícito. */
public abstract class AbstractJdbcRepository<T> implements ICrudGenericoRepository<T> {
  protected final SqlRepository db;
  private final String table;
  private final String primaryKey;

  protected AbstractJdbcRepository(SqlRepository db, String table, String primaryKey) {
    this.db = db;
    this.table = table;
    this.primaryKey = primaryKey;
  }

  public abstract T fromRow(Map<String, Object> row);

  public abstract Map<String, Object> toRow(T entity);

  public List<T> findAll(Connection c) throws SQLException {
    List<T> entities = new ArrayList<>();
    for (var row : db.query(c, "SELECT * FROM " + table + " ORDER BY " + primaryKey)) {
      entities.add(fromRow(row));
    }
    return entities;
  }

  public T findById(Connection c, long id) throws SQLException {
    return find(c, id, false);
  }

  public T findByIdForUpdate(Connection c, long id) throws SQLException {
    return find(c, id, true);
  }

  private T find(Connection c, long id, boolean lock) throws SQLException {
    var rows =
        db.query(
            c,
            "SELECT * FROM " + table + " WHERE " + primaryKey + "=?" + (lock ? " FOR UPDATE" : ""),
            id);
    if (rows.isEmpty()) throw new ModelNotFoundException(table, id);
    return fromRow(rows.getFirst());
  }

  public long insert(Connection c, T entity) throws SQLException {
    Map<String, Object> row = new LinkedHashMap<>(toRow(entity));
    Object explicit = row.get(primaryKey);
    if (explicit == null) row.remove(primaryKey);
    String sql =
        "INSERT INTO "
            + table
            + "("
            + String.join(",", row.keySet())
            + ") VALUES("
            + String.join(",", Collections.nCopies(row.size(), "?"))
            + ")";
    long id = db.id(c, sql, primaryKey, row.values().toArray());
    return explicit == null ? id : ((Number) explicit).longValue();
  }

  public void update(Connection c, T entity) throws SQLException {
    Map<String, Object> row = new LinkedHashMap<>(toRow(entity));
    Object id = row.remove(primaryKey);
    if (id == null) throw new IllegalArgumentException("Falta la identidad de " + table);
    List<Object> args = new ArrayList<>(row.values());
    args.add(id);
    String setters = String.join(",", row.keySet().stream().map(n -> n + "=?").toList());
    if (db.update(
            c,
            "UPDATE " + table + " SET " + setters + " WHERE " + primaryKey + "=?",
            args.toArray())
        != 1) {
      throw new ModelNotFoundException(table, ((Number) id).longValue());
    }
  }

  /** Adaptador del formulario dinámico: convierte sus campos al modelo antes de persistir. */
  public long saveForm(Connection c, Long id, List<String> names, List<Object> values)
      throws SQLException {
    Map<String, Object> row = id == null ? new LinkedHashMap<>() : toRow(findByIdForUpdate(c, id));
    for (int i = 0; i < names.size(); i++) row.put(names.get(i), values.get(i));
    T entity = fromRow(row);
    if (id == null) return insert(c, entity);
    update(c, entity);
    return id;
  }
}
