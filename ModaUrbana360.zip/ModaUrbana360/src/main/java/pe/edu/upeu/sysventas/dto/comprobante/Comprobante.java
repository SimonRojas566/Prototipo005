package pe.edu.upeu.sysventas.dto.comprobante;

import java.util.*;
import pe.edu.upeu.sysventas.model.Venta;

/** Proyección tipada utilizada para consultar y presentar un comprobante. */
public final class Comprobante {
  private final Venta venta;
  private final String cliente;
  private final String responsable;
  private final String documentoCliente;
  private final List<ItemComprobante> items;
  private final List<PagoComprobante> pagos;
  private final List<DevolucionComprobante> devoluciones;

  public Comprobante(
      Venta venta,
      String cliente,
      String responsable,
      String documentoCliente,
      List<ItemComprobante> items,
      List<PagoComprobante> pagos,
      List<DevolucionComprobante> devoluciones) {
    this.venta = venta;
    this.cliente = cliente;
    this.responsable = responsable;
    this.documentoCliente = documentoCliente;
    this.items = List.copyOf(items);
    this.pagos = List.copyOf(pagos);
    this.devoluciones = List.copyOf(devoluciones);
  }

  public String getDocumentoCliente() {
    return documentoCliente;
  }

  public Venta getVenta() {
    return venta;
  }

  public String getCliente() {
    return cliente;
  }

  public String getResponsable() {
    return responsable;
  }

  public List<ItemComprobante> getItems() {
    return items;
  }

  public List<PagoComprobante> getPagos() {
    return pagos;
  }

  public List<DevolucionComprobante> getDevoluciones() {
    return devoluciones;
  }
}
