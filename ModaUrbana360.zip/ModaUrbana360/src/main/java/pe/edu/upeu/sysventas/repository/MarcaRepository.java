package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Marca;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para marca. No abre conexiones dentro de una transacción. */
public class MarcaRepository extends AbstractJdbcRepository<Marca> {
  public MarcaRepository(SqlRepository db) {
    super(db, "marca", "id_marca");
  }

  @Override
  public Marca fromRow(Map<String, Object> row) {
    Marca entity = new Marca();
    if (row.containsKey("id_marca")) entity.setIdMarca(SqlHelper.longValue(row.get("id_marca")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Marca entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_marca", entity.getIdMarca());
    row.put("nombre", entity.getNombre());
    return row;
  }
}
