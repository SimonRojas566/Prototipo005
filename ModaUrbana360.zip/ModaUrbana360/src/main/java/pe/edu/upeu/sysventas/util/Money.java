package pe.edu.upeu.sysventas.util;

import java.math.*;
import pe.edu.upeu.sysventas.config.DatabaseConfig;

public final class Money {
  public static final BigDecimal ZERO = new BigDecimal("0.00");

  private Money() {}

  public static BigDecimal of(Object value) {
    return new BigDecimal(value.toString()).setScale(2, RoundingMode.HALF_UP);
  }

  public static BigDecimal parse(String value) {
    try {
      return of(value.trim().replace(',', '.'));
    } catch (Exception e) {
      throw new IllegalArgumentException("Ingresa un importe numérico válido.");
    }
  }

  public static BigDecimal rate() {
    BigDecimal r = new BigDecimal(DatabaseConfig.setting("tax.rate", "0.18"));
    if (r.signum() < 0 || r.compareTo(BigDecimal.ONE) > 0)
      throw new IllegalArgumentException("La tasa de impuesto debe estar entre 0 y 1.");
    return r;
  }

  public static BigDecimal base(BigDecimal total) {
    return total.divide(BigDecimal.ONE.add(rate()), 2, RoundingMode.HALF_UP);
  }

  public static String soles(Object value) {
    return "S/ " + of(value).toPlainString();
  }
}
