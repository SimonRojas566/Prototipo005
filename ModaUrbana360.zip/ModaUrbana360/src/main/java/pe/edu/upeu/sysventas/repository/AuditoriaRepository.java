package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Auditoria;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para auditoria. No abre conexiones dentro de una transacción. */
public class AuditoriaRepository extends AbstractJdbcRepository<Auditoria> {
  public AuditoriaRepository(SqlRepository db) {
    super(db, "auditoria", "id_auditoria");
  }

  @Override
  public Auditoria fromRow(Map<String, Object> row) {
    Auditoria entity = new Auditoria();
    if (row.containsKey("id_auditoria"))
      entity.setIdAuditoria(SqlHelper.longValue(row.get("id_auditoria")));
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    if (row.containsKey("accion")) entity.setAccion(SqlHelper.textValue(row.get("accion")));
    if (row.containsKey("entidad")) entity.setEntidad(SqlHelper.textValue(row.get("entidad")));
    if (row.containsKey("id_registro"))
      entity.setIdRegistro(SqlHelper.longValue(row.get("id_registro")));
    if (row.containsKey("fecha")) entity.setFecha(SqlHelper.timestampValue(row.get("fecha")));
    if (row.containsKey("detalle")) entity.setDetalle(SqlHelper.textValue(row.get("detalle")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Auditoria entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_auditoria", entity.getIdAuditoria());
    row.put("id_usuario", entity.getIdUsuario());
    row.put("accion", entity.getAccion());
    row.put("entidad", entity.getEntidad());
    row.put("id_registro", entity.getIdRegistro());
    row.put("fecha", entity.getFecha());
    row.put("detalle", entity.getDetalle());
    return row;
  }
}
