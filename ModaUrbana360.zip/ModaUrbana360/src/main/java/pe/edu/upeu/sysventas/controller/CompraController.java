package pe.edu.upeu.sysventas.controller;

import java.math.*;
import java.time.*;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.Choice;
import pe.edu.upeu.sysventas.dto.PurchaseLine;
import pe.edu.upeu.sysventas.util.*;

public class CompraController {
  @FXML private ComboBox<Choice> supplier, variant;
  @FXML private TextField serie, document, quantity, cost;
  @FXML private DatePicker date;
  @FXML private TableView<Map<String, Object>> table;
  @FXML private Label total;
  private final List<PurchaseLine> lines = new ArrayList<>();

  @FXML
  public void initialize() {
    date.setValue(LocalDate.now());
    Ui.run(
        () -> {
          for (var p : AppContext.getInstance().catalog.choices("proveedor"))
            supplier
                .getItems()
                .add(
                    new Choice(
                        ((Number) p.get("id_proveedor")).longValue(), p.get("nombre").toString()));
          for (var p : AppContext.getInstance().catalog.choices("variante"))
            variant
                .getItems()
                .add(
                    new Choice(
                        ((Number) p.get("id_variante")).longValue(), p.get("nombre").toString()));
          refresh();
        });
  }

  @FXML
  public void add() {
    Ui.run(
        () -> {
          if (variant.getValue() == null) throw new IllegalArgumentException("Selecciona un SKU.");
          long v = variant.getValue().getId();
          if (lines.stream().anyMatch(l -> l.getVariante() == v))
            throw new IllegalArgumentException(
                "El SKU ya está en la compra. Retira la línea e ingresa su cantidad total.");
          lines.add(
              new PurchaseLine(
                  v, Integer.parseInt(quantity.getText()), Money.parse(cost.getText())));
          refresh();
        });
  }

  private void refresh() {
    List<Map<String, Object>> rows = new ArrayList<>();
    BigDecimal sum = Money.ZERO;
    for (var l : lines) {
      Map<String, Object> r = new LinkedHashMap<>();
      r.put("id_variante", l.getVariante());
      r.put(
          "sku",
          variant.getItems().stream()
              .filter(v -> v.getId() == l.getVariante())
              .findFirst()
              .orElseThrow()
              .getName());
      r.put("cantidad", l.getCantidad());
      r.put("costo", l.getCosto());
      r.put("subtotal", l.getCosto().multiply(BigDecimal.valueOf(l.getCantidad())));
      rows.add(r);
      sum = sum.add((BigDecimal) r.get("subtotal"));
    }
    Ui.table(table, rows);
    total.setText(Money.soles(sum));
  }

  @FXML
  public void remove() {
    Ui.run(
        () -> {
          long id = Ui.id(table.getSelectionModel().getSelectedItem(), "id_variante");
          lines.removeIf(l -> l.getVariante() == id);
          refresh();
        });
  }

  @FXML
  public void confirm() {
    Ui.run(
        () -> {
          if (supplier.getValue() == null)
            throw new IllegalArgumentException("Selecciona un proveedor.");
          if (!Ui.confirm(
              "Confirmar recepción por " + total.getText() + " e incrementar existencias.")) return;
          long id =
              AppContext.getInstance()
                  .compras
                  .buy(
                      supplier.getValue().getId(),
                      serie.getText(),
                      document.getText(),
                      date.getValue(),
                      List.copyOf(lines));
          lines.clear();
          document.clear();
          refresh();
          Ui.info("Compra #" + id + " registrada. El inventario se actualizó.");
        });
  }
}
