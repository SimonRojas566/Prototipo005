package pe.edu.upeu.sysventas.controller;

import java.math.*;
import java.time.*;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.Choice;
import pe.edu.upeu.sysventas.dto.PurchaseLine;
import pe.edu.upeu.sysventas.util.*;

public class CompraController {
  @FXML private ComboBox<Choice> supplier, variant;
  @FXML private TextField serie, document, productSearch, quantity, cost;
  @FXML private DatePicker date;
  @FXML private TableView<Map<String, Object>> table;
  @FXML private Label total;
  private final List<PurchaseLine> lines = new ArrayList<>();
  private final List<Choice> allVariants = new ArrayList<>();

  @FXML
  public void initialize() {
    date.setValue(LocalDate.now());
    Ui.run(
        () -> {
          for (var p : AppContext.getInstance().catalog.choices("proveedor"))
            supplier
                .getItems()
                .add(
                    new Choice(
                        ((Number) p.get("id_proveedor")).longValue(), p.get("nombre").toString()));
          for (var p : AppContext.getInstance().catalog.choices("variante"))
            allVariants.add(
                new Choice(
                    ((Number) p.get("id_variante")).longValue(), p.get("nombre").toString()));
          variant.getItems().setAll(allVariants);
          productSearch.textProperty().addListener((o, before, query) -> filterVariants(query));
          refresh();
        });
  }

  private void filterVariants(String query) {
    Choice selected = variant.getValue();
    String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
    variant.getItems().setAll(
        allVariants.stream().filter(v -> v.getName().toLowerCase(Locale.ROOT).contains(q)).toList());
    if (selected != null && variant.getItems().stream().anyMatch(v -> v.getId() == selected.getId()))
      variant.setValue(selected);
    else variant.getSelectionModel().clearSelection();
    variant.hide();
  }

  @FXML
  public void add() {
    Ui.run(
        () -> {
          if (variant.getValue() == null) throw new IllegalArgumentException("Selecciona un SKU.");
          long v = variant.getValue().getId();
          int qty = Integer.parseInt(quantity.getText());
          BigDecimal unitCost = Money.parse(cost.getText());
          int existing = -1;
          for (int i = 0; i < lines.size(); i++)
            if (lines.get(i).getVariante() == v) existing = i;
          if (existing >= 0) {
            PurchaseLine previous = lines.get(existing);
            if (previous.getCosto().compareTo(unitCost) != 0)
              throw new IllegalArgumentException(
                  "Ese SKU ya tiene otro costo en esta compra. Retira la línea para reemplazarla.");
            lines.set(
                existing,
                new PurchaseLine(v, Math.addExact(previous.getCantidad(), qty), unitCost));
          } else lines.add(new PurchaseLine(v, qty, unitCost));
          refresh();
        });
  }

  private void refresh() {
    List<Map<String, Object>> rows = new ArrayList<>();
    BigDecimal sum = Money.ZERO;
    for (var l : lines) {
      Map<String, Object> r = new LinkedHashMap<>();
      r.put("id_variante", l.getVariante());
      r.put(
          "sku",
          allVariants.stream()
              .filter(v -> v.getId() == l.getVariante())
              .findFirst()
              .orElseThrow()
              .getName());
      r.put("cantidad", l.getCantidad());
      r.put("costo", l.getCosto());
      r.put("subtotal", l.getCosto().multiply(BigDecimal.valueOf(l.getCantidad())));
      rows.add(r);
      sum = sum.add((BigDecimal) r.get("subtotal"));
    }
    Ui.table(table, rows);
    total.setText(Money.soles(sum));
  }

  @FXML
  public void remove() {
    Ui.run(
        () -> {
          long id = Ui.id(table.getSelectionModel().getSelectedItem(), "id_variante");
          lines.removeIf(l -> l.getVariante() == id);
          refresh();
        });
  }

  @FXML
  public void confirm() {
    Ui.run(
        () -> {
          if (supplier.getValue() == null)
            throw new IllegalArgumentException("Selecciona un proveedor.");
          if (!Ui.confirm(
              "Confirmar recepción por " + total.getText() + " e incrementar existencias.")) return;
          long id =
              AppContext.getInstance()
                  .compras
                  .buy(
                      supplier.getValue().getId(),
                      serie.getText(),
                      document.getText(),
                      date.getValue(),
                      List.copyOf(lines));
          lines.clear();
          document.clear();
          refresh();
          Ui.info("Compra #" + id + " registrada. El inventario se actualizó.");
        });
  }
}
