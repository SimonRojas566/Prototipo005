package pe.edu.upeu.sysventas.controller;

import java.time.*;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.util.*;

public class DashboardController {
  @FXML private Label greeting, date, metric1, metric2, metric3, label1, label2, label3;
  @FXML private TableView<Map<String, Object>> recent;

  @FXML
  public void initialize() {
    var s = SessionManager.getInstance();
    greeting.setText("Hola, " + s.getUserName() + ".");
    date.textProperty()
        .bind(
            javafx.beans.binding.Bindings.createStringBinding(
                () -> {
                  var language = UiSettings.getLanguage();
                  String pattern =
                      language == pe.edu.upeu.sysventas.enums.UiLanguage.ENGLISH
                          ? "EEEE, MMMM d, yyyy"
                          : "EEEE d 'de' MMMM yyyy";
                  return LocalDate.now()
                      .format(
                          java.time.format.DateTimeFormatter.ofPattern(
                              pattern, language.getLocale()));
                },
                UiSettings.languageProperty()));
    Ui.run(
        () -> {
          var ctx = AppContext.getInstance();
          var items = ctx.catalog.search("", null, null, "", "", null, null, false);
          label1.setText("VARIANTES EN COLECCIÓN");
          metric1.setText("" + items.size());
          label2.setText("UNIDADES DISPONIBLES");
          metric2.setText("" + items.stream().mapToInt(x -> x.getStockActual()).sum());
          if (Set.of("ADM", "ALM").contains(s.getRole())) {
            label3.setText("VARIANTES CON STOCK BAJO");
            metric3.setText(
                "" + items.stream().filter(x -> x.getStockActual() <= x.getStockMinimo()).count());
            new pe.edu.upeu.sysventas.components.TableViewHelper<>()
                .configure(
                    recent,
                    ctx.reports.report(
                        "Stock bajo", LocalDate.now().minusYears(1), LocalDate.now(), null),
                    pe.edu.upeu.sysventas.components.ReportColumns.forReport("Stock bajo"));
          } else {
            label3.setText("COMPRAS / VENTAS DEL MES");
            var rows =
                ctx.reports.report(
                    "Ventas por fecha", LocalDate.now().withDayOfMonth(1), LocalDate.now(), null);
            metric3.setText("" + rows.size());
            new pe.edu.upeu.sysventas.components.TableViewHelper<>()
                .configure(
                    recent,
                    rows,
                    pe.edu.upeu.sysventas.components.ReportColumns.forReport("Ventas por fecha"));
          }
        });
  }

  @FXML
  public void collection() {
    SysVentas.page("catalogo", "Colección urbana");
  }

  @FXML
  public void reports() {
    SysVentas.page("reportes", "Consultas e historial");
  }
}
