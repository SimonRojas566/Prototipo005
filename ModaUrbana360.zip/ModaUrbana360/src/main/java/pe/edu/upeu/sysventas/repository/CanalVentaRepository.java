package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.CanalVenta;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para canal_venta. No abre conexiones dentro de una transacción. */
public class CanalVentaRepository extends AbstractJdbcRepository<CanalVenta> {
  public CanalVentaRepository(SqlRepository db) {
    super(db, "canal_venta", "id_canal");
  }

  @Override
  public CanalVenta fromRow(Map<String, Object> row) {
    CanalVenta entity = new CanalVenta();
    if (row.containsKey("id_canal")) entity.setIdCanal(SqlHelper.longValue(row.get("id_canal")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(CanalVenta entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_canal", entity.getIdCanal());
    row.put("nombre", entity.getNombre());
    return row;
  }
}
