package pe.edu.upeu.sysventas.enums;

public enum EstadoRegistro {
  ACTIVO("Activo"),
  INACTIVO("Inactivo");
  private final String codigo;

  EstadoRegistro(String codigo) {
    this.codigo = codigo;
  }

  public String getCodigo() {
    return codigo;
  }

  public static EstadoRegistro fromCodigo(String codigo) {
    for (EstadoRegistro value : values()) {
      if (value.codigo.equals(codigo)) return value;
    }
    throw new IllegalArgumentException("Código de EstadoRegistro desconocido: " + codigo);
  }
}
