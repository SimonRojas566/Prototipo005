package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla genero. Las relaciones se identifican mediante sus claves foráneas. */
public class Genero {
  private Long idGenero = null;
  private String nombre = null;

  public Genero() {}

  public Long getIdGenero() {
    return idGenero;
  }

  public void setIdGenero(Long idGenero) {
    this.idGenero = idGenero;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
}
