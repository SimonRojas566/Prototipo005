package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/** Entidad de la tabla venta_pago. Las relaciones se identifican mediante sus claves foráneas. */
public class VentaPago {
  private Long idVentaPago = null;
  private Long idVenta = null;
  private Long idMetodoPago = null;
  private BigDecimal monto = BigDecimal.ZERO;
  private String referencia = null;

  public VentaPago() {}

  public Long getIdVentaPago() {
    return idVentaPago;
  }

  public void setIdVentaPago(Long idVentaPago) {
    this.idVentaPago = idVentaPago;
  }

  public Long getIdVenta() {
    return idVenta;
  }

  public void setIdVenta(Long idVenta) {
    this.idVenta = idVenta;
  }

  public Long getIdMetodoPago() {
    return idMetodoPago;
  }

  public void setIdMetodoPago(Long idMetodoPago) {
    this.idMetodoPago = idMetodoPago;
  }

  public BigDecimal getMonto() {
    return monto;
  }

  public void setMonto(BigDecimal monto) {
    this.monto = monto;
  }

  public String getReferencia() {
    return referencia;
  }

  public void setReferencia(String referencia) {
    this.referencia = referencia;
  }
}
