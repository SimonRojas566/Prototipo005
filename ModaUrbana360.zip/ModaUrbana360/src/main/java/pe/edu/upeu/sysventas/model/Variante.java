package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/** Entidad de la tabla variante. Las relaciones se identifican mediante sus claves foráneas. */
public class Variante {
  private Long idVariante = null;
  private Long idProducto = null;
  private String talla = null;
  private String color = null;
  private String sku = null;
  private BigDecimal costo = BigDecimal.ZERO;
  private BigDecimal precioVenta = BigDecimal.ZERO;
  private Integer stockActual = 0;
  private Integer stockMinimo = 0;

  public Variante() {}

  public Long getIdVariante() {
    return idVariante;
  }

  public void setIdVariante(Long idVariante) {
    this.idVariante = idVariante;
  }

  public Long getIdProducto() {
    return idProducto;
  }

  public void setIdProducto(Long idProducto) {
    this.idProducto = idProducto;
  }

  public String getTalla() {
    return talla;
  }

  public void setTalla(String talla) {
    this.talla = talla;
  }

  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

  public String getSku() {
    return sku;
  }

  public void setSku(String sku) {
    this.sku = sku;
  }

  public BigDecimal getCosto() {
    return costo;
  }

  public void setCosto(BigDecimal costo) {
    this.costo = costo;
  }

  public BigDecimal getPrecioVenta() {
    return precioVenta;
  }

  public void setPrecioVenta(BigDecimal precioVenta) {
    this.precioVenta = precioVenta;
  }

  public Integer getStockActual() {
    return stockActual;
  }

  public void setStockActual(Integer stockActual) {
    this.stockActual = stockActual;
  }

  public Integer getStockMinimo() {
    return stockMinimo;
  }

  public void setStockMinimo(Integer stockMinimo) {
    this.stockMinimo = stockMinimo;
  }
}
