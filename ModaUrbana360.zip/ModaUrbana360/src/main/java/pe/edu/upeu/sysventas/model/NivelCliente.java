package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/**
 * Entidad de la tabla nivel_cliente. Las relaciones se identifican mediante sus claves foráneas.
 */
public class NivelCliente {
  private Long idNivel = null;
  private String nombre = null;
  private BigDecimal descuentoPct = BigDecimal.ZERO;
  private Integer puntosMinimos = 0;

  public NivelCliente() {}

  public Long getIdNivel() {
    return idNivel;
  }

  public void setIdNivel(Long idNivel) {
    this.idNivel = idNivel;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public BigDecimal getDescuentoPct() {
    return descuentoPct;
  }

  public void setDescuentoPct(BigDecimal descuentoPct) {
    this.descuentoPct = descuentoPct;
  }

  public Integer getPuntosMinimos() {
    return puntosMinimos;
  }

  public void setPuntosMinimos(Integer puntosMinimos) {
    this.puntosMinimos = puntosMinimos;
  }
}
