package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/** Entidad de la tabla compra. Las relaciones se identifican mediante sus claves foráneas. */
public class Compra {
  private Long idCompra = null;
  private String serie = null;
  private String numDoc = null;
  private String tipoDoc = null;
  private LocalDate fechaComp = null;
  private LocalDate fechaReg = null;
  private BigDecimal precioBase = BigDecimal.ZERO;
  private BigDecimal igv = BigDecimal.ZERO;
  private BigDecimal precioTotal = BigDecimal.ZERO;
  private Long idProveedor = null;
  private Long idUsuario = null;
  private String estado = "Confirmada";

  public Compra() {}

  public Long getIdCompra() {
    return idCompra;
  }

  public void setIdCompra(Long idCompra) {
    this.idCompra = idCompra;
  }

  public String getSerie() {
    return serie;
  }

  public void setSerie(String serie) {
    this.serie = serie;
  }

  public String getNumDoc() {
    return numDoc;
  }

  public void setNumDoc(String numDoc) {
    this.numDoc = numDoc;
  }

  public String getTipoDoc() {
    return tipoDoc;
  }

  public void setTipoDoc(String tipoDoc) {
    this.tipoDoc = tipoDoc;
  }

  public LocalDate getFechaComp() {
    return fechaComp;
  }

  public void setFechaComp(LocalDate fechaComp) {
    this.fechaComp = fechaComp;
  }

  public LocalDate getFechaReg() {
    return fechaReg;
  }

  public void setFechaReg(LocalDate fechaReg) {
    this.fechaReg = fechaReg;
  }

  public BigDecimal getPrecioBase() {
    return precioBase;
  }

  public void setPrecioBase(BigDecimal precioBase) {
    this.precioBase = precioBase;
  }

  public BigDecimal getIgv() {
    return igv;
  }

  public void setIgv(BigDecimal igv) {
    this.igv = igv;
  }

  public BigDecimal getPrecioTotal() {
    return precioTotal;
  }

  public void setPrecioTotal(BigDecimal precioTotal) {
    this.precioTotal = precioTotal;
  }

  public Long getIdProveedor() {
    return idProveedor;
  }

  public void setIdProveedor(Long idProveedor) {
    this.idProveedor = idProveedor;
  }

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }
}
