package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Promocion;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para promocion. No abre conexiones dentro de una transacción. */
public class PromocionRepository extends AbstractJdbcRepository<Promocion> {
  public PromocionRepository(SqlRepository db) {
    super(db, "promocion", "id_promocion");
  }

  @Override
  public Promocion fromRow(Map<String, Object> row) {
    Promocion entity = new Promocion();
    if (row.containsKey("id_promocion"))
      entity.setIdPromocion(SqlHelper.longValue(row.get("id_promocion")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    if (row.containsKey("tipo")) entity.setTipo(SqlHelper.textValue(row.get("tipo")));
    if (row.containsKey("valor")) entity.setValor(SqlHelper.decimalValue(row.get("valor")));
    if (row.containsKey("fecha_inicio"))
      entity.setFechaInicio(SqlHelper.dateValue(row.get("fecha_inicio")));
    if (row.containsKey("fecha_fin")) entity.setFechaFin(SqlHelper.dateValue(row.get("fecha_fin")));
    if (row.containsKey("id_categoria"))
      entity.setIdCategoria(SqlHelper.longValue(row.get("id_categoria")));
    if (row.containsKey("id_marca")) entity.setIdMarca(SqlHelper.longValue(row.get("id_marca")));
    if (row.containsKey("id_producto"))
      entity.setIdProducto(SqlHelper.longValue(row.get("id_producto")));
    if (row.containsKey("estado")) entity.setEstado(SqlHelper.textValue(row.get("estado")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Promocion entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_promocion", entity.getIdPromocion());
    row.put("nombre", entity.getNombre());
    row.put("tipo", entity.getTipo());
    row.put("valor", entity.getValor());
    row.put("fecha_inicio", entity.getFechaInicio());
    row.put("fecha_fin", entity.getFechaFin());
    row.put("id_categoria", entity.getIdCategoria());
    row.put("id_marca", entity.getIdMarca());
    row.put("id_producto", entity.getIdProducto());
    row.put("estado", entity.getEstado());
    return row;
  }

  public List<Promocion> findVigentes(Connection c, Long product, Long brand, Long category)
      throws SQLException {
    List<Promocion> result = new ArrayList<>();
    for (var row :
        db.query(
            c,
            "SELECT * FROM promocion WHERE estado='Activo' AND fecha_inicio<=CURRENT_DATE AND"
                + " (fecha_fin IS NULL OR fecha_fin>=CURRENT_DATE) AND (id_producto=? OR id_marca=?"
                + " OR id_categoria=?) ORDER BY id_promocion",
            product,
            brand,
            category)) {
      result.add(fromRow(row));
    }
    return result;
  }
}
