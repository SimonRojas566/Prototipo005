package pe.edu.upeu.sysventas.service.impl;

import java.sql.*;
import java.time.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.repository.SqlRepository;
import pe.edu.upeu.sysventas.service.*;

public class ReportServiceImpl implements ReportService {
  private final SqlRepository db;
  private final AuthService auth;

  public ReportServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
  }

  public List<Map<String, Object>> report(String name, LocalDate from, LocalDate to, Long seller) {
    if (from == null || to == null || from.isAfter(to))
      throw new IllegalArgumentException("Selecciona un periodo válido.");
    return db.read(
        c -> {
          long user = auth.require(c, "ADM", "VEN", "ALM", "CLI");
          String role = SessionManager.getInstance().getRole();
          if (("CLI".equals(role) || SessionManager.getInstance().isGuest())
              && !name.equals("Ventas por fecha"))
            throw new SecurityException("Solo puedes consultar tu historial de compras.");
          if ("VEN".equals(role)
              && !Set.of("Ventas por fecha", "Devoluciones y cambios").contains(name))
            throw new SecurityException("Solo puedes consultar tus ventas y devoluciones.");
          if ("ALM".equals(role)
              && !Set.of(
                      "Stock disponible",
                      "Stock bajo",
                      "Compras por proveedor",
                      "Movimientos de inventario")
                  .contains(name))
            throw new SecurityException("Reporte reservado a administración.");
          List<Object> args = new ArrayList<>();
          String where = " WHERE v.fecha_gener>=? AND v.fecha_gener<?";
          args.add(from.atStartOfDay());
          args.add(to.plusDays(1).atStartOfDay());
          if (SessionManager.getInstance().isGuest()) {
            var sales = SessionManager.getInstance().getGuestSales();
            if (sales.isEmpty()) return List.of();
            where +=
                " AND v.id_venta IN ("
                    + String.join(",", Collections.nCopies(sales.size(), "?"))
                    + ")";
            args.addAll(sales);
          } else if (role.equals("VEN")) {
            where += " AND v.id_usuario=?";
            args.add(user);
          } else if (role.equals("CLI")) {
            where += " AND v.id_cliente=(SELECT id_cliente FROM cliente WHERE id_usuario=?)";
            args.add(user);
          } else if (seller != null) {
            where += " AND v.id_usuario=?";
            args.add(seller);
          }
          String joins =
              " FROM venta v JOIN venta_detalle d ON d.id_venta=v.id_venta JOIN variante va ON"
                  + " va.id_variante=d.id_variante JOIN producto p ON p.id_producto=va.id_producto"
                  + " ";
          String valid = where + " AND v.estado='Confirmada'";
          return switch (name) {
            case "Ventas por fecha" ->
                db.query(
                    c,
                    "SELECT v.id_venta,v.serie||'-'||v.num_doc AS"
                        + " comprobante,v.fecha_gener,COALESCE(cl.nombres,'Consumidor final') AS"
                        + " cliente,v.precio_total,v.estado,CASE WHEN"
                        + " u.nombre_usuario='__invitado_sistema' THEN 'Invitado' ELSE"
                        + " u.nombre_usuario END AS"
                        + " responsable,v.precio_base,v.igv,v.descuento_total FROM venta v LEFT"
                        + " JOIN cliente cl ON cl.id_cliente=v.id_cliente JOIN usuario u ON"
                        + " u.id_usuario=v.id_usuario"
                        + where
                        + " ORDER BY v.fecha_gener DESC",
                    args.toArray());
            case "Ventas por vendedor" ->
                db.query(
                    c,
                    "SELECT CASE WHEN u.nombre_usuario='__invitado_sistema' THEN 'Invitado' ELSE"
                        + " u.nombre_usuario END AS vendedor,COUNT(*) AS ventas,SUM(v.precio_total)"
                        + " AS importe_confirmado FROM venta v JOIN usuario u ON"
                        + " u.id_usuario=v.id_usuario"
                        + valid
                        + " GROUP BY u.nombre_usuario ORDER BY importe_confirmado DESC",
                    args.toArray());
            case "Productos más vendidos" ->
                db.query(
                    c,
                    "SELECT p.nombre AS producto,SUM(d.cantidad) AS unidades,SUM(d.subtotal) AS"
                        + " importe_confirmado"
                        + joins
                        + valid
                        + " GROUP BY p.id_producto,p.nombre ORDER BY unidades DESC",
                    args.toArray());
            case "Ventas por marca" ->
                db.query(
                    c,
                    "SELECT m.nombre AS marca,SUM(d.cantidad) AS unidades,SUM(d.subtotal) AS"
                        + " importe_confirmado"
                        + joins
                        + " JOIN marca m ON m.id_marca=p.id_marca"
                        + valid
                        + " GROUP BY m.nombre ORDER BY importe_confirmado DESC",
                    args.toArray());
            case "Ventas por categoría" ->
                db.query(
                    c,
                    "SELECT ca.nombre AS categoria,SUM(d.cantidad) AS unidades,SUM(d.subtotal) AS"
                        + " importe_confirmado"
                        + joins
                        + " JOIN categoria ca ON ca.id_categoria=p.id_categoria"
                        + valid
                        + " GROUP BY ca.nombre ORDER BY importe_confirmado DESC",
                    args.toArray());
            case "Stock disponible", "Stock bajo" -> {
              args.clear();
              yield db.query(
                  c,
                  "SELECT va.id_variante,va.sku,p.nombre AS"
                      + " producto,va.talla,va.color,va.stock_actual,va.stock_minimo,va.precio_venta,p.estado"
                      + " FROM variante va JOIN producto p ON p.id_producto=va.id_producto"
                      + (name.equals("Stock bajo") ? " WHERE va.stock_actual<=va.stock_minimo" : "")
                      + " ORDER BY va.stock_actual,p.nombre");
            }
            case "Compras por proveedor" ->
                db.query(
                    c,
                    "SELECT co.id_compra,co.serie||'-'||co.num_doc AS"
                        + " documento,co.fecha_comp,p.razon_social AS proveedor,CASE WHEN"
                        + " u.nombre_usuario='__invitado_sistema' THEN 'Invitado' ELSE"
                        + " u.nombre_usuario END AS"
                        + " responsable,co.precio_base,co.igv,co.precio_total,co.estado FROM compra"
                        + " co JOIN proveedor p ON p.id_proveedor=co.id_proveedor JOIN usuario u ON"
                        + " u.id_usuario=co.id_usuario WHERE co.fecha_comp BETWEEN ? AND ? ORDER BY"
                        + " co.fecha_comp DESC",
                    from,
                    to);
            case "Movimientos de inventario" ->
                db.query(
                    c,
                    "SELECT m.id_movimiento,m.fecha,va.sku,p.nombre AS"
                        + " producto,m.tipo_movimiento,m.cantidad,m.referencia,CASE WHEN"
                        + " u.nombre_usuario='__invitado_sistema' THEN 'Invitado' ELSE"
                        + " u.nombre_usuario END AS responsable FROM movimiento_stock m JOIN"
                        + " variante va ON va.id_variante=m.id_variante JOIN producto p ON"
                        + " p.id_producto=va.id_producto JOIN usuario u ON"
                        + " u.id_usuario=m.id_usuario WHERE m.fecha>=? AND m.fecha<? ORDER BY"
                        + " m.fecha DESC",
                    from.atStartOfDay(),
                    to.plusDays(1).atStartOfDay());
            case "Historial de operaciones" ->
                db.query(
                    c,
                    "SELECT a.id_auditoria,a.fecha,CASE WHEN u.nombre_usuario='__invitado_sistema'"
                        + " THEN 'Invitado' ELSE u.nombre_usuario END AS"
                        + " responsable,a.accion,a.entidad,a.id_registro,a.detalle FROM auditoria a"
                        + " JOIN usuario u ON u.id_usuario=a.id_usuario WHERE a.fecha>=? AND"
                        + " a.fecha<? ORDER BY a.fecha DESC",
                    from.atStartOfDay(),
                    to.plusDays(1).atStartOfDay());
            case "Devoluciones y cambios" ->
                db.query(
                    c,
                    "SELECT"
                        + " r.id_devolucion,r.id_venta,r.fecha,r.tipo,r.motivo,va.sku,rd.cantidad,vc.sku"
                        + " AS sku_cambio,CASE WHEN u.nombre_usuario='__invitado_sistema' THEN"
                        + " 'Invitado' ELSE u.nombre_usuario END AS responsable FROM devolucion r"
                        + " JOIN devolucion_detalle rd ON rd.id_devolucion=r.id_devolucion JOIN"
                        + " variante va ON va.id_variante=rd.id_variante_devuelta LEFT JOIN"
                        + " variante vc ON vc.id_variante=rd.id_variante_cambio JOIN usuario u ON"
                        + " u.id_usuario=r.id_usuario JOIN venta v ON v.id_venta=r.id_venta"
                        + where
                        + " ORDER BY r.fecha DESC",
                    args.toArray());
            case "Ingresos por método de pago" ->
                db.query(
                    c,
                    "SELECT m.nombre AS metodo_pago,SUM(pa.monto) AS cobros_confirmados FROM venta"
                        + " v JOIN venta_pago pa ON pa.id_venta=v.id_venta JOIN metodo_pago m"
                        + " ON m.id_metodo_pago=pa.id_metodo_pago"
                        + valid
                        + " GROUP BY m.nombre ORDER BY cobros_confirmados DESC",
                    args.toArray());
            default -> throw new IllegalArgumentException("Selecciona un reporte válido.");
          };
        });
  }

  public List<Map<String, Object>> details(long sale) {
    return db.read(
        c -> {
          scope(c, sale);
          return db.query(
              c,
              "SELECT d.id_venta_detalle,va.sku,p.nombre AS"
                  + " producto,d.cantidad,d.pu,d.descuento,d.subtotal,COALESCE((SELECT"
                  + " SUM(rd.cantidad) FROM devolucion_detalle rd WHERE"
                  + " rd.id_venta_detalle=d.id_venta_detalle),0) AS devueltas FROM venta_detalle d"
                  + " JOIN variante va ON va.id_variante=d.id_variante JOIN producto p ON"
                  + " p.id_producto=va.id_producto WHERE d.id_venta=? ORDER BY d.id_venta_detalle",
              sale);
        });
  }

  private pe.edu.upeu.sysventas.dto.comprobante.Comprobante scope(Connection c, long sale)
      throws SQLException {
    long user = auth.require(c, "ADM", "VEN", "CLI");
    if (SessionManager.getInstance().isGuest() && !SessionManager.getInstance().ownsGuestSale(sale))
      throw new SecurityException("Solo puedes consultar las compras de esta sesión de invitado.");
    var comprobante = new ComprobanteRepository(db).findByVenta(c, sale);
    var venta = comprobante.getVenta();
    String role = SessionManager.getInstance().getRole();
    if (role.equals("VEN") && venta.getIdUsuario() != user) {
      throw new SecurityException("Solo puedes consultar tus ventas.");
    }
    if (role.equals("CLI")) {
      var cliente = new ClienteRepository(db).findByUsuario(c, user);
      if (!Objects.equals(venta.getIdCliente(), cliente.getIdCliente())) {
        throw new SecurityException("Esta compra pertenece a otro cliente.");
      }
    }
    return comprobante;
  }

  @Override
  public pe.edu.upeu.sysventas.dto.comprobante.Comprobante comprobante(long sale) {
    return db.read(c -> scope(c, sale));
  }

  @Override
  public String receipt(long sale) {
    return new pe.edu.upeu.sysventas.components.comprob.ComprobanteTextService()
        .format(comprobante(sale));
  }
}
