package pe.edu.upeu.sysventas.components.comprob;

import java.nio.file.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javafx.geometry.*;
import javafx.print.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.transform.Scale;
import javafx.stage.FileChooser;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.dto.comprobante.*;
import pe.edu.upeu.sysventas.enums.TipoDocumento;
import pe.edu.upeu.sysventas.util.*;

/** Hoja blanca reutilizada por venta e historial. No contiene imágenes. */
public class ComprobanteView {
  public VBox createContent(Comprobante comprobante) {
    Label title = new Label("Comprobante de pago");
    Region spacer = new Region();
    HBox.setHgrow(spacer, Priority.ALWAYS);
    Button print = new Button("Imprimir");
    print.setOnAction(event -> Ui.run(() -> print(comprobante)));
    Button pdf = new Button("Exportar PDF");
    pdf.setId("exportPdf");
    pdf.getStyleClass().add("primary");
    pdf.setOnAction(event -> Ui.run(() -> exportPdf(comprobante)));
    HBox toolbar = new HBox(12, title, spacer, print, pdf);
    toolbar.setAlignment(Pos.CENTER_LEFT);
    ScrollPane preview = new ScrollPane(createPage(comprobante, comprobante.getItems(), true));
    preview.setId("comprobantePreview");
    preview.setFitToWidth(true);
    preview.setPrefViewportWidth(950);
    preview.setPrefViewportHeight(610);
    preview.setStyle("-fx-background:#dedde0;-fx-background-color:#dedde0;-fx-padding:18;");
    VBox content = new VBox(12, toolbar, preview);
    pe.edu.upeu.sysventas.util.I18n.apply(content);
    return content;
  }

  public VBox createPage(Comprobante comprobante, List<ItemComprobante> items, boolean last) {
    var venta = comprobante.getVenta();
    VBox page = new VBox(18);
    page.setId("comprobantePaper");
    page.setPadding(new Insets(28));
    page.setPrefWidth(900);
    page.setStyle("-fx-background-color:white;");
    VBox business =
        new VBox(
            6,
            label("MODA URBANA 360", 18, true),
            label("Tienda de ropa", 12, false),
            label("Sistema académico de ventas e inventario", 12, false));
    VBox document =
        new VBox(
            7,
            label(
                TipoDocumento.fromStored(venta.getTipoDoc()).getTitulo().toUpperCase(Locale.ROOT),
                16,
                true),
            label("DEMONSTRATIVA", 12, true),
            label(venta.getSerie() + " - " + venta.getNumDoc(), 15, true),
            label(
                "Fecha: "
                    + venta.getFechaGener().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
                    + " | PEN",
                12,
                false));
    document.setAlignment(Pos.CENTER);
    document.setPadding(new Insets(15));
    document.setStyle("-fx-border-color:#663e87;-fx-border-width:2;");
    business.setMaxWidth(Double.MAX_VALUE);
    HBox.setHgrow(business, Priority.ALWAYS);
    HBox header = new HBox(20, business, document);
    GridPane customer = new GridPane();
    customer.setHgap(25);
    customer.setVgap(9);
    customer.setPadding(new Insets(12));
    customer.setStyle("-fx-border-color:#e0dce6;");
    customer.addRow(
        0, label("Documento", 12, true), label(comprobante.getDocumentoCliente(), 12, false));
    customer.addRow(1, label("Cliente", 12, true), label(comprobante.getCliente(), 12, false));
    customer.addRow(
        2, label("Responsable", 12, true), label(comprobante.getResponsable(), 12, false));
    GridPane detail = new GridPane();
    detail.setMaxWidth(Double.MAX_VALUE);
    for (double width : new double[] {8, 40, 18, 16, 18}) {
      ColumnConstraints column = new ColumnConstraints();
      column.setPercentWidth(width);
      detail.getColumnConstraints().add(column);
    }
    String[] titles = {"CANT.", "DESCRIPCIÓN", "P. UNIT.", "DESCUENTO", "SUBTOTAL"};
    for (int i = 0; i < titles.length; i++) detail.add(tableCell(titles[i], true, i > 1), i, 0);
    int row = 1;
    for (ItemComprobante item : items) {
      detail.add(tableCell(item.getCantidad().toString(), false, false), 0, row);
      detail.add(tableCell(item.getNombre() + "\n" + item.getSku(), false, false), 1, row);
      detail.add(tableCell(Money.soles(item.getPrecioUnitario()), false, true), 2, row);
      detail.add(tableCell(Money.soles(item.getDescuento()), false, true), 3, row);
      detail.add(tableCell(Money.soles(item.getSubtotal()), false, true), 4, row++);
    }
    page.getChildren()
        .addAll(
            header,
            label("DATOS DEL CLIENTE", 13, true),
            customer,
            label("DETALLE", 13, true),
            detail);
    if (last) {
      GridPane totals = new GridPane();
      totals.setHgap(28);
      totals.setVgap(9);
      totals.addRow(
          0, label("Op. gravadas", 12, true), label(Money.soles(venta.getPrecioBase()), 12, false));
      totals.addRow(
          1, label("IGV incluido", 12, true), label(Money.soles(venta.getIgv()), 12, false));
      totals.addRow(
          2,
          label("Descuento", 12, true),
          label(Money.soles(venta.getDescuentoTotal()), 12, false));
      totals.addRow(
          3, label("TOTAL", 16, true), label(Money.soles(venta.getPrecioTotal()), 16, true));
      totals.setPadding(new Insets(14));
      totals.setStyle("-fx-background-color:#f3eef7;");
      totals.setAlignment(Pos.CENTER_RIGHT);
      page.getChildren()
          .addAll(
              label("Estado: " + venta.getEstado(), 12, true),
              totals,
              label("PAGOS DECLARADOS", 12, true));
      for (PagoComprobante pago : comprobante.getPagos())
        page.getChildren()
            .add(
                label(
                    pago.getNombre()
                        + ": "
                        + Money.soles(pago.getMonto())
                        + (pago.getReferencia().isBlank() ? "" : " · " + pago.getReferencia()),
                    12,
                    false));
      if (!comprobante.getDevoluciones().isEmpty()) {
        page.getChildren().add(label("DEVOLUCIONES Y CAMBIOS", 12, true));
        for (DevolucionComprobante item : comprobante.getDevoluciones())
          page.getChildren()
              .add(
                  label(
                      "#"
                          + item.getIdDevolucion()
                          + " · "
                          + item.getTipo()
                          + " · "
                          + item.getCantidad()
                          + " unidades · "
                          + item.getSku(),
                      12,
                      false));
      }
    }
    Label footer =
        label(
            "DOCUMENTO DEMOSTRATIVO SIN VALIDEZ TRIBUTARIA\n"
                + "Aplicación académica local · Sin emisión ante SUNAT",
            11,
            false);
    footer.setMaxWidth(Double.MAX_VALUE);
    footer.setAlignment(Pos.CENTER);
    page.getChildren().add(footer);
    return page;
  }

  private Label label(String text, int size, boolean bold) {
    Label label = new Label(text);
    pe.edu.upeu.sysventas.util.I18n.bind(label.textProperty());
    label.setWrapText(true);
    label.setStyle(
        "-fx-text-fill:#2d2637;-fx-font-size:"
            + size
            + "px;-fx-font-weight:"
            + (bold ? "bold" : "normal")
            + ";");
    return label;
  }

  private Label tableCell(String text, boolean header, boolean right) {
    Label label = label(text, 12, header);
    label.setMaxWidth(Double.MAX_VALUE);
    label.setMinHeight(40);
    label.setPadding(new Insets(9));
    label.setAlignment(right ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
    label.setStyle(
        label.getStyle()
            + "-fx-border-color:#e6e0ec;-fx-background-color:"
            + (header ? "#663e87" : "#ffffff")
            + ";-fx-text-fill:"
            + (header ? "white" : "#2d2637")
            + ";");
    return label;
  }

  public void exportPdf(Comprobante comprobante) {
    FileChooser chooser = new FileChooser();
    chooser.setTitle(pe.edu.upeu.sysventas.util.I18n.t("Exportar comprobante a PDF"));
    chooser.setInitialFileName(
        comprobante.getVenta().getSerie() + "-" + comprobante.getVenta().getNumDoc() + ".pdf");
    chooser
        .getExtensionFilters()
        .add(
            new FileChooser.ExtensionFilter(
                pe.edu.upeu.sysventas.util.I18n.t("Documento PDF"), "*.pdf"));
    var file = chooser.showSaveDialog(SysVentas.stage());
    if (file == null) return;
    Path target = file.toPath();
    if (!target.toString().toLowerCase(Locale.ROOT).endsWith(".pdf"))
      target = Path.of(target + ".pdf");
    Path temporary = null;
    try {
      temporary = Files.createTempFile(target.toAbsolutePath().getParent(), "comprobante-", ".pdf");
      new ComprobantePdfService().exportar(comprobante, temporary);
      Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
      Ui.info("Comprobante PDF guardado.");
    } catch (Exception error) {
      throw new IllegalStateException("No se pudo exportar el comprobante PDF.", error);
    } finally {
      if (temporary != null)
        try {
          Files.deleteIfExists(temporary);
        } catch (java.io.IOException ignored) {
        }
    }
  }

  private void print(Comprobante comprobante) {
    PrinterJob job = PrinterJob.createPrinterJob();
    if (job == null)
      throw new IllegalStateException("No hay una impresora disponible. Puedes exportar a PDF.");
    if (!job.showPrintDialog(SysVentas.stage())) return;
    PageLayout layout = job.getJobSettings().getPageLayout();
    int count = comprobante.getItems().size();
    for (int start = 0; start < Math.max(1, count); start += 12) {
      int end = Math.min(start + 12, count);
      VBox page = createPage(comprobante, comprobante.getItems().subList(start, end), end == count);
      new Scene(page);
      page.applyCss();
      page.autosize();
      page.layout();
      double scale =
          Math.min(
              layout.getPrintableWidth() / page.getWidth(),
              layout.getPrintableHeight() / page.getHeight());
      page.getTransforms().add(new Scale(scale, scale));
      if (!job.printPage(layout, page)) {
        job.cancelJob();
        throw new IllegalStateException("No se pudo completar la impresión.");
      }
    }
    job.endJob();
  }

  public void show(Comprobante comprobante) {
    Dialog<Void> dialog = new Dialog<>();
    dialog.setTitle("Visualizar comprobante");
    dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
    dialog.getDialogPane().setContent(createContent(comprobante));
    Ui.style(dialog);
    dialog.setResizable(true);
    dialog.showAndWait();
  }
}
