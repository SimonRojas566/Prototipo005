package pe.edu.upeu.sysventas.dto;

import java.math.BigDecimal;
import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class Payment {
  private final long metodo;
  private final BigDecimal monto;
  private final String referencia;

  public Payment(long metodo, BigDecimal monto, String referencia) {
    if (metodo < 1 || monto == null || monto.signum() <= 0 || monto.scale() > 2)
      throw new IllegalArgumentException(
          "El pago debe ser positivo y tener como máximo dos decimales.");
    referencia = referencia == null ? "" : referencia.trim();
    if (metodo != 1 && referencia.isBlank())
      throw new IllegalArgumentException("Ingresa una referencia para el pago digital.");
    this.metodo = metodo;
    this.monto = monto;
    this.referencia = referencia;
  }

  public long getMetodo() {
    return metodo;
  }

  public BigDecimal getMonto() {
    return monto;
  }

  public String getReferencia() {
    return referencia;
  }
}
