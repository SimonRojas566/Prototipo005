package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.MovimientoStock;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para movimiento_stock. No abre conexiones dentro de una transacción. */
public class MovimientoStockRepository extends AbstractJdbcRepository<MovimientoStock> {
  public MovimientoStockRepository(SqlRepository db) {
    super(db, "movimiento_stock", "id_movimiento");
  }

  @Override
  public MovimientoStock fromRow(Map<String, Object> row) {
    MovimientoStock entity = new MovimientoStock();
    if (row.containsKey("id_movimiento"))
      entity.setIdMovimiento(SqlHelper.longValue(row.get("id_movimiento")));
    if (row.containsKey("id_variante"))
      entity.setIdVariante(SqlHelper.longValue(row.get("id_variante")));
    if (row.containsKey("tipo_movimiento"))
      entity.setTipoMovimiento(SqlHelper.textValue(row.get("tipo_movimiento")));
    if (row.containsKey("cantidad"))
      entity.setCantidad(SqlHelper.integerValue(row.get("cantidad")));
    if (row.containsKey("fecha")) entity.setFecha(SqlHelper.timestampValue(row.get("fecha")));
    if (row.containsKey("referencia"))
      entity.setReferencia(SqlHelper.textValue(row.get("referencia")));
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(MovimientoStock entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_movimiento", entity.getIdMovimiento());
    row.put("id_variante", entity.getIdVariante());
    row.put("tipo_movimiento", entity.getTipoMovimiento());
    row.put("cantidad", entity.getCantidad());
    row.put("fecha", entity.getFecha());
    row.put("referencia", entity.getReferencia());
    row.put("id_usuario", entity.getIdUsuario());
    return row;
  }

  public void registrar(
      Connection c, long variant, String type, int quantity, String reference, long user)
      throws SQLException {
    MovimientoStock movimiento = new MovimientoStock();
    movimiento.setIdVariante(variant);
    movimiento.setTipoMovimiento(type);
    movimiento.setCantidad(quantity);
    movimiento.setReferencia(reference);
    movimiento.setIdUsuario(user);
    new MovimientoStockRepository(db).insert(c, movimiento);
  }
}
