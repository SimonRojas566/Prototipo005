package pe.edu.upeu.sysventas.components;

import java.util.List;

/** Cabeceras de consultas sin resultados, para que las tablas sigan siendo comprensibles. */
public final class ReportColumns {
  private ReportColumns() {}

  public static List<String> forReport(String name) {
    return switch (name) {
      case "Ventas por fecha" ->
          List.of(
              "id_venta",
              "comprobante",
              "fecha_gener",
              "cliente",
              "precio_total",
              "estado",
              "responsable");
      case "Stock disponible", "Stock bajo" ->
          List.of(
              "sku",
              "producto",
              "talla",
              "color",
              "stock_actual",
              "stock_minimo",
              "precio_venta",
              "estado");
      case "Compras por proveedor" ->
          List.of("documento", "fecha_comp", "proveedor", "precio_total", "estado");
      case "Movimientos de inventario" ->
          List.of(
              "fecha",
              "sku",
              "producto",
              "tipo_movimiento",
              "cantidad",
              "referencia",
              "responsable");
      case "Historial de operaciones" ->
          List.of("fecha", "responsable", "accion", "entidad", "detalle");
      case "Devoluciones y cambios" ->
          List.of("id_devolucion", "id_venta", "fecha", "tipo", "motivo", "sku", "cantidad");
      case "Ingresos por método de pago" -> List.of("metodo_pago", "cobros_confirmados");
      case "Ventas por vendedor" -> List.of("vendedor", "ventas", "importe_confirmado");
      case "Ventas por marca" -> List.of("marca", "unidades", "importe_confirmado");
      case "Ventas por categoría" -> List.of("categoria", "unidades", "importe_confirmado");
      default -> List.of("producto", "unidades", "importe_confirmado");
    };
  }
}
