package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/**
 * Entidad de la tabla venta_detalle. Las relaciones se identifican mediante sus claves foráneas.
 */
public class VentaDetalle {
  private Long idVentaDetalle = null;
  private Long idVenta = null;
  private Long idVariante = null;
  private BigDecimal pu = BigDecimal.ZERO;
  private Integer cantidad = 0;
  private BigDecimal descuento = BigDecimal.ZERO;
  private BigDecimal subtotal = BigDecimal.ZERO;
  private Long idPromocion = null;

  public VentaDetalle() {}

  public Long getIdVentaDetalle() {
    return idVentaDetalle;
  }

  public void setIdVentaDetalle(Long idVentaDetalle) {
    this.idVentaDetalle = idVentaDetalle;
  }

  public Long getIdVenta() {
    return idVenta;
  }

  public void setIdVenta(Long idVenta) {
    this.idVenta = idVenta;
  }

  public Long getIdVariante() {
    return idVariante;
  }

  public void setIdVariante(Long idVariante) {
    this.idVariante = idVariante;
  }

  public BigDecimal getPu() {
    return pu;
  }

  public void setPu(BigDecimal pu) {
    this.pu = pu;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public void setCantidad(Integer cantidad) {
    this.cantidad = cantidad;
  }

  public BigDecimal getDescuento() {
    return descuento;
  }

  public void setDescuento(BigDecimal descuento) {
    this.descuento = descuento;
  }

  public BigDecimal getSubtotal() {
    return subtotal;
  }

  public void setSubtotal(BigDecimal subtotal) {
    this.subtotal = subtotal;
  }

  public Long getIdPromocion() {
    return idPromocion;
  }

  public void setIdPromocion(Long idPromocion) {
    this.idPromocion = idPromocion;
  }
}
