package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Proveedor;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para proveedor. No abre conexiones dentro de una transacción. */
public class ProveedorRepository extends AbstractJdbcRepository<Proveedor> {
  public ProveedorRepository(SqlRepository db) {
    super(db, "proveedor", "id_proveedor");
  }

  @Override
  public Proveedor fromRow(Map<String, Object> row) {
    Proveedor entity = new Proveedor();
    if (row.containsKey("id_proveedor"))
      entity.setIdProveedor(SqlHelper.longValue(row.get("id_proveedor")));
    if (row.containsKey("documento"))
      entity.setDocumento(SqlHelper.textValue(row.get("documento")));
    if (row.containsKey("razon_social"))
      entity.setRazonSocial(SqlHelper.textValue(row.get("razon_social")));
    if (row.containsKey("celular")) entity.setCelular(SqlHelper.textValue(row.get("celular")));
    if (row.containsKey("correo")) entity.setCorreo(SqlHelper.textValue(row.get("correo")));
    if (row.containsKey("direccion"))
      entity.setDireccion(SqlHelper.textValue(row.get("direccion")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Proveedor entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_proveedor", entity.getIdProveedor());
    row.put("documento", entity.getDocumento());
    row.put("razon_social", entity.getRazonSocial());
    row.put("celular", entity.getCelular());
    row.put("correo", entity.getCorreo());
    row.put("direccion", entity.getDireccion());
    return row;
  }
}
