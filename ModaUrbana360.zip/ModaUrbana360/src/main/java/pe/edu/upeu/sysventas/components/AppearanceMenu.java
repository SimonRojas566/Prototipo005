package pe.edu.upeu.sysventas.components;

import javafx.scene.control.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.util.*;

/** Opciones de presentación disponibles tanto en el login como en la ventana principal. */
public final class AppearanceMenu {
  private AppearanceMenu() {}

  public static void addTo(MenuBar bar) {
    Menu styles = new Menu("Cambiar estilo");
    styles.setId("styleMenu");
    ToggleGroup themes = new ToggleGroup();
    for (UiTheme theme : UiTheme.values()) {
      RadioMenuItem item = new RadioMenuItem(theme.getTitle());
      item.setId("theme-" + theme.name());
      item.setToggleGroup(themes);
      item.setSelected(UiSettings.getTheme() == theme);
      item.setOnAction(event -> Ui.run(() -> UiSettings.select(theme, UiSettings.getLanguage())));
      styles.getItems().add(item);
    }
    Menu languages = new Menu("Idioma");
    languages.setId("languageMenu");
    ToggleGroup locales = new ToggleGroup();
    for (UiLanguage language : UiLanguage.values()) {
      RadioMenuItem item = new RadioMenuItem(language.getTitle());
      item.setId("language-" + language.name());
      item.setToggleGroup(locales);
      item.setSelected(UiSettings.getLanguage() == language);
      item.setOnAction(event -> Ui.run(() -> UiSettings.select(UiSettings.getTheme(), language)));
      languages.getItems().add(item);
    }
    bar.getMenus().addAll(styles, languages);
  }
}
