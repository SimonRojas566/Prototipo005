package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.config.DatabaseConfig;

/** SQL parametrizado. Las conexiones compartidas pertenecen al servicio transaccional. */
public class SqlRepository {
  @FunctionalInterface
  public interface Work<T> {
    T run(Connection c) throws Exception;
  }

  public <T> T read(Work<T> work) {
    try (Connection c = DatabaseConfig.getConnection()) {
      return work.run(c);
    } catch (Exception e) {
      throw failure(e);
    }
  }

  public <T> T transaction(Work<T> work) {
    try (Connection c = DatabaseConfig.getConnection()) {
      c.setAutoCommit(false);
      try {
        T result = work.run(c);
        c.commit();
        return result;
      } catch (Exception e) {
        c.rollback();
        throw e;
      }
    } catch (Exception e) {
      throw failure(e);
    }
  }

  public static RuntimeException failure(Exception e) {
    if (e instanceof IllegalArgumentException
        || e instanceof SecurityException
        || e instanceof pe.edu.upeu.sysventas.exceptions.DatabaseException)
      return (RuntimeException) e;
    if (e instanceof SQLException s) {
      if ("23505".equals(s.getSQLState()))
        return new IllegalArgumentException(
            "Ya existe un registro con ese código, documento o combinación.", e);
      if (("23503".equals(s.getSQLState()) || "23506".equals(s.getSQLState())))
        return new IllegalArgumentException(
            "El registro está relacionado con otra operación. Revisa la selección.", e);
      if (("23514".equals(s.getSQLState()) || "23513".equals(s.getSQLState()))
          || "23502".equals(s.getSQLState()))
        return new IllegalArgumentException("Los datos no cumplen las reglas de integridad.", e);
    }
    return new pe.edu.upeu.sysventas.exceptions.DatabaseException(
        "No se pudo completar la operación. Revisa que la carpeta del proyecto permita guardar la"
            + " base H2.",
        e);
  }

  public List<Map<String, Object>> query(Connection c, String sql, Object... args)
      throws SQLException {
    try (PreparedStatement p = c.prepareStatement(sql)) {
      bind(p, args);
      try (ResultSet rs = p.executeQuery()) {
        List<Map<String, Object>> out = new ArrayList<>();
        ResultSetMetaData m = rs.getMetaData();
        while (rs.next()) {
          Map<String, Object> r = new LinkedHashMap<>();
          for (int i = 1; i <= m.getColumnCount(); i++) r.put(m.getColumnLabel(i), rs.getObject(i));
          out.add(r);
        }
        return out;
      }
    }
  }

  public Map<String, Object> one(Connection c, String sql, Object... args) throws SQLException {
    var rows = query(c, sql, args);
    if (rows.isEmpty())
      throw new IllegalArgumentException("El registro no existe o no está disponible.");
    return rows.getFirst();
  }

  public int update(Connection c, String sql, Object... args) throws SQLException {
    try (PreparedStatement p = c.prepareStatement(sql)) {
      bind(p, args);
      return p.executeUpdate();
    }
  }

  /** Recupera la identidad generada mediante JDBC, sin SQL específico de PostgreSQL. */
  public long id(Connection c, String sql, String column, Object... args) throws SQLException {
    try (PreparedStatement statement = c.prepareStatement(sql, new String[] {column})) {
      bind(statement, args);
      statement.executeUpdate();
      try (ResultSet keys = statement.getGeneratedKeys()) {
        if (!keys.next()) throw new SQLException("No se recibió la identidad del registro.");
        return keys.getLong(1);
      }
    }
  }

  private void bind(PreparedStatement p, Object... args) throws SQLException {
    for (int i = 0; i < args.length; i++) p.setObject(i + 1, args[i]);
  }

  public List<Map<String, Object>> query(String sql, Object... args) {
    return read(c -> query(c, sql, args));
  }

  public void audit(Connection c, long user, String action, String entity, long id, String detail)
      throws SQLException {
    pe.edu.upeu.sysventas.model.Auditoria registro = new pe.edu.upeu.sysventas.model.Auditoria();
    registro.setIdUsuario(user);
    registro.setAccion(action);
    registro.setEntidad(entity);
    registro.setIdRegistro(id);
    registro.setDetalle(detail);
    new AuditoriaRepository(this).insert(c, registro);
  }
}
