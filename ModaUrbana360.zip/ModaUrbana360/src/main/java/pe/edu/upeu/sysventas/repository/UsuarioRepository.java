package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Usuario;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para usuario. No abre conexiones dentro de una transacción. */
public class UsuarioRepository extends AbstractJdbcRepository<Usuario> {
  public UsuarioRepository(SqlRepository db) {
    super(db, "usuario", "id_usuario");
  }

  @Override
  public Usuario fromRow(Map<String, Object> row) {
    Usuario entity = new Usuario();
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    if (row.containsKey("nombre_usuario"))
      entity.setNombreUsuario(SqlHelper.textValue(row.get("nombre_usuario")));
    if (row.containsKey("hash_clave"))
      entity.setHashClave(SqlHelper.textValue(row.get("hash_clave")));
    if (row.containsKey("estado")) entity.setEstado(SqlHelper.textValue(row.get("estado")));
    if (row.containsKey("id_perfil")) entity.setIdPerfil(SqlHelper.longValue(row.get("id_perfil")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Usuario entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_usuario", entity.getIdUsuario());
    row.put("nombre_usuario", entity.getNombreUsuario());
    row.put("hash_clave", entity.getHashClave());
    row.put("estado", entity.getEstado());
    row.put("id_perfil", entity.getIdPerfil());
    return row;
  }

  public Optional<Usuario> findByUsername(Connection c, String username) throws SQLException {
    var rows = db.query(c, "SELECT * FROM usuario WHERE nombre_usuario=?", username);
    return rows.isEmpty() ? Optional.empty() : Optional.of(fromRow(rows.getFirst()));
  }
}
