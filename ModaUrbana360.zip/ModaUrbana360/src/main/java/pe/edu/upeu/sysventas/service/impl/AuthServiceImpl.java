package pe.edu.upeu.sysventas.service.impl;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.repository.SqlRepository;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.Passwords;

public class AuthServiceImpl implements AuthService {
  private final SqlRepository db;

  public AuthServiceImpl(SqlRepository db) {
    this.db = db;
  }

  public void login(String name, String password) {
    logout();
    db.transaction(
        c -> {
          Usuario usuario =
              new UsuarioRepository(db)
                  .findByUsername(c, name.trim())
                  .orElseThrow(
                      () -> new IllegalArgumentException("Usuario o contraseña incorrectos."));
          if ("__invitado_sistema".equals(usuario.getNombreUsuario()))
            throw new IllegalArgumentException("Utiliza el botón Entrar como invitado.");
          if (!EstadoRegistro.ACTIVO.getCodigo().equals(usuario.getEstado())
              || !Passwords.verify(password, usuario.getHashClave())) {
            throw new IllegalArgumentException("Usuario o contraseña incorrectos.");
          }
          Perfil perfil = new PerfilRepository(db).findById(c, usuario.getIdPerfil());
          Rol rol = Rol.fromCodigo(perfil.getCodigo());
          db.audit(
              c,
              usuario.getIdUsuario(),
              "INGRESO",
              "usuario",
              usuario.getIdUsuario(),
              "Inicio de sesión");
          SessionManager.getInstance()
              .open(
                  usuario.getIdUsuario(),
                  usuario.getNombreUsuario(),
                  perfil.getNombre(),
                  rol.getCodigo());
          return null;
        });
  }

  /** Un actor técnico compartido permite conservar la FK sin crear una cuenta por visitante. */
  public synchronized void guest() {
    logout();
    long actor =
        db.transaction(
            c -> {
              var usuarios = new UsuarioRepository(db);
              var existing = usuarios.findByUsername(c, "__invitado_sistema");
              long id;
              if (existing.isPresent()) {
                id = existing.get().getIdUsuario();
              } else {
                var perfil =
                    new PerfilRepository(db)
                        .findAll(c).stream()
                            .filter(p -> "CLI".equals(p.getCodigo()))
                            .findFirst()
                            .orElseThrow();
                Usuario usuario = new Usuario();
                usuario.setNombreUsuario("__invitado_sistema");
                usuario.setHashClave(Passwords.hash(java.util.UUID.randomUUID().toString()));
                usuario.setIdPerfil(perfil.getIdPerfil());
                id = usuarios.insert(c, usuario);
              }
              var usuario = usuarios.findById(c, id);
              var perfil = new PerfilRepository(db).findById(c, usuario.getIdPerfil());
              if (!"Activo".equals(usuario.getEstado()) || !"CLI".equals(perfil.getCodigo()))
                throw new SecurityException("El acceso de invitados no está disponible.");
              db.audit(
                  c,
                  id,
                  "INGRESO_INVITADO",
                  "usuario",
                  id,
                  "Sesión de invitado sin cuenta de cliente");
              return id;
            });
    SessionManager.getInstance().openGuest(actor);
  }

  public void logout() {
    SessionManager.getInstance().clear();
  }

  /** La autorización se comprueba en base de datos, no solo en el menú. */
  public long require(Connection c, String... roles) throws SQLException {
    var s = SessionManager.getInstance();
    if (s.getUserId() == null) throw new SecurityException("Inicia sesión para continuar.");
    Usuario usuario = new UsuarioRepository(db).findById(c, s.getUserId());
    Perfil perfil = new PerfilRepository(db).findById(c, usuario.getIdPerfil());
    if (!EstadoRegistro.ACTIVO.getCodigo().equals(usuario.getEstado())
        || !Arrays.asList(roles).contains(perfil.getCodigo())) {
      throw new SecurityException("Tu perfil no tiene permiso para esta operación.");
    }
    if (s.isGuest()) {
      if (!"CLI".equals(perfil.getCodigo())
          || !"__invitado_sistema".equals(usuario.getNombreUsuario()))
        throw new SecurityException("La sesión de invitado no es válida.");
      return s.getUserId();
    }
    s.open(
        usuario.getIdUsuario(),
        usuario.getNombreUsuario(),
        perfil.getNombre(),
        Rol.fromCodigo(perfil.getCodigo()).getCodigo());
    return s.getUserId();
  }

  public long register(
      String username, String password, String document, String name, String phone, String email) {
    for (String text : List.of(username, document, name, phone, email))
      if (text == null || text.isBlank())
        throw new IllegalArgumentException("Completa todos los datos del registro.");
    if (!email.contains("@")) throw new IllegalArgumentException("Ingresa un correo válido.");
    if (username.trim().startsWith("__"))
      throw new IllegalArgumentException("Ese nombre de usuario está reservado.");
    String hash = Passwords.hash(password);
    return db.transaction(
        c -> {
          Perfil perfil =
              new PerfilRepository(db)
                  .findAll(c).stream()
                      .filter(item -> Rol.CLIENTE.getCodigo().equals(item.getCodigo()))
                      .findFirst()
                      .orElseThrow();
          Usuario usuario = new Usuario();
          usuario.setNombreUsuario(username.trim());
          usuario.setHashClave(hash);
          usuario.setEstado(EstadoRegistro.ACTIVO.getCodigo());
          usuario.setIdPerfil(perfil.getIdPerfil());
          long id = new UsuarioRepository(db).insert(c, usuario);
          NivelCliente nivel =
              new NivelClienteRepository(db)
                  .findAll(c).stream()
                      .min(Comparator.comparing(NivelCliente::getPuntosMinimos))
                      .orElseThrow();
          Cliente cliente = new Cliente();
          cliente.setIdUsuario(id);
          cliente.setDocumento(document.trim());
          cliente.setNombres(name.trim());
          cliente.setCelular(phone.trim());
          cliente.setCorreo(email.trim());
          cliente.setIdNivel(nivel.getIdNivel());
          new ClienteRepository(db).insert(c, cliente);
          db.audit(c, id, "REGISTRO", "usuario", id, "Registro de cliente");
          return id;
        });
  }
}
