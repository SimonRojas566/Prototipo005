package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla temporada. Las relaciones se identifican mediante sus claves foráneas. */
public class Temporada {
  private Long idTemporada = null;
  private String nombre = null;
  private LocalDate fechaInicio = null;
  private LocalDate fechaFin = null;

  public Temporada() {}

  public Long getIdTemporada() {
    return idTemporada;
  }

  public void setIdTemporada(Long idTemporada) {
    this.idTemporada = idTemporada;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public LocalDate getFechaInicio() {
    return fechaInicio;
  }

  public void setFechaInicio(LocalDate fechaInicio) {
    this.fechaInicio = fechaInicio;
  }

  public LocalDate getFechaFin() {
    return fechaFin;
  }

  public void setFechaFin(LocalDate fechaFin) {
    this.fechaFin = fechaFin;
  }
}
