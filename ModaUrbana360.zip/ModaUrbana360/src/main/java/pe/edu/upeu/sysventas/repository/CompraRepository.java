package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Compra;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para compra. No abre conexiones dentro de una transacción. */
public class CompraRepository extends AbstractJdbcRepository<Compra> {
  public CompraRepository(SqlRepository db) {
    super(db, "compra", "id_compra");
  }

  @Override
  public Compra fromRow(Map<String, Object> row) {
    Compra entity = new Compra();
    if (row.containsKey("id_compra")) entity.setIdCompra(SqlHelper.longValue(row.get("id_compra")));
    if (row.containsKey("serie")) entity.setSerie(SqlHelper.textValue(row.get("serie")));
    if (row.containsKey("num_doc")) entity.setNumDoc(SqlHelper.textValue(row.get("num_doc")));
    if (row.containsKey("tipo_doc")) entity.setTipoDoc(SqlHelper.textValue(row.get("tipo_doc")));
    if (row.containsKey("fecha_comp"))
      entity.setFechaComp(SqlHelper.dateValue(row.get("fecha_comp")));
    if (row.containsKey("fecha_reg")) entity.setFechaReg(SqlHelper.dateValue(row.get("fecha_reg")));
    if (row.containsKey("precio_base"))
      entity.setPrecioBase(SqlHelper.decimalValue(row.get("precio_base")));
    if (row.containsKey("igv")) entity.setIgv(SqlHelper.decimalValue(row.get("igv")));
    if (row.containsKey("precio_total"))
      entity.setPrecioTotal(SqlHelper.decimalValue(row.get("precio_total")));
    if (row.containsKey("id_proveedor"))
      entity.setIdProveedor(SqlHelper.longValue(row.get("id_proveedor")));
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    if (row.containsKey("estado")) entity.setEstado(SqlHelper.textValue(row.get("estado")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Compra entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_compra", entity.getIdCompra());
    row.put("serie", entity.getSerie());
    row.put("num_doc", entity.getNumDoc());
    row.put("tipo_doc", entity.getTipoDoc());
    row.put("fecha_comp", entity.getFechaComp());
    row.put("fecha_reg", entity.getFechaReg());
    row.put("precio_base", entity.getPrecioBase());
    row.put("igv", entity.getIgv());
    row.put("precio_total", entity.getPrecioTotal());
    row.put("id_proveedor", entity.getIdProveedor());
    row.put("id_usuario", entity.getIdUsuario());
    row.put("estado", entity.getEstado());
    return row;
  }
}
