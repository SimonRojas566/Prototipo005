package pe.edu.upeu.sysventas.components;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.*;

/** Adaptación del helper de columnas de Unidad 1 para resultados JDBC con alias claros. */
public class TableViewHelper<T> {
  public void configure(TableView<Map<String, Object>> table, List<Map<String, Object>> rows) {
    configure(table, rows, List.of());
  }

  public void configure(
      TableView<Map<String, Object>> table,
      List<Map<String, Object>> rows,
      List<String> emptyColumns) {
    table.getColumns().clear();
    table.getItems().setAll(rows);
    table.setPlaceholder(new Label("No se encontraron registros para esta consulta."));
    table.setFixedCellSize(43);
    table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
    Collection<String> keys = rows.isEmpty() ? emptyColumns : rows.getFirst().keySet();
    for (String key : keys) {
      if (key.equals("url_imagen") || key.equals("hash_clave")) continue;
      if (key.startsWith("id_") && keys.contains(key.substring(3))) continue;
      String title = label(key);
      ColumnInfo info = new ColumnInfo(key, width(key, rows));
      TableColumn<Map<String, Object>, Object> col = new TableColumn<>(title);
      col.setPrefWidth(info.getWidth());
      col.setMinWidth(90);
      col.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().get(info.getField())));
      col.setCellFactory(
          c ->
              new TableCell<>() {
                @Override
                protected void updateItem(Object item, boolean empty) {
                  super.updateItem(item, empty);
                  if (empty || item == null) {
                    setText("");
                    setTooltip(null);
                    return;
                  }
                  String text =
                      item instanceof BigDecimal b
                          ? b.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString()
                          : item instanceof java.sql.Timestamp t
                              ? t.toLocalDateTime()
                                  .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
                              : item instanceof java.sql.Date d
                                  ? d.toLocalDate()
                                      .format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                                  : item instanceof java.time.LocalDateTime t
                                      ? t.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
                                      : item instanceof java.time.LocalDate d
                                          ? d.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                                          : item.toString();
                  setText(pe.edu.upeu.sysventas.util.I18n.t(text));
                  setTooltip(new Tooltip(pe.edu.upeu.sysventas.util.I18n.t(text)));
                  setStyle(
                      item instanceof Number
                          ? "-fx-alignment:CENTER-RIGHT;"
                          : "-fx-alignment:CENTER-LEFT;");
                  if (key.equals("estado"))
                    setStyle(
                        "-fx-text-fill:"
                            + (text.equals("Activo") || text.equals("Confirmada")
                                ? (pe.edu.upeu.sysventas.util.UiSettings.getTheme()
                                        == pe.edu.upeu.sysventas.enums.UiTheme.WHITE
                                    ? "#20633d"
                                    : "#82e0bd")
                                : (pe.edu.upeu.sysventas.util.UiSettings.getTheme()
                                        == pe.edu.upeu.sysventas.enums.UiTheme.WHITE
                                    ? "#a12949"
                                    : "#f0a2b8"))
                            + ";");
                }
              });
      table.getColumns().add(col);
    }
  }

  private double width(String key, List<Map<String, Object>> rows) {
    if (key.startsWith("id_")) return 120;
    if (key.contains("fecha")) return 170;
    if (key.equals("comprobante")) return 175;
    if (key.equals("cliente")) return 190;
    if (key.equals("precio_total")) return 140;
    if (key.equals("estado")) return 120;
    if (key.contains("detalle") || key.contains("descripcion")) return 360;
    if (Set.of("nombre", "producto", "cliente", "responsable", "razon_social", "comprobante")
        .contains(key)) return 225;
    return 155;
  }

  public static String label(String key) {
    return switch (key) {
      case "fecha_gener", "fecha_comp" -> "Fecha";
      case "codigo" -> "Código";
      case "descripcion" -> "Descripción";
      case "categoria" -> "Categoría";
      case "pu" -> "Precio unit. (S/)";
      case "precio_base" -> "Base (S/)";
      case "precio_total" -> "Total (S/)";
      case "igv" -> "Impuesto (S/)";
      case "precio_venta" -> "Precio (S/)";
      case "stock_actual" -> "Disponible";
      case "stock_minimo" -> "Stock mínimo";
      case "url_imagen" -> "Imagen local";
      case "id_venta_detalle" -> "ID detalle";
      case "descuento_total", "descuento" -> "Descuento (S/)";
      case "importe_confirmado", "cobros_confirmados" -> "Importe bruto (S/)";
      case "subtotal" -> "Subtotal (S/)";
      case "password" -> "Contraseña nueva";
      default -> {
        String s = key.replace('_', ' ');
        yield Character.toUpperCase(s.charAt(0)) + s.substring(1);
      }
    };
  }
}
