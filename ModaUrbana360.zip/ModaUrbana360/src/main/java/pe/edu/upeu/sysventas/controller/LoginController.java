package pe.edu.upeu.sysventas.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.config.AppContext;

public class LoginController {
  @FXML private TextField usuario;
  @FXML private PasswordField clave;
  @FXML private Label mensaje;
  @FXML private MenuBar preferences;

  @FXML
  public void initialize() {
    pe.edu.upeu.sysventas.components.AppearanceMenu.addTo(preferences);
  }

  @FXML
  public void login() {
    mensaje.setText("");
    try {
      AppContext.getInstance().auth.login(usuario.getText(), clave.getText());
      clave.clear();
      SysVentas.home();
    } catch (Exception e) {
      clave.clear();
      mensaje.setText(e.getMessage());
      e.printStackTrace();
    }
  }

}
