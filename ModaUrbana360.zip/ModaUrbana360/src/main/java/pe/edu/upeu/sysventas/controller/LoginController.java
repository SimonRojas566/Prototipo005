package pe.edu.upeu.sysventas.controller;

import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.util.Ui;

public class LoginController {
  @FXML private TextField usuario;
  @FXML private PasswordField clave;
  @FXML private Label mensaje;
  @FXML private MenuBar preferences;

  @FXML
  public void initialize() {
    pe.edu.upeu.sysventas.components.AppearanceMenu.addTo(preferences);
  }

  @FXML
  public void login() {
    mensaje.setText("");
    try {
      AppContext.getInstance().auth.login(usuario.getText(), clave.getText());
      clave.clear();
      SysVentas.home();
    } catch (Exception e) {
      clave.clear();
      mensaje.setText(e.getMessage());
      e.printStackTrace();
    }
  }

  @FXML
  public void guest() {
    mensaje.setText("");
    try {
      AppContext.getInstance().auth.guest();
      clave.clear();
      SysVentas.home();
    } catch (Exception error) {
      mensaje.setText(error.getMessage());
    }
  }

  @FXML
  public void register() {
    Dialog<ButtonType> d = new Dialog<>();
    d.setTitle("Crea tu cuenta Moda Urbana");
    d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
    GridPane form = new GridPane();
    form.setHgap(16);
    form.setVgap(12);
    String[] labels = {
      "Usuario", "Contraseña (10 caracteres mínimo)", "Documento", "Nombres", "Celular", "Correo"
    };
    List<TextField> inputs = new ArrayList<>();
    for (int i = 0; i < labels.length; i++) {
      TextField f = i == 1 ? new PasswordField() : new TextField();
      f.setPrefWidth(300);
      form.add(new Label(labels[i]), 0, i);
      form.add(f, 1, i);
      inputs.add(f);
    }
    d.getDialogPane().setContent(form);
    Ui.style(d);
    d.getDialogPane()
        .lookupButton(ButtonType.OK)
        .addEventFilter(
            javafx.event.ActionEvent.ACTION,
            e -> {
              try {
                AppContext.getInstance()
                    .auth
                    .register(
                        inputs.get(0).getText(),
                        inputs.get(1).getText(),
                        inputs.get(2).getText(),
                        inputs.get(3).getText(),
                        inputs.get(4).getText(),
                        inputs.get(5).getText());
                usuario.setText(inputs.get(0).getText());
                mensaje.setText("Cuenta creada. Inicia sesión para explorar la colección.");
              } catch (Exception ex) {
                e.consume();
                Ui.error(ex);
              }
            });
    d.showAndWait();
  }
}
