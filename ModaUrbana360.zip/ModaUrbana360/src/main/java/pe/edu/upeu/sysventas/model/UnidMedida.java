package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla unid_medida. Las relaciones se identifican mediante sus claves foráneas. */
public class UnidMedida {
  private Long idUnidad = null;
  private String nombreMedida = null;

  public UnidMedida() {}

  public Long getIdUnidad() {
    return idUnidad;
  }

  public void setIdUnidad(Long idUnidad) {
    this.idUnidad = idUnidad;
  }

  public String getNombreMedida() {
    return nombreMedida;
  }

  public void setNombreMedida(String nombreMedida) {
    this.nombreMedida = nombreMedida;
  }
}
