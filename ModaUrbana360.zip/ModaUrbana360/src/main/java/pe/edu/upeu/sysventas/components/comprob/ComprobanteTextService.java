package pe.edu.upeu.sysventas.components.comprob;

import pe.edu.upeu.sysventas.dto.comprobante.*;
import pe.edu.upeu.sysventas.util.Money;

/** Presentación del documento, independiente de SQL y de los controles JavaFX. */
public class ComprobanteTextService {
  public String format(Comprobante comprobante) {
    var venta = comprobante.getVenta();
    StringBuilder out =
        new StringBuilder("MODA URBANA 360\nCOMPROBANTE DEMOSTRATIVO\nSin validez tributaria\n\n");
    out.append(venta.getSerie())
        .append('-')
        .append(venta.getNumDoc())
        .append("\nFecha: ")
        .append(
            venta
                .getFechaGener()
                .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")))
        .append("\nCliente: ")
        .append(comprobante.getCliente())
        .append("\nResponsable: ")
        .append(comprobante.getResponsable())
        .append("\nEstado: ")
        .append(venta.getEstado())
        .append("\n\n");
    for (ItemComprobante item : comprobante.getItems()) {
      out.append(item.getSku())
          .append(" · ")
          .append(item.getNombre())
          .append("\n")
          .append(item.getCantidad())
          .append(" x ")
          .append(Money.soles(item.getPrecioUnitario()))
          .append(" · desc. ")
          .append(Money.soles(item.getDescuento()))
          .append(" · ")
          .append(Money.soles(item.getSubtotal()))
          .append("\n");
    }
    out.append("\nBase: ")
        .append(Money.soles(venta.getPrecioBase()))
        .append("\nImpuesto: ")
        .append(Money.soles(venta.getIgv()))
        .append("\nDescuento: ")
        .append(Money.soles(venta.getDescuentoTotal()))
        .append("\nTOTAL: ")
        .append(Money.soles(venta.getPrecioTotal()))
        .append("\n\nPagos declarados\n");
    for (PagoComprobante pago : comprobante.getPagos()) {
      out.append(pago.getNombre())
          .append(": ")
          .append(Money.soles(pago.getMonto()))
          .append(" · ")
          .append(pago.getReferencia())
          .append("\n");
    }
    out.append("\nDevoluciones / cambios\n");
    for (DevolucionComprobante devolucion : comprobante.getDevoluciones()) {
      out.append('#')
          .append(devolucion.getIdDevolucion())
          .append(" · ")
          .append(devolucion.getTipo())
          .append(" · ")
          .append(devolucion.getSku())
          .append(" · ")
          .append(devolucion.getCantidad())
          .append(" unid.\n");
    }
    return out.toString();
  }
}
