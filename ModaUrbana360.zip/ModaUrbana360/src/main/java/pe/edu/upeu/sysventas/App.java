package pe.edu.upeu.sysventas;

import javafx.application.Application;
import pe.edu.upeu.sysventas.config.*;

public class App {
  public static void main(String[] args) {
    String launcher = System.getProperty("jpackage.app-path");
    if (launcher != null)
      System.setProperty(
          "moda.home", java.nio.file.Path.of(launcher).toAbsolutePath().getParent().toString());
    if (args.length > 0 && args[0].equals("--check")) {
      try {
        var ctx = AppContext.getInstance();
        int tables =
            ctx.db
                .query(
                    "SELECT table_name FROM information_schema.tables WHERE"
                        + " table_schema=current_schema()")
                .size();
        if (tables != 24)
          throw new IllegalStateException("Se esperaban 24 tablas y se encontraron " + tables);
        for (String user : java.util.List.of("admin", "vendedor", "almacen", "cliente")) {
          ctx.auth.login(user, "admin123");
          ctx.auth.logout();
        }
        System.out.println("VERIFICACION_CORRECTA: 24 tablas y cuatro accesos demo.");
      } finally {
        DatabaseConfig.shutdown();
      }
      return;
    }
    Application.launch(SysVentas.class, args);
  }
}
