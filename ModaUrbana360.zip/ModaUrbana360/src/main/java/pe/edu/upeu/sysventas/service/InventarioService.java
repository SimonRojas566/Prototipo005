package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;

/** Contrato de negocio para inventario. */
public interface InventarioService {
  void adjust(long variant, int delta, String reason);
}
