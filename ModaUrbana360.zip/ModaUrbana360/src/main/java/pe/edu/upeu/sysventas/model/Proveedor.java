package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla proveedor. Las relaciones se identifican mediante sus claves foráneas. */
public class Proveedor {
  private Long idProveedor = null;
  private String documento = null;
  private String razonSocial = null;
  private String celular = null;
  private String correo = null;
  private String direccion = null;

  public Proveedor() {}

  public Long getIdProveedor() {
    return idProveedor;
  }

  public void setIdProveedor(Long idProveedor) {
    this.idProveedor = idProveedor;
  }

  public String getDocumento() {
    return documento;
  }

  public void setDocumento(String documento) {
    this.documento = documento;
  }

  public String getRazonSocial() {
    return razonSocial;
  }

  public void setRazonSocial(String razonSocial) {
    this.razonSocial = razonSocial;
  }

  public String getCelular() {
    return celular;
  }

  public void setCelular(String celular) {
    this.celular = celular;
  }

  public String getCorreo() {
    return correo;
  }

  public void setCorreo(String correo) {
    this.correo = correo;
  }

  public String getDireccion() {
    return direccion;
  }

  public void setDireccion(String direccion) {
    this.direccion = direccion;
  }
}
