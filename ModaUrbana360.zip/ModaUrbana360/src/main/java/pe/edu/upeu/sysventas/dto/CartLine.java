package pe.edu.upeu.sysventas.dto;

import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class CartLine {
  private final long variante;
  private final int cantidad;

  public CartLine(long variante, int cantidad) {
    if (variante < 1 || cantidad < 1)
      throw new IllegalArgumentException("Selecciona una variante y cantidad positiva.");
    this.variante = variante;
    this.cantidad = cantidad;
  }

  public long getVariante() {
    return variante;
  }

  public int getCantidad() {
    return cantidad;
  }
}
