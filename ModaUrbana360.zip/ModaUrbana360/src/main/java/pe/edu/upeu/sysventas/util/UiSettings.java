package pe.edu.upeu.sysventas.util;

import java.nio.file.Path;
import java.util.*;
import javafx.beans.property.*;
import javafx.scene.Scene;
import javafx.stage.Window;
import pe.edu.upeu.sysventas.config.*;
import pe.edu.upeu.sysventas.enums.*;

/** Actualiza las escenas abiertas sin reconstruir formularios ni vaciar carritos. */
public final class UiSettings {
  private static final UiPreferences preferences =
      new UiPreferences(
          Path.of(
              System.getProperty(
                  "moda.ui.config",
                  DatabaseConfig.home().resolve("config/ui.properties").toString())));
  private static final ObjectProperty<UiLanguage> language =
      new SimpleObjectProperty<>(preferences.getLanguage());
  private static UiTheme theme = preferences.getTheme();
  private static final Set<Scene> scenes = Collections.newSetFromMap(new WeakHashMap<>());

  private UiSettings() {}

  public static UiLanguage getLanguage() {
    return language.get();
  }

  public static ReadOnlyObjectProperty<UiLanguage> languageProperty() {
    return language;
  }

  public static UiTheme getTheme() {
    return theme;
  }

  public static void select(UiTheme selectedTheme, UiLanguage selectedLanguage) {
    preferences.save(
        Objects.requireNonNull(selectedTheme), Objects.requireNonNull(selectedLanguage));
    theme = selectedTheme;
    language.set(selectedLanguage);
    for (Scene scene : List.copyOf(scenes)) apply(scene);
    for (Window window : Window.getWindows())
      if (window.getScene() != null) apply(window.getScene());
    I18n.refresh();
  }

  public static void apply(Scene scene) {
    scenes.add(scene);
    scene
        .getStylesheets()
        .removeIf(
            url ->
                url.contains("/css/moda.css")
                    || url.contains("/css/black.css")
                    || url.contains("/css/white.css")
                    || url.contains("/css/green.css"));
    scene.getStylesheets().add(UiSettings.class.getResource(theme.getCss()).toExternalForm());
    I18n.apply(scene.getRoot());
  }
}
