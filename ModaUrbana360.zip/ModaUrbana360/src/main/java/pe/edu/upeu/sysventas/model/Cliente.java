package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla cliente. Las relaciones se identifican mediante sus claves foráneas. */
public class Cliente {
  private Long idCliente = null;
  private Long idUsuario = null;
  private String documento = null;
  private String nombres = null;
  private String celular = null;
  private String correo = null;
  private Long idNivel = null;
  private Integer puntosAcumulados = 0;

  public Cliente() {}

  public Long getIdCliente() {
    return idCliente;
  }

  public void setIdCliente(Long idCliente) {
    this.idCliente = idCliente;
  }

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public String getDocumento() {
    return documento;
  }

  public void setDocumento(String documento) {
    this.documento = documento;
  }

  public String getNombres() {
    return nombres;
  }

  public void setNombres(String nombres) {
    this.nombres = nombres;
  }

  public String getCelular() {
    return celular;
  }

  public void setCelular(String celular) {
    this.celular = celular;
  }

  public String getCorreo() {
    return correo;
  }

  public void setCorreo(String correo) {
    this.correo = correo;
  }

  public Long getIdNivel() {
    return idNivel;
  }

  public void setIdNivel(Long idNivel) {
    this.idNivel = idNivel;
  }

  public Integer getPuntosAcumulados() {
    return puntosAcumulados;
  }

  public void setPuntosAcumulados(Integer puntosAcumulados) {
    this.puntosAcumulados = puntosAcumulados;
  }
}
