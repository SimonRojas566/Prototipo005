package pe.edu.upeu.sysventas.controller;

import java.nio.file.*;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.components.TableViewHelper;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.Choice;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.*;

public class AdminController {
  @FXML private ComboBox<String> entity;
  @FXML private TableView<Map<String, Object>> table;
  @FXML private TextField search;
  @FXML private Label count, note;
  @FXML private Button deactivate, adjust;
  private List<Map<String, Object>> rows = List.of();

  @FXML
  public void initialize() {
    String role = SessionManager.getInstance().getRole();
    if (role.equals("ADM"))
      entity
          .getItems()
          .addAll(
              "producto",
              "variante",
              "marca",
              "categoria",
              "unid_medida",
              "genero",
              "temporada",
              "nivel_cliente",
              "proveedor",
              "usuario",
              "cliente",
              "promocion");
    else entity.getItems().add(role.equals("ALM") ? "proveedor" : "cliente");
    entity.setOnAction(e -> load());
    entity.getSelectionModel().selectFirst();
    load();
    search.textProperty().addListener((o, a, b) -> filter());
  }

  @FXML
  public void load() {
    Ui.run(
        () -> {
          rows = AppContext.getInstance().admin.list(entity.getValue());
          filter();
          deactivate.setDisable(
              !Set.of("producto", "usuario", "promocion").contains(entity.getValue()));
          adjust.setDisable(!entity.getValue().equals("variante"));
          note.setText(
              entity.getValue().equals("variante")
                  ? "El stock se modifica con compras, ventas o ajustes autorizados; cada"
                      + " movimiento conserva su motivo."
                  : entity.getValue().equals("cliente")
                      ? "Las ventas pueden registrarse como consumidor final sin cuenta. Aquí se"
                          + " consultan y editan fichas de clientes asociadas a compras."
                      : entity.getValue().equals("usuario")
                          ? "Cuentas del personal: asigna perfil y contraseña individual. Desactiva"
                              + " accesos cuando alguien deje de usar el sistema."
                          : "Selecciona una fila para editar. Los identificadores relacionan los"
                              + " registros entre tablas.");
        });
  }

  private void filter() {
    String q = search.getText().trim().toLowerCase();
    var filtered =
        rows.stream()
            .filter(
                r ->
                    r.values().stream()
                        .anyMatch(v -> v != null && v.toString().toLowerCase().contains(q)))
            .toList();
    Ui.table(table, filtered);
    count.setText(filtered.size() + " registros");
  }

  @FXML
  public void create() {
    edit(null);
  }

  @FXML
  public void editSelected() {
    Ui.run(
        () -> {
          var row = table.getSelectionModel().getSelectedItem();
          if (row == null) throw new IllegalArgumentException("Selecciona una fila para editar.");
          edit(row);
        });
  }

  private void edit(Map<String, Object> row) {
    Ui.run(
        () -> {
          String t = entity.getValue();
          if (t.equals("cliente") && row == null) {
            Ui.info(
                "Una venta no necesita cliente registrado: usa Consumidor final. La ficha del"
                    + " cliente se mantiene separada de las cuentas de acceso del personal.");
            return;
          }
          var admin = AppContext.getInstance().admin;
          Dialog<ButtonType> d = new Dialog<>();
          d.setTitle((row == null ? "Nuevo registro · " : "Editar · ") + t);
          d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
          GridPane grid = new GridPane();
          grid.setHgap(18);
          grid.setVgap(12);
          grid.setPadding(new javafx.geometry.Insets(16));
          Map<String, java.util.function.Supplier<String>> inputs = new LinkedHashMap<>();
          int i = 0;
          for (var f : admin.fields(t)) {
            String initial = row == null ? "" : Objects.toString(row.get(f.getName()), "");
            if (row == null) {
              if (Set.of(
                      "costo",
                      "precio_venta",
                      "stock_minimo",
                      "descuento_pct",
                      "puntos_minimos",
                      "puntos_acumulados")
                  .contains(f.getName())) initial = "0";
              if (f.getName().equals("estado")) initial = "Activo";
            }
            Label label =
                new Label(TableViewHelper.label(f.getName()) + (f.getRequired() ? " *" : ""));
            Node control;
            var options = admin.lookup(f.getName());
            if (!options.isEmpty()) {
              ComboBox<Choice> combo = new ComboBox<>();
              if (!f.getRequired()) combo.getItems().add(new Choice(0, "Sin objetivo"));
              combo.getItems().addAll(options);
              String current = initial;
              combo.getItems().stream()
                  .filter(o -> Long.toString(o.getId()).equals(current))
                  .findFirst()
                  .ifPresent(o -> combo.setValue(o));
              if (combo.getValue() == null) combo.getSelectionModel().selectFirst();
              combo.setMaxWidth(Double.MAX_VALUE);
              inputs.put(
                  f.getName(),
                  () ->
                      combo.getValue() == null || combo.getValue().getId() == 0
                          ? ""
                          : Long.toString(combo.getValue().getId()));
              control = combo;
            } else if (f.getName().equals("estado")
                || f.getName().equals("tipo") && t.equals("promocion")) {
              ComboBox<String> combo = new ComboBox<>();
              combo
                  .getItems()
                  .addAll(
                      f.getName().equals("estado")
                          ? List.of("Activo", "Inactivo")
                          : List.of("PORCENTAJE", "MONTO"));
              if (!initial.isBlank()) combo.setValue(initial);
              else combo.getSelectionModel().selectFirst();
              inputs.put(f.getName(), () -> combo.getValue());
              control = combo;
            } else {
              TextField text =
                  f.getType().equals("password") ? new PasswordField() : new TextField();
              text.setText(initial);
              text.setPrefWidth(350);
              if (f.getType().equals("date")) text.setPromptText("AAAA-MM-DD");
              if (f.getName().equals("password"))
                text.setPromptText(
                    row == null ? "10 caracteres mínimo" : "Vacío para conservar la contraseña");
              inputs.put(f.getName(), text::getText);
              control = text;
            }
            grid.add(label, 0, i);
            grid.add(control, 1, i++);
          }
          ScrollPane scroll = new ScrollPane(grid);
          scroll.setFitToWidth(true);
          scroll.setPrefViewportHeight(Math.min(i * 53, 610));
          scroll.setPrefViewportWidth(640);
          d.getDialogPane().setContent(scroll);
          Ui.style(d);
          d.getDialogPane()
              .lookupButton(ButtonType.OK)
              .addEventFilter(
                  javafx.event.ActionEvent.ACTION,
                  e -> {
                    try {
                      Map<String, String> values = new LinkedHashMap<>();
                      inputs.forEach((k, v) -> values.put(k, v.get()));
                      admin.save(
                          t, row == null ? null : Ui.id(row, AdminService.PK.get(t)), values);
                      load();
                    } catch (Exception ex) {
                      e.consume();
                      Ui.error(ex);
                    }
                  });
          d.showAndWait();
        });
  }

  @FXML
  public void deactivate() {
    Ui.run(
        () -> {
          long id =
              Ui.id(
                  table.getSelectionModel().getSelectedItem(),
                  AdminService.PK.get(entity.getValue()));
          if (Ui.confirm("Desactivar el registro seleccionado conservando su historial.")) {
            AppContext.getInstance().admin.deactivate(entity.getValue(), id);
            load();
          }
        });
  }

  @FXML
  public void adjust() {
    Ui.run(
        () -> {
          long id = Ui.id(table.getSelectionModel().getSelectedItem(), "id_variante");
          var delta =
              Ui.prompt(
                  "Ajustar stock", "Variación entera: usa un valor negativo para una salida.");
          if (delta.isEmpty()) return;
          var reason = Ui.prompt("Motivo del ajuste", "Describe el motivo de la corrección.");
          if (reason.isEmpty()) return;
          AppContext.getInstance()
              .inventario
              .adjust(id, Integer.parseInt(delta.get()), reason.get());
          load();
        });
  }
}
