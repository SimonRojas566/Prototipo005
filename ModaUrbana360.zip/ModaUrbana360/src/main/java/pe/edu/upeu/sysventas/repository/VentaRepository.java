package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Venta;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para venta. No abre conexiones dentro de una transacción. */
public class VentaRepository extends AbstractJdbcRepository<Venta> {
  public VentaRepository(SqlRepository db) {
    super(db, "venta", "id_venta");
  }

  @Override
  public Venta fromRow(Map<String, Object> row) {
    Venta entity = new Venta();
    if (row.containsKey("id_venta")) entity.setIdVenta(SqlHelper.longValue(row.get("id_venta")));
    if (row.containsKey("serie")) entity.setSerie(SqlHelper.textValue(row.get("serie")));
    if (row.containsKey("num_doc")) entity.setNumDoc(SqlHelper.textValue(row.get("num_doc")));
    if (row.containsKey("tipo_doc")) entity.setTipoDoc(SqlHelper.textValue(row.get("tipo_doc")));
    if (row.containsKey("fecha_gener"))
      entity.setFechaGener(SqlHelper.timestampValue(row.get("fecha_gener")));
    if (row.containsKey("precio_base"))
      entity.setPrecioBase(SqlHelper.decimalValue(row.get("precio_base")));
    if (row.containsKey("igv")) entity.setIgv(SqlHelper.decimalValue(row.get("igv")));
    if (row.containsKey("descuento_total"))
      entity.setDescuentoTotal(SqlHelper.decimalValue(row.get("descuento_total")));
    if (row.containsKey("precio_total"))
      entity.setPrecioTotal(SqlHelper.decimalValue(row.get("precio_total")));
    if (row.containsKey("id_cliente"))
      entity.setIdCliente(SqlHelper.longValue(row.get("id_cliente")));
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    if (row.containsKey("id_canal")) entity.setIdCanal(SqlHelper.longValue(row.get("id_canal")));
    if (row.containsKey("estado")) entity.setEstado(SqlHelper.textValue(row.get("estado")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Venta entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_venta", entity.getIdVenta());
    row.put("serie", entity.getSerie());
    row.put("num_doc", entity.getNumDoc());
    row.put("tipo_doc", entity.getTipoDoc());
    row.put("fecha_gener", entity.getFechaGener());
    row.put("precio_base", entity.getPrecioBase());
    row.put("igv", entity.getIgv());
    row.put("descuento_total", entity.getDescuentoTotal());
    row.put("precio_total", entity.getPrecioTotal());
    row.put("id_cliente", entity.getIdCliente());
    row.put("id_usuario", entity.getIdUsuario());
    row.put("id_canal", entity.getIdCanal());
    row.put("estado", entity.getEstado());
    return row;
  }
}
