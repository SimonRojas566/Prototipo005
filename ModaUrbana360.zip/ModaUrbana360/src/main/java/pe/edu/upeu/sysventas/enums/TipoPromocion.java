package pe.edu.upeu.sysventas.enums;

public enum TipoPromocion {
  PORCENTAJE("PORCENTAJE"),
  MONTO("MONTO");
  private final String codigo;

  TipoPromocion(String codigo) {
    this.codigo = codigo;
  }

  public String getCodigo() {
    return codigo;
  }

  public static TipoPromocion fromCodigo(String codigo) {
    for (TipoPromocion value : values()) {
      if (value.codigo.equals(codigo)) return value;
    }
    throw new IllegalArgumentException("Código de TipoPromocion desconocido: " + codigo);
  }
}
