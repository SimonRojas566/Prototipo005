package pe.edu.upeu.sysventas.dto;

/** Sesión de Unidad 1 extendida con cierre y código de perfil. */
public final class SessionManager {
  private static final SessionManager INSTANCE = new SessionManager();
  private Long userId;
  private String userName;
  private String userPerfil;
  private String role;
  private boolean guest;
  private final java.util.Set<Long> guestSales = new java.util.LinkedHashSet<>();

  public boolean isGuest() {
    return guest;
  }

  public java.util.Set<Long> getGuestSales() {
    return java.util.Set.copyOf(guestSales);
  }

  public boolean ownsGuestSale(long id) {
    return guest && guestSales.contains(id);
  }

  public void rememberGuestSale(long id) {
    if (guest) guestSales.add(id);
  }

  public void openGuest(long actor) {
    clear();
    userId = actor;
    userName = "Invitado";
    userPerfil = "Compra sin cuenta";
    role = "INV";
    guest = true;
  }

  private SessionManager() {}

  public static SessionManager getInstance() {
    return INSTANCE;
  }

  public Long getUserId() {
    return userId;
  }

  public String getUserName() {
    return userName;
  }

  public String getUserPerfil() {
    return userPerfil;
  }

  public String getRole() {
    return role;
  }

  public void open(long id, String name, String perfil, String code) {
    clear();
    userId = id;
    userName = name;
    userPerfil = perfil;
    role = code;
  }

  public void clear() {
    guest = false;
    guestSales.clear();
    userId = null;
    userName = null;
    userPerfil = null;
    role = null;
  }
}
