package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla canal_venta. Las relaciones se identifican mediante sus claves foráneas. */
public class CanalVenta {
  private Long idCanal = null;
  private String nombre = null;

  public CanalVenta() {}

  public Long getIdCanal() {
    return idCanal;
  }

  public void setIdCanal(Long idCanal) {
    this.idCanal = idCanal;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
}
