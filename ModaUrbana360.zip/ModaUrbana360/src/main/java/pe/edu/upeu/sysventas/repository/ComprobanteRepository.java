package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.comprobante.*;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Reúne cabecera, líneas, pagos y devoluciones dentro de la conexión del servicio. */
public class ComprobanteRepository {
  private final SqlRepository db;

  public ComprobanteRepository(SqlRepository db) {
    this.db = db;
  }

  public Comprobante findByVenta(Connection c, long id) throws SQLException {
    var venta = new VentaRepository(db).findById(c, id);
    String cliente =
        venta.getIdCliente() == null
            ? "Consumidor final"
            : new ClienteRepository(db).findById(c, venta.getIdCliente()).getNombres();
    String responsable =
        new UsuarioRepository(db).findById(c, venta.getIdUsuario()).getNombreUsuario();
    if (responsable.equals("__invitado_sistema")) responsable = "Invitado";
    List<ItemComprobante> items = new ArrayList<>();
    for (var row :
        db.query(
            c,
            "SELECT va.sku,p.nombre,d.cantidad,d.pu,d.descuento,d.subtotal FROM venta_detalle d"
                + " JOIN variante va ON va.id_variante=d.id_variante JOIN producto p ON"
                + " p.id_producto=va.id_producto WHERE d.id_venta=? ORDER BY d.id_venta_detalle",
            id)) {
      items.add(
          new ItemComprobante(
              SqlHelper.textValue(row.get("sku")),
              SqlHelper.textValue(row.get("nombre")),
              SqlHelper.integerValue(row.get("cantidad")),
              SqlHelper.decimalValue(row.get("pu")),
              SqlHelper.decimalValue(row.get("descuento")),
              SqlHelper.decimalValue(row.get("subtotal"))));
    }
    List<PagoComprobante> pagos = new ArrayList<>();
    for (var row :
        db.query(
            c,
            "SELECT m.nombre,pa.monto,pa.referencia FROM venta_pago pa JOIN metodo_pago m ON"
                + " m.id_metodo_pago=pa.id_metodo_pago WHERE id_venta=? ORDER BY pa.id_venta_pago",
            id)) {
      pagos.add(
          new PagoComprobante(
              SqlHelper.textValue(row.get("nombre")),
              SqlHelper.decimalValue(row.get("monto")),
              SqlHelper.textValue(row.get("referencia"))));
    }
    List<DevolucionComprobante> devoluciones = new ArrayList<>();
    for (var row :
        db.query(
            c,
            "SELECT r.id_devolucion,r.tipo,rd.cantidad,va.sku FROM devolucion r JOIN"
                + " devolucion_detalle rd ON rd.id_devolucion=r.id_devolucion JOIN variante va ON"
                + " va.id_variante=rd.id_variante_devuelta WHERE id_venta=? ORDER BY"
                + " r.id_devolucion,rd.id_dev_detalle",
            id)) {
      devoluciones.add(
          new DevolucionComprobante(
              SqlHelper.longValue(row.get("id_devolucion")),
              SqlHelper.textValue(row.get("tipo")),
              SqlHelper.integerValue(row.get("cantidad")),
              SqlHelper.textValue(row.get("sku"))));
    }
    String documento =
        venta.getIdCliente() == null
            ? "Sin documento"
            : new ClienteRepository(db).findById(c, venta.getIdCliente()).getDocumento();
    return new Comprobante(venta, cliente, responsable, documento, items, pagos, devoluciones);
  }
}
