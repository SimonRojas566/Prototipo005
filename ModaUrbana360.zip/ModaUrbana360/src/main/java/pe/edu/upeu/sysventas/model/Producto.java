package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla producto. Las relaciones se identifican mediante sus claves foráneas. */
public class Producto {
  private Long idProducto = null;
  private String codigo = null;
  private String nombre = null;
  private String descripcion = null;
  private Long idMarca = null;
  private Long idCategoria = null;
  private Long idUnidad = null;
  private Long idGenero = null;
  private Long idTemporada = null;
  private String urlImagen = null;
  private String estado = "Activo";

  public Producto() {}

  public Long getIdProducto() {
    return idProducto;
  }

  public void setIdProducto(Long idProducto) {
    this.idProducto = idProducto;
  }

  public String getCodigo() {
    return codigo;
  }

  public void setCodigo(String codigo) {
    this.codigo = codigo;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }

  public Long getIdMarca() {
    return idMarca;
  }

  public void setIdMarca(Long idMarca) {
    this.idMarca = idMarca;
  }

  public Long getIdCategoria() {
    return idCategoria;
  }

  public void setIdCategoria(Long idCategoria) {
    this.idCategoria = idCategoria;
  }

  public Long getIdUnidad() {
    return idUnidad;
  }

  public void setIdUnidad(Long idUnidad) {
    this.idUnidad = idUnidad;
  }

  public Long getIdGenero() {
    return idGenero;
  }

  public void setIdGenero(Long idGenero) {
    this.idGenero = idGenero;
  }

  public Long getIdTemporada() {
    return idTemporada;
  }

  public void setIdTemporada(Long idTemporada) {
    this.idTemporada = idTemporada;
  }

  public String getUrlImagen() {
    return urlImagen;
  }

  public void setUrlImagen(String urlImagen) {
    this.urlImagen = urlImagen;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }
}
