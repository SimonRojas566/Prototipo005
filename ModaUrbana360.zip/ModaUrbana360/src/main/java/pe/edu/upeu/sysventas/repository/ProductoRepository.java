package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Producto;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para producto. No abre conexiones dentro de una transacción. */
public class ProductoRepository extends AbstractJdbcRepository<Producto> {
  public ProductoRepository(SqlRepository db) {
    super(db, "producto", "id_producto");
  }

  @Override
  public Producto fromRow(Map<String, Object> row) {
    Producto entity = new Producto();
    if (row.containsKey("id_producto"))
      entity.setIdProducto(SqlHelper.longValue(row.get("id_producto")));
    if (row.containsKey("codigo")) entity.setCodigo(SqlHelper.textValue(row.get("codigo")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    if (row.containsKey("descripcion"))
      entity.setDescripcion(SqlHelper.textValue(row.get("descripcion")));
    if (row.containsKey("id_marca")) entity.setIdMarca(SqlHelper.longValue(row.get("id_marca")));
    if (row.containsKey("id_categoria"))
      entity.setIdCategoria(SqlHelper.longValue(row.get("id_categoria")));
    if (row.containsKey("id_unidad")) entity.setIdUnidad(SqlHelper.longValue(row.get("id_unidad")));
    if (row.containsKey("id_genero")) entity.setIdGenero(SqlHelper.longValue(row.get("id_genero")));
    if (row.containsKey("id_temporada"))
      entity.setIdTemporada(SqlHelper.longValue(row.get("id_temporada")));
    if (row.containsKey("url_imagen"))
      entity.setUrlImagen(SqlHelper.textValue(row.get("url_imagen")));
    if (row.containsKey("estado")) entity.setEstado(SqlHelper.textValue(row.get("estado")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Producto entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_producto", entity.getIdProducto());
    row.put("codigo", entity.getCodigo());
    row.put("nombre", entity.getNombre());
    row.put("descripcion", entity.getDescripcion());
    row.put("id_marca", entity.getIdMarca());
    row.put("id_categoria", entity.getIdCategoria());
    row.put("id_unidad", entity.getIdUnidad());
    row.put("id_genero", entity.getIdGenero());
    row.put("id_temporada", entity.getIdTemporada());
    row.put("url_imagen", entity.getUrlImagen());
    row.put("estado", entity.getEstado());
    return row;
  }
}
