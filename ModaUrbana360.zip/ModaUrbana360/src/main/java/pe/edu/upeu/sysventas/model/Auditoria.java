package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla auditoria. Las relaciones se identifican mediante sus claves foráneas. */
public class Auditoria {
  private Long idAuditoria = null;
  private Long idUsuario = null;
  private String accion = null;
  private String entidad = null;
  private Long idRegistro = null;
  private LocalDateTime fecha = LocalDateTime.now();
  private String detalle = null;

  public Auditoria() {}

  public Long getIdAuditoria() {
    return idAuditoria;
  }

  public void setIdAuditoria(Long idAuditoria) {
    this.idAuditoria = idAuditoria;
  }

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public String getAccion() {
    return accion;
  }

  public void setAccion(String accion) {
    this.accion = accion;
  }

  public String getEntidad() {
    return entidad;
  }

  public void setEntidad(String entidad) {
    this.entidad = entidad;
  }

  public Long getIdRegistro() {
    return idRegistro;
  }

  public void setIdRegistro(Long idRegistro) {
    this.idRegistro = idRegistro;
  }

  public LocalDateTime getFecha() {
    return fecha;
  }

  public void setFecha(LocalDateTime fecha) {
    this.fecha = fecha;
  }

  public String getDetalle() {
    return detalle;
  }

  public void setDetalle(String detalle) {
    this.detalle = detalle;
  }
}
