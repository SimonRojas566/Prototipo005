package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla categoria. Las relaciones se identifican mediante sus claves foráneas. */
public class Categoria {
  private Long idCategoria = null;
  private String nombre = null;

  public Categoria() {}

  public Long getIdCategoria() {
    return idCategoria;
  }

  public void setIdCategoria(Long idCategoria) {
    this.idCategoria = idCategoria;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
}
