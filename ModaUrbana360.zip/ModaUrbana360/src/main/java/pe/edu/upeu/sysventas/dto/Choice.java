package pe.edu.upeu.sysventas.dto;

import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class Choice {
  private final long id;
  private final String name;

  public Choice(long id, String name) {
    this.id = id;
    this.name = name;
  }

  public long getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  @Override
  public String toString() {
    return id == 0 ? name : name + " · #" + id;
  }
}
