package pe.edu.upeu.sysventas.dto;

import java.math.BigDecimal;
import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class Quote {
  private final List<Detail> lines;
  private final BigDecimal base;
  private final BigDecimal tax;
  private final BigDecimal discount;
  private final BigDecimal total;

  public Quote(
      List<Detail> lines, BigDecimal base, BigDecimal tax, BigDecimal discount, BigDecimal total) {
    this.lines = List.copyOf(lines);
    this.base = base;
    this.tax = tax;
    this.discount = discount;
    this.total = total;
  }

  public List<Detail> getLines() {
    return lines;
  }

  public BigDecimal getBase() {
    return base;
  }

  public BigDecimal getTax() {
    return tax;
  }

  public BigDecimal getDiscount() {
    return discount;
  }

  public BigDecimal getTotal() {
    return total;
  }
}
