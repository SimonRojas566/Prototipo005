package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;

/** Contrato de negocio para compra. */
public interface CompraService {
  long buy(
      long supplier,
      String serie,
      String document,
      java.time.LocalDate date,
      List<PurchaseLine> lines);
}
