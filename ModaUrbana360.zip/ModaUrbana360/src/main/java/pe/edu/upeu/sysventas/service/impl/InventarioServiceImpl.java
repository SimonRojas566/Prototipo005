package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.service.*;

/** Reglas y transacciones de inventario. */
public class InventarioServiceImpl implements InventarioService {
  private final SqlRepository db;
  private final AuthService auth;
  private final MovimientoStockRepository movimientos;

  public InventarioServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
    this.movimientos = new MovimientoStockRepository(db);
  }

  public void adjust(long variant, int delta, String reason) {
    if (delta == 0 || reason == null || reason.trim().length() < 5)
      throw new IllegalArgumentException(
          "Ingresa una variación distinta de cero y un motivo de al menos cinco caracteres.");
    db.transaction(
        c -> {
          long u = auth.require(c, "ADM");
          var v =
              db.one(
                  c, "SELECT stock_actual FROM variante WHERE id_variante=? FOR UPDATE", variant);
          if ((long) ((Number) v.get("stock_actual")).intValue() + delta < 0)
            throw new IllegalArgumentException("El ajuste dejaría stock negativo.");
          db.update(
              c,
              "UPDATE variante SET stock_actual=stock_actual+? WHERE id_variante=?",
              delta,
              variant);
          movimientos.registrar(c, variant, "AJUSTE", delta, reason.trim(), u);
          db.audit(c, u, "AJUSTAR", "variante", variant, delta + "; " + reason);
          return null;
        });
  }
}
