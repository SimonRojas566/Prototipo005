package pe.edu.upeu.sysventas.util;

import java.util.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.components.TableViewHelper;

public final class Ui {
  private Ui() {}

  public static void error(Throwable error) {
    error.printStackTrace();
    if (Boolean.getBoolean("moda.ui.failFast")) throw new IllegalStateException(error);
    Alert a = new Alert(Alert.AlertType.ERROR);
    a.setTitle("Revisa la operación");
    a.setHeaderText(
        error instanceof SecurityException ? "Acceso restringido" : "No se completó la operación");
    a.setContentText(error.getMessage());
    style(a);
    a.showAndWait();
  }

  public static void info(String text) {
    Alert a = new Alert(Alert.AlertType.INFORMATION);
    a.setTitle("Moda Urbana 360");
    a.setHeaderText("Operación completada");
    a.setContentText(text);
    style(a);
    a.showAndWait();
  }

  public static boolean confirm(String text) {
    Alert a = new Alert(Alert.AlertType.CONFIRMATION, text, ButtonType.OK, ButtonType.CANCEL);
    a.setTitle("Confirmar operación");
    a.setHeaderText("Revisa antes de continuar");
    style(a);
    return a.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK;
  }

  public static void run(Runnable action) {
    try {
      action.run();
    } catch (Exception e) {
      error(e);
    } finally {
      I18n.applyAll();
    }
  }

  public static void style(Dialog<?> dialog) {
    if (SysVentas.stage() != null) dialog.initOwner(SysVentas.stage());
    dialog
        .getDialogPane()
        .getStylesheets()
        .add(Ui.class.getResource(UiSettings.getTheme().getCss()).toExternalForm());
    I18n.bind(dialog.titleProperty());
    I18n.apply(dialog.getDialogPane());
    dialog.getDialogPane().setMinWidth(540);
  }

  public static void table(TableView<Map<String, Object>> table, List<Map<String, Object>> rows) {
    new TableViewHelper<>().configure(table, rows);
  }

  public static long id(Map<String, Object> row, String key) {
    if (row == null) throw new IllegalArgumentException("Selecciona una fila de la tabla.");
    return ((Number) row.get(key)).longValue();
  }

  public static TextField text(String prompt) {
    TextField t = new TextField();
    t.setPromptText(prompt);
    return t;
  }

  public static Optional<String> prompt(String title, String content) {
    TextInputDialog d = new TextInputDialog();
    d.setTitle(title);
    d.setHeaderText(content);
    style(d);
    return d.showAndWait();
  }

  public static void textView(String title, String text) {
    Dialog<Void> d = new Dialog<>();
    d.setTitle(title);
    d.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
    TextArea area = new TextArea(text);
    area.setEditable(false);
    area.setWrapText(true);
    area.setPrefSize(680, 560);
    d.getDialogPane().setContent(area);
    style(d);
    d.showAndWait();
  }
}
