package pe.edu.upeu.sysventas.enums;

import java.util.Locale;

public enum UiLanguage {
  SPANISH("Español", Locale.forLanguageTag("es-PE"), 0),
  ENGLISH("English", Locale.ENGLISH, 1),
  PORTUGUESE("Português (Brasil)", Locale.forLanguageTag("pt-BR"), 2);
  private final String title;
  private final Locale locale;
  private final int column;

  UiLanguage(String title, Locale locale, int column) {
    this.title = title;
    this.locale = locale;
    this.column = column;
  }

  public String getTitle() {
    return title;
  }

  public Locale getLocale() {
    return locale;
  }

  public int getColumn() {
    return column;
  }
}
