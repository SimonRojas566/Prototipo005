package pe.edu.upeu.sysventas.enums;

public enum Rol {
  ADMINISTRADOR("ADM"),
  VENDEDOR("VEN"),
  ALMACENERO("ALM"),
  CLIENTE("CLI");
  private final String codigo;

  Rol(String codigo) {
    this.codigo = codigo;
  }

  public String getCodigo() {
    return codigo;
  }

  public static Rol fromCodigo(String codigo) {
    for (Rol value : values()) {
      if (value.codigo.equals(codigo)) return value;
    }
    throw new IllegalArgumentException("Código de Rol desconocido: " + codigo);
  }
}
