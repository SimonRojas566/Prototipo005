package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.model.*;

/** Contrato de la capa de negocio utilizado por los controladores. */
public interface AdminService {

  public static final Set<String> TABLES =
      Set.of(
          "producto",
          "variante",
          "marca",
          "categoria",
          "unid_medida",
          "genero",
          "temporada",
          "nivel_cliente",
          "proveedor",
          "cliente",
          "usuario",
          "promocion");
  public static final Map<String, String> PK =
      Map.ofEntries(
          Map.entry("producto", "id_producto"),
          Map.entry("variante", "id_variante"),
          Map.entry("marca", "id_marca"),
          Map.entry("categoria", "id_categoria"),
          Map.entry("unid_medida", "id_unidad"),
          Map.entry("genero", "id_genero"),
          Map.entry("temporada", "id_temporada"),
          Map.entry("nivel_cliente", "id_nivel"),
          Map.entry("proveedor", "id_proveedor"),
          Map.entry("cliente", "id_cliente"),
          Map.entry("usuario", "id_usuario"),
          Map.entry("promocion", "id_promocion"));

  List<Field> fields(String table);

  List<Map<String, Object>> list(String table);

  List<Choice> lookup(String field);

  long save(String table, Long id, Map<String, String> input);

  void deactivate(String table, long id);
}
