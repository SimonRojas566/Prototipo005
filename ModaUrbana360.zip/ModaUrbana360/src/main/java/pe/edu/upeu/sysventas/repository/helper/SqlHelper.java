package pe.edu.upeu.sysventas.repository.helper;

import java.math.BigDecimal;
import java.sql.*;
import java.time.*;

/** Conversión JDBC centralizada; conserva los valores SQL NULL en las relaciones opcionales. */
public final class SqlHelper {
  private SqlHelper() {}

  public static Long longValue(Object value) {
    return value == null ? null : ((Number) value).longValue();
  }

  public static Integer integerValue(Object value) {
    return value == null ? null : ((Number) value).intValue();
  }

  public static String textValue(Object value) {
    return value == null ? null : value.toString();
  }

  public static BigDecimal decimalValue(Object value) {
    return value == null ? null : new BigDecimal(value.toString());
  }

  public static LocalDate dateValue(Object value) {
    return value == null
        ? null
        : value instanceof java.sql.Date date ? date.toLocalDate() : (LocalDate) value;
  }

  public static LocalDateTime timestampValue(Object value) {
    return value == null
        ? null
        : value instanceof Timestamp timestamp
            ? timestamp.toLocalDateTime()
            : (LocalDateTime) value;
  }
}
