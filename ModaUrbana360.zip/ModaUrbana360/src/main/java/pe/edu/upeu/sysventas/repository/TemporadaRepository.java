package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Temporada;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para temporada. No abre conexiones dentro de una transacción. */
public class TemporadaRepository extends AbstractJdbcRepository<Temporada> {
  public TemporadaRepository(SqlRepository db) {
    super(db, "temporada", "id_temporada");
  }

  @Override
  public Temporada fromRow(Map<String, Object> row) {
    Temporada entity = new Temporada();
    if (row.containsKey("id_temporada"))
      entity.setIdTemporada(SqlHelper.longValue(row.get("id_temporada")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    if (row.containsKey("fecha_inicio"))
      entity.setFechaInicio(SqlHelper.dateValue(row.get("fecha_inicio")));
    if (row.containsKey("fecha_fin")) entity.setFechaFin(SqlHelper.dateValue(row.get("fecha_fin")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Temporada entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_temporada", entity.getIdTemporada());
    row.put("nombre", entity.getNombre());
    row.put("fecha_inicio", entity.getFechaInicio());
    row.put("fecha_fin", entity.getFechaFin());
    return row;
  }
}
