package pe.edu.upeu.sysventas.model;

import java.time.*;

/**
 * Entidad de la tabla movimiento_stock. Las relaciones se identifican mediante sus claves foráneas.
 */
public class MovimientoStock {
  private Long idMovimiento = null;
  private Long idVariante = null;
  private String tipoMovimiento = null;
  private Integer cantidad = 0;
  private LocalDateTime fecha = LocalDateTime.now();
  private String referencia = null;
  private Long idUsuario = null;

  public MovimientoStock() {}

  public Long getIdMovimiento() {
    return idMovimiento;
  }

  public void setIdMovimiento(Long idMovimiento) {
    this.idMovimiento = idMovimiento;
  }

  public Long getIdVariante() {
    return idVariante;
  }

  public void setIdVariante(Long idVariante) {
    this.idVariante = idVariante;
  }

  public String getTipoMovimiento() {
    return tipoMovimiento;
  }

  public void setTipoMovimiento(String tipoMovimiento) {
    this.tipoMovimiento = tipoMovimiento;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public void setCantidad(Integer cantidad) {
    this.cantidad = cantidad;
  }

  public LocalDateTime getFecha() {
    return fecha;
  }

  public void setFecha(LocalDateTime fecha) {
    this.fecha = fecha;
  }

  public String getReferencia() {
    return referencia;
  }

  public void setReferencia(String referencia) {
    this.referencia = referencia;
  }

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }
}
