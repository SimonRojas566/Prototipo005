package pe.edu.upeu.sysventas.enums;

/** Tipos de comprobantes académicos; la elección se persiste con la venta. */
public enum TipoDocumento {
  BOLETA("Boleta demo", "B001", "Boleta de venta"),
  FACTURA("Factura demo", "F001", "Factura de venta");
  private final String valor;
  private final String serie;
  private final String titulo;

  TipoDocumento(String valor, String serie, String titulo) {
    this.valor = valor;
    this.serie = serie;
    this.titulo = titulo;
  }

  public String getValor() {
    return valor;
  }

  public String getSerie() {
    return serie;
  }

  public String getTitulo() {
    return titulo;
  }

  public static TipoDocumento fromStored(String value) {
    return value != null && value.toLowerCase(java.util.Locale.ROOT).contains("factura")
        ? FACTURA
        : BOLETA;
  }

  @Override
  public String toString() {
    return titulo + " (demo)";
  }
}
