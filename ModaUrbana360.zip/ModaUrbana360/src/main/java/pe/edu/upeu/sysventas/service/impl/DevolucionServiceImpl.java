package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.Money;

/** Reglas y transacciones de devolucion. */
public class DevolucionServiceImpl implements DevolucionService {
  private final SqlRepository db;
  private final AuthService auth;
  private final MovimientoStockRepository movimientos;

  public DevolucionServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
    this.movimientos = new MovimientoStockRepository(db);
  }

  public long returnItem(long detail, int quantity, Long exchange, String reason) {
    if (quantity < 1 || reason == null || reason.trim().length() < 5)
      throw new IllegalArgumentException(
          "Ingresa cantidad positiva y motivo de al menos cinco caracteres.");
    return db.transaction(
        c -> {
          long u = auth.require(c, "ADM", "VEN");
          var lookup =
              db.one(c, "SELECT id_venta FROM venta_detalle WHERE id_venta_detalle=?", detail);
          long sale = ((Number) lookup.get("id_venta")).longValue();
          Venta s = new VentaRepository(db).findByIdForUpdate(c, sale);
          if (!EstadoOperacion.CONFIRMADA.getCodigo().equals(s.getEstado()))
            throw new IllegalArgumentException("La venta está anulada.");
          if ("VEN".equals(SessionManager.getInstance().getRole()) && s.getIdUsuario() != u)
            throw new SecurityException("Solo puedes tramitar devoluciones de tus ventas.");
          VentaDetalle line = new VentaDetalleRepository(db).findByIdForUpdate(c, detail);
          int returned =
              ((Number)
                      db.one(
                              c,
                              "SELECT COALESCE(SUM(cantidad),0) AS n FROM devolucion_detalle WHERE"
                                  + " id_venta_detalle=?",
                              detail)
                          .get("n"))
                  .intValue();
          int sold = line.getCantidad();
          if (quantity > sold - returned)
            throw new IllegalArgumentException("La cantidad supera el saldo de unidades vendidas.");
          long variant = line.getIdVariante();
          BigDecimal net = line.getSubtotal();
          BigDecimal previous =
              net.multiply(BigDecimal.valueOf(returned))
                  .divide(BigDecimal.valueOf(sold), 2, RoundingMode.HALF_UP);
          BigDecimal cumulative =
              net.multiply(BigDecimal.valueOf(returned + quantity))
                  .divide(BigDecimal.valueOf(sold), 2, RoundingMode.HALF_UP);
          BigDecimal refund = cumulative.subtract(previous);
          if (exchange != null) {
            if (exchange == variant)
              throw new IllegalArgumentException("Elige otra variante para el cambio.");
            var other =
                db.one(
                    c,
                    "SELECT v.precio_venta,v.stock_actual,p.estado FROM variante v JOIN producto p"
                        + " ON p.id_producto=v.id_producto WHERE id_variante=? FOR UPDATE",
                    exchange);
            if (!other.get("estado").equals("Activo")
                || ((Number) other.get("stock_actual")).intValue() < quantity)
              throw new IllegalArgumentException(
                  "La variante de cambio no tiene stock suficiente.");
            if (Money.of(other.get("precio_venta"))
                    .multiply(BigDecimal.valueOf(quantity))
                    .compareTo(refund)
                != 0)
              throw new IllegalArgumentException(
                  "El cambio directo requiere igual valor neto. Para otra diferencia, registra"
                      + " devolución y nueva venta.");
          }
          Devolucion devolucion = new Devolucion();
          devolucion.setIdVenta(sale);
          devolucion.setMotivo(reason.trim());
          devolucion.setTipo(exchange == null ? "DEVOLUCION" : "CAMBIO");
          devolucion.setIdUsuario(u);
          long id = new DevolucionRepository(db).insert(c, devolucion);
          DevolucionDetalle detalle = new DevolucionDetalle();
          detalle.setIdDevolucion(id);
          detalle.setIdVentaDetalle(detail);
          detalle.setIdVarianteDevuelta(variant);
          detalle.setCantidad(quantity);
          detalle.setIdVarianteCambio(exchange);
          new DevolucionDetalleRepository(db).insert(c, detalle);
          db.update(
              c,
              "UPDATE variante SET stock_actual=stock_actual+? WHERE id_variante=?",
              quantity,
              variant);
          movimientos.registrar(c, variant, "ENTRADA_DEVOLUCION", quantity, "DEVOLUCION:" + id, u);
          if (exchange != null) {
            db.update(
                c,
                "UPDATE variante SET stock_actual=stock_actual-? WHERE id_variante=?",
                quantity,
                exchange);
            movimientos.registrar(c, exchange, "SALIDA_CAMBIO", -quantity, "DEVOLUCION:" + id, u);
          }
          db.audit(
              c,
              u,
              "CONFIRMAR",
              "devolucion",
              id,
              (exchange == null ? "Reembolso demostrativo en efectivo " : "Cambio de igual valor ")
                  + Money.soles(refund)
                  + "; "
                  + reason);
          return id;
        });
  }
}
