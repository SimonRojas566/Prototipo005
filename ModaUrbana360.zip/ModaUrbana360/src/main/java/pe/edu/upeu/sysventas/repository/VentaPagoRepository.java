package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.VentaPago;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para venta_pago. No abre conexiones dentro de una transacción. */
public class VentaPagoRepository extends AbstractJdbcRepository<VentaPago> {
  public VentaPagoRepository(SqlRepository db) {
    super(db, "venta_pago", "id_venta_pago");
  }

  @Override
  public VentaPago fromRow(Map<String, Object> row) {
    VentaPago entity = new VentaPago();
    if (row.containsKey("id_venta_pago"))
      entity.setIdVentaPago(SqlHelper.longValue(row.get("id_venta_pago")));
    if (row.containsKey("id_venta")) entity.setIdVenta(SqlHelper.longValue(row.get("id_venta")));
    if (row.containsKey("id_metodo_pago"))
      entity.setIdMetodoPago(SqlHelper.longValue(row.get("id_metodo_pago")));
    if (row.containsKey("monto")) entity.setMonto(SqlHelper.decimalValue(row.get("monto")));
    if (row.containsKey("referencia"))
      entity.setReferencia(SqlHelper.textValue(row.get("referencia")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(VentaPago entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_venta_pago", entity.getIdVentaPago());
    row.put("id_venta", entity.getIdVenta());
    row.put("id_metodo_pago", entity.getIdMetodoPago());
    row.put("monto", entity.getMonto());
    row.put("referencia", entity.getReferencia());
    return row;
  }
}
