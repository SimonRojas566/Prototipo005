package pe.edu.upeu.sysventas.dto.comprobante;

import java.math.BigDecimal;
import java.util.*;

/** Proyección tipada utilizada para consultar y presentar un comprobante. */
public final class PagoComprobante {
  private final String nombre;
  private final BigDecimal monto;
  private final String referencia;

  public PagoComprobante(String nombre, BigDecimal monto, String referencia) {
    this.nombre = nombre;
    this.monto = monto;
    this.referencia = referencia;
  }

  public String getNombre() {
    return nombre;
  }

  public BigDecimal getMonto() {
    return monto;
  }

  public String getReferencia() {
    return referencia;
  }
}
