package pe.edu.upeu.sysventas.util;

import java.io.*;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import javafx.beans.property.StringProperty;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Window;

/** Traduce la presentación y conserva intactos los valores de formularios y consultas. */
public final class I18n {
  private static final Map<String, String[]> texts = load();
  private static final List<Map.Entry<String, String[]>> templates =
      texts.entrySet().stream()
          .filter(entry -> entry.getKey().contains("{0}"))
          .sorted(
              Comparator.comparingInt(
                      (Map.Entry<String, String[]> entry) ->
                          entry.getKey().replaceAll("\\{[0-9]+\\}", "").length())
                  .reversed())
          .toList();
  private static final Map<StringProperty, Binding> bindings = new WeakHashMap<>();

  private I18n() {}

  private static Map<String, String[]> load() {
    Map<String, String[]> result = new LinkedHashMap<>();
    try (var stream = I18n.class.getResourceAsStream("/i18n/texts.tsv");
        var reader =
            new BufferedReader(
                new InputStreamReader(Objects.requireNonNull(stream), StandardCharsets.UTF_8))) {
      for (String line; (line = reader.readLine()) != null; ) {
        if (line.isBlank() || line.startsWith("# ")) continue;
        String[] parts = line.split("\t", -1);
        if (parts.length != 3) throw new IOException("Catálogo de idiomas inválido");
        for (int i = 0; i < 3; i++) parts[i] = parts[i].replace("\\n", "\n");
        result.put(parts[0], parts);
      }
    } catch (IOException error) {
      throw new IllegalStateException("No se pudo cargar el catálogo de idiomas.", error);
    }
    return Collections.unmodifiableMap(result);
  }

  public static String t(String source) {
    if (source == null || source.isEmpty()) return source;
    source =
        switch (source) {
          case "Cancel" -> "Cancelar";
          case "Close" -> "Cerrar";
          case "OK" -> "Aceptar";
          default -> source;
        };
    int index = UiSettings.getLanguage().getColumn();
    if (index == 0) return source;
    String[] exact = texts.get(source);
    if (exact != null) return exact[index];
    if (source.contains("\n"))
      return String.join("\n", Arrays.stream(source.split("\n", -1)).map(I18n::t).toList());
    for (var entry : templates)
      if (entry.getKey().contains("{0}")) {
        String[] pieces = entry.getKey().split("(?=\\{[0-9]+\\})|(?<=\\})", -1);
        StringBuilder regex = new StringBuilder();
        List<String> keys = new ArrayList<>();
        for (String piece : pieces) {
          if (piece.matches("\\{[0-9]+\\}")) {
            regex.append("(.*?)");
            keys.add(piece);
          } else regex.append(Pattern.quote(piece));
        }
        Matcher match = Pattern.compile(regex.toString(), Pattern.DOTALL).matcher(source);
        if (match.matches()) {
          String result = entry.getValue()[index];
          boolean semantic =
              Set.of(
                      "{0} · #{1}",
                      "{0} *",
                      "{0} (demo)",
                      "{0}: {1}",
                      "Nuevo registro · {0}",
                      "Editar · {0}",
                      "Estado: {0}",
                      "Completa el campo {0}.")
                  .contains(entry.getKey());
          for (int i = 0; i < keys.size(); i++)
            result =
                result.replace(
                    keys.get(i),
                    (semantic && i == 0)
                            || (entry.getKey().equals("#{0} · {1} · {2} unidades · {3}") && i == 1)
                        ? t(match.group(i + 1))
                        : match.group(i + 1));
          return result;
        }
      }
    return source;
  }

  public static void bind(StringProperty property) {
    if (property.isBound() || bindings.containsKey(property)) return;
    Binding binding = new Binding(property);
    bindings.put(property, binding);
    binding.render();
  }

  private static class Binding {
    final WeakReference<StringProperty> property;
    String source;
    boolean rendering;

    Binding(StringProperty p) {
      property = new WeakReference<>(p);
      source = p.get();
      p.addListener(
          (obs, oldValue, newValue) -> {
            if (!rendering) {
              source = newValue;
              render();
            }
          });
    }

    void render() {
      var p = property.get();
      if (p == null || p.isBound()) return;
      rendering = true;
      try {
        p.set(t(source));
      } finally {
        rendering = false;
      }
    }
  }

  public static void refresh() {
    for (Binding binding : List.copyOf(bindings.values())) binding.render();
  }

  public static void applyAll() {
    for (Window window : Window.getWindows())
      if (window.getScene() != null) apply(window.getScene().getRoot());
  }

  public static void menu(MenuItem item) {
    bind(item.textProperty());
    if (item instanceof Menu menu) for (MenuItem child : menu.getItems()) menu(child);
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  public static void apply(Node node) {
    if (node instanceof Labeled label
        && !(node instanceof TableCell)
        && !(node instanceof ListCell)) bind(label.textProperty());
    if (node instanceof TextInputControl input) bind(input.promptTextProperty());
    if (node instanceof MenuBar bar) for (Menu menu : bar.getMenus()) menu(menu);
    if (node instanceof ComboBox combo
        && combo.getProperties().putIfAbsent("moda.i18n.combo", true) == null) {
      javafx.util.Callback<ListView<Object>, ListCell<Object>> factory =
          view ->
              new ListCell<>() {
                {
                  bind(textProperty());
                }

                @Override
                protected void updateItem(Object item, boolean empty) {
                  super.updateItem(item, empty);
                  setText(empty || item == null ? "" : item.toString());
                }
              };
      combo.setCellFactory(factory);
      combo.setButtonCell(factory.call(null));
    }
    if (node instanceof TableView<?> table) {
      for (TableColumn<?, ?> column : table.getColumns()) bind(column.textProperty());
      table.refresh();
    }
    if (node instanceof DialogPane pane) {
      bind(pane.headerTextProperty());
      bind(pane.contentTextProperty());
    }
    if (node instanceof ScrollPane scroll && scroll.getContent() != null)
      apply(scroll.getContent());
    if (node instanceof Parent parent)
      for (Node child : parent.getChildrenUnmodifiable()) apply(child);
  }
}
