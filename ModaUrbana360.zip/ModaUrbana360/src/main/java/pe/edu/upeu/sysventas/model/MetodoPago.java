package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla metodo_pago. Las relaciones se identifican mediante sus claves foráneas. */
public class MetodoPago {
  private Long idMetodoPago = null;
  private String nombre = null;

  public MetodoPago() {}

  public Long getIdMetodoPago() {
    return idMetodoPago;
  }

  public void setIdMetodoPago(Long idMetodoPago) {
    this.idMetodoPago = idMetodoPago;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
}
