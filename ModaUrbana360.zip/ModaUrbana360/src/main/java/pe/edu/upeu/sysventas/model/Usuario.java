package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla usuario. Las relaciones se identifican mediante sus claves foráneas. */
public class Usuario {
  private Long idUsuario = null;
  private String nombreUsuario = null;
  private String hashClave = null;
  private String estado = "Activo";
  private Long idPerfil = null;

  public Usuario() {}

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public String getNombreUsuario() {
    return nombreUsuario;
  }

  public void setNombreUsuario(String nombreUsuario) {
    this.nombreUsuario = nombreUsuario;
  }

  public String getHashClave() {
    return hashClave;
  }

  public void setHashClave(String hashClave) {
    this.hashClave = hashClave;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }

  public Long getIdPerfil() {
    return idPerfil;
  }

  public void setIdPerfil(Long idPerfil) {
    this.idPerfil = idPerfil;
  }
}
