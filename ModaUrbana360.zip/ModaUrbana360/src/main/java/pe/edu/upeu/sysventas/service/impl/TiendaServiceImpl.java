package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.service.*;

public class TiendaServiceImpl implements TiendaService {
  private final VentaService ventas;
  private final CompraService compras;
  private final InventarioService inventario;
  private final DevolucionService devoluciones;

  public TiendaServiceImpl(
      VentaService ventas,
      CompraService compras,
      InventarioService inventario,
      DevolucionService devoluciones) {
    this.ventas = ventas;
    this.compras = compras;
    this.inventario = inventario;
    this.devoluciones = devoluciones;
  }

  public Quote quote(List<CartLine> cart, Long client, BigDecimal manual) {
    return ventas.quote(cart, client, manual);
  }

  public long sell(
      List<CartLine> cart,
      Long client,
      List<Payment> payments,
      BigDecimal manual,
      TipoDocumento documento) {
    return ventas.sell(cart, client, payments, manual, documento);
  }

  public void cancel(long sale, String reason) {
    ventas.cancel(sale, reason);
  }

  public long buy(
      long supplier,
      String serie,
      String document,
      java.time.LocalDate date,
      List<PurchaseLine> lines) {
    return compras.buy(supplier, serie, document, date, lines);
  }

  public void adjust(long variant, int delta, String reason) {
    inventario.adjust(variant, delta, reason);
  }

  public long returnItem(long detail, int quantity, Long exchange, String reason) {
    return devoluciones.returnItem(detail, quantity, exchange, reason);
  }
}
