package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Devolucion;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para devolucion. No abre conexiones dentro de una transacción. */
public class DevolucionRepository extends AbstractJdbcRepository<Devolucion> {
  public DevolucionRepository(SqlRepository db) {
    super(db, "devolucion", "id_devolucion");
  }

  @Override
  public Devolucion fromRow(Map<String, Object> row) {
    Devolucion entity = new Devolucion();
    if (row.containsKey("id_devolucion"))
      entity.setIdDevolucion(SqlHelper.longValue(row.get("id_devolucion")));
    if (row.containsKey("id_venta")) entity.setIdVenta(SqlHelper.longValue(row.get("id_venta")));
    if (row.containsKey("fecha")) entity.setFecha(SqlHelper.timestampValue(row.get("fecha")));
    if (row.containsKey("motivo")) entity.setMotivo(SqlHelper.textValue(row.get("motivo")));
    if (row.containsKey("tipo")) entity.setTipo(SqlHelper.textValue(row.get("tipo")));
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    if (row.containsKey("estado")) entity.setEstado(SqlHelper.textValue(row.get("estado")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Devolucion entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_devolucion", entity.getIdDevolucion());
    row.put("id_venta", entity.getIdVenta());
    row.put("fecha", entity.getFecha());
    row.put("motivo", entity.getMotivo());
    row.put("tipo", entity.getTipo());
    row.put("id_usuario", entity.getIdUsuario());
    row.put("estado", entity.getEstado());
    return row;
  }
}
