package pe.edu.upeu.sysventas.enums;

public enum EstadoOperacion {
  CONFIRMADA("Confirmada"),
  ANULADA("Anulada");
  private final String codigo;

  EstadoOperacion(String codigo) {
    this.codigo = codigo;
  }

  public String getCodigo() {
    return codigo;
  }

  public static EstadoOperacion fromCodigo(String codigo) {
    for (EstadoOperacion value : values()) {
      if (value.codigo.equals(codigo)) return value;
    }
    throw new IllegalArgumentException("Código de EstadoOperacion desconocido: " + codigo);
  }
}
