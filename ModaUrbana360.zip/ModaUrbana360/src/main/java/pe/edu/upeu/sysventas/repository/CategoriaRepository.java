package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Categoria;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para categoria. No abre conexiones dentro de una transacción. */
public class CategoriaRepository extends AbstractJdbcRepository<Categoria> {
  public CategoriaRepository(SqlRepository db) {
    super(db, "categoria", "id_categoria");
  }

  @Override
  public Categoria fromRow(Map<String, Object> row) {
    Categoria entity = new Categoria();
    if (row.containsKey("id_categoria"))
      entity.setIdCategoria(SqlHelper.longValue(row.get("id_categoria")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Categoria entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_categoria", entity.getIdCategoria());
    row.put("nombre", entity.getNombre());
    return row;
  }
}
