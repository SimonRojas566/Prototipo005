package pe.edu.upeu.sysventas.repository;

import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.ProductoCatalogoDto;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Consultas con filtros opcionales; devuelve DTO tipados para el catálogo. */
public class CatalogoRepository {
  private final SqlRepository db;

  public CatalogoRepository(SqlRepository db) {
    this.db = db;
  }

  public List<ProductoCatalogoDto> search(
      Connection c,
      String text,
      Long brand,
      Long category,
      String size,
      String color,
      BigDecimal min,
      BigDecimal max,
      boolean available)
      throws SQLException {
    StringBuilder q =
        new StringBuilder(
            "SELECT v.id_variante,p.id_producto,p.nombre,p.descripcion,m.nombre AS marca,cat.nombre"
                + " AS categoria,v.talla,v.color,v.sku,v.precio_venta,v.costo,v.stock_actual,v.stock_minimo"
                + " FROM variante v JOIN producto p ON p.id_producto=v.id_producto JOIN marca m ON"
                + " m.id_marca=p.id_marca JOIN categoria cat ON cat.id_categoria=p.id_categoria"
                + " WHERE p.estado='Activo'");
    List<Object> a = new ArrayList<>();
    if (text != null && !text.isBlank()) {
      q.append(" AND (p.nombre ILIKE ? OR v.sku ILIKE ? OR v.color ILIKE ?)");
      for (int i = 0; i < 3; i++) a.add("%" + text.trim() + "%");
    }
    if (brand != null) {
      q.append(" AND p.id_marca=?");
      a.add(brand);
    }
    if (category != null) {
      q.append(" AND p.id_categoria=?");
      a.add(category);
    }
    if (size != null && !size.isBlank()) {
      q.append(" AND v.talla=?");
      a.add(size);
    }
    if (color != null && !color.isBlank()) {
      q.append(" AND v.color ILIKE ?");
      a.add("%" + color + "%");
    }
    if (min != null) {
      q.append(" AND v.precio_venta>=?");
      a.add(min);
    }
    if (max != null) {
      q.append(" AND v.precio_venta<=?");
      a.add(max);
    }
    if (available) q.append(" AND v.stock_actual>0");
    q.append(" ORDER BY p.nombre,v.talla");
    List<ProductoCatalogoDto> result = new ArrayList<>();
    for (var row : db.query(c, q.toString(), a.toArray())) {
      ProductoCatalogoDto item = new ProductoCatalogoDto();
      item.setIdVariante(SqlHelper.longValue(row.get("id_variante")));
      item.setIdProducto(SqlHelper.longValue(row.get("id_producto")));
      item.setNombre(SqlHelper.textValue(row.get("nombre")));
      item.setDescripcion(SqlHelper.textValue(row.get("descripcion")));
      item.setMarca(SqlHelper.textValue(row.get("marca")));
      item.setCategoria(SqlHelper.textValue(row.get("categoria")));
      item.setTalla(SqlHelper.textValue(row.get("talla")));
      item.setColor(SqlHelper.textValue(row.get("color")));
      item.setSku(SqlHelper.textValue(row.get("sku")));
      item.setPrecioVenta(SqlHelper.decimalValue(row.get("precio_venta")));
      item.setCosto(SqlHelper.decimalValue(row.get("costo")));
      item.setStockActual(SqlHelper.integerValue(row.get("stock_actual")));
      item.setStockMinimo(SqlHelper.integerValue(row.get("stock_minimo")));
      result.add(item);
    }
    return result;
  }
}
