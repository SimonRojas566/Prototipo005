package pe.edu.upeu.sysventas.controller;

import java.nio.file.*;
import java.time.*;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.Choice;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.*;

public class ReportController {
  @FXML private ComboBox<String> report;
  @FXML private TextField seller;
  @FXML private DatePicker from, to;
  @FXML private TableView<Map<String, Object>> table;
  @FXML private Label count, note;
  @FXML private Button receipt, details, cancel;
  private List<Map<String, Object>> rows = List.of();

  @FXML
  public void initialize() {
    from.setValue(LocalDate.now().withDayOfMonth(1));
    to.setValue(LocalDate.now());
    String role = SessionManager.getInstance().getRole();
    if (role.equals("ADM")) report.getItems().addAll(ReportService.NAMES);
    else if (role.equals("ALM"))
      report
          .getItems()
          .addAll(
              "Stock disponible",
              "Stock bajo",
              "Compras por proveedor",
              "Movimientos de inventario");
    else if (role.equals("VEN"))
      report.getItems().addAll("Ventas por fecha", "Devoluciones y cambios");
    else report.getItems().add("Ventas por fecha");
    seller.setDisable(!role.equals("ADM"));
    cancel.setVisible(role.equals("ADM"));
    cancel.setManaged(cancel.isVisible());
    report.setOnAction(e -> load());
    report.getSelectionModel().selectFirst();
    load();
  }

  @FXML
  public void load() {
    Ui.run(
        () -> {
          rows =
              AppContext.getInstance()
                  .reports
                  .report(
                      report.getValue(),
                      from.getValue(),
                      to.getValue(),
                      seller.getText().isBlank() ? null : Long.parseLong(seller.getText()));
          new pe.edu.upeu.sysventas.components.TableViewHelper<>()
              .configure(
                  table,
                  rows,
                  pe.edu.upeu.sysventas.components.ReportColumns.forReport(report.getValue()));
          count.setText(rows.size() + " resultados");
          boolean sales = report.getValue().equals("Ventas por fecha");
          receipt.setDisable(!sales);
          details.setDisable(!sales);
          cancel.setDisable(!sales);
          note.setText(
              report.getValue().startsWith("Stock")
                  ? "Existencias actuales de todas las variantes; no dependen del periodo."
                  : report.getValue().equals("Devoluciones y cambios")
                      ? "Devoluciones asociadas a ventas del periodo seleccionado."
                      : "Importes brutos de ventas confirmadas; las devoluciones y anulaciones"
                          + " conservan su historial. Doble clic en una venta para ver su"
                          + " comprobante.");
        });
    table.setRowFactory(
        tv -> {
          TableRow<Map<String, Object>> r = new TableRow<>();
          r.setOnMouseClicked(
              e -> {
                if (e.getClickCount() == 2
                    && !r.isEmpty()
                    && report.getValue().equals("Ventas por fecha")) receipt();
              });
          return r;
        });
  }

  private long sale() {
    return Ui.id(table.getSelectionModel().getSelectedItem(), "id_venta");
  }

  @FXML
  public void receipt() {
    Ui.run(
        () ->
            new pe.edu.upeu.sysventas.components.comprob.ComprobanteView()
                .show(AppContext.getInstance().reports.comprobante(sale())));
  }

  @FXML
  public void export() {
    Ui.run(
        () -> {
          if (rows.isEmpty())
            throw new IllegalArgumentException("No hay resultados para exportar.");
          FileChooser chooser = new FileChooser();
          chooser.setInitialFileName("ModaUrbana-reporte.csv");
          var file = chooser.showSaveDialog(SysVentas.stage());
          if (file == null) return;
          StringBuilder out = new StringBuilder("\ufeff");
          out.append(String.join(";", rows.getFirst().keySet())).append('\n');
          for (var r : rows) {
            List<String> line = new ArrayList<>();
            for (Object v : r.values())
              line.add("\"" + Objects.toString(v, "").replace("\"", "\"\"") + "\"");
            out.append(String.join(";", line)).append('\n');
          }
          try {
            Files.writeString(file.toPath(), out);
          } catch (Exception e) {
            throw new IllegalStateException("No se pudo guardar el reporte", e);
          }
          Ui.info("Reporte exportado.");
        });
  }

  @FXML
  public void saveReceipt() {
    Ui.run(
        () -> {
          new pe.edu.upeu.sysventas.components.comprob.ComprobanteView()
              .exportPdf(AppContext.getInstance().reports.comprobante(sale()));
        });
  }

  @FXML
  public void cancel() {
    Ui.run(
        () -> {
          long id = sale();
          Ui.prompt("Anular venta", "Motivo de anulación (mínimo 5 caracteres)")
              .ifPresent(
                  reason -> {
                    if (Ui.confirm("Anular venta #" + id + " y reintegrar su stock.")) {
                      AppContext.getInstance().ventas.cancel(id, reason);
                      load();
                    }
                  });
        });
  }

  @FXML
  public void details() {
    Ui.run(
        () -> {
          long sale = sale();
          Dialog<Void> d = new Dialog<>();
          d.setTitle("Detalle de venta #" + sale);
          d.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
          TableView<Map<String, Object>> lines = new TableView<>();
          Ui.table(lines, AppContext.getInstance().reports.details(sale));
          lines.setPrefSize(950, 310);
          VBox box = new VBox(14, lines);
          if (!SessionManager.getInstance().getRole().equals("CLI")
              && !SessionManager.getInstance().isGuest()) {
            TextField quantity = Ui.text("Cantidad a devolver");
            quantity.setText("1");
            TextField reason = Ui.text("Motivo de devolución o cambio");
            ComboBox<Choice> exchange = new ComboBox<>();
            exchange.getItems().add(new Choice(0, "Devolver y reembolsar en efectivo (demo)"));
            for (var v : AppContext.getInstance().catalog.choices("variante"))
              exchange
                  .getItems()
                  .add(
                      new Choice(
                          ((Number) v.get("id_variante")).longValue(), v.get("nombre").toString()));
            exchange.getSelectionModel().selectFirst();
            Button confirm = new Button("Registrar devolución / cambio");
            confirm.getStyleClass().add("primary");
            confirm.setOnAction(
                e ->
                    Ui.run(
                        () -> {
                          long detail =
                              Ui.id(
                                  lines.getSelectionModel().getSelectedItem(), "id_venta_detalle");
                          if (!Ui.confirm(
                              "Confirmar devolución/cambio y sus movimientos de stock.")) return;
                          long id =
                              AppContext.getInstance()
                                  .devoluciones
                                  .returnItem(
                                      detail,
                                      Integer.parseInt(quantity.getText()),
                                      exchange.getValue().getId() == 0
                                          ? null
                                          : exchange.getValue().getId(),
                                      reason.getText());
                          Ui.table(lines, AppContext.getInstance().reports.details(sale));
                          load();
                          Ui.info(
                              "Devolución #"
                                  + id
                                  + " registrada. El reembolso se declara como demostrativo en la"
                                  + " auditoría.");
                        }));
            Label hint =
                new Label(
                    "Selecciona una línea. Los cambios directos requieren igual valor neto; para"
                        + " diferencias, registra devolución y nueva venta.");
            hint.setWrapText(true);
            hint.getStyleClass().add("muted");
            box.getChildren().addAll(hint, new HBox(12, quantity, exchange), reason, confirm);
          }
          d.getDialogPane().setContent(box);
          Ui.style(d);
          d.showAndWait();
        });
  }
}
