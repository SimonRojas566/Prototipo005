package pe.edu.upeu.sysventas.exceptions;

public class DatabaseException extends IllegalStateException {
  public DatabaseException(String message, Throwable cause) {
    super(message, cause);
  }
}
