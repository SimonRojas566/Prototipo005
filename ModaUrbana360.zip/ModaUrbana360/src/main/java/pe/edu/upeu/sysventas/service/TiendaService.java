package pe.edu.upeu.sysventas.service;

/** Fachada para componer las operaciones de la tienda. Cada operación tiene su contrato propio. */
public interface TiendaService
    extends VentaService, CompraService, InventarioService, DevolucionService {}
