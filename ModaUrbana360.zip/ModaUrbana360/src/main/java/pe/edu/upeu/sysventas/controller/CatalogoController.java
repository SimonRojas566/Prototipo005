package pe.edu.upeu.sysventas.controller;

import java.util.*;
import javafx.fxml.FXML;
import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.config.AppContext;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.Choice;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.util.*;

public class CatalogoController {
  @FXML private FlowPane cards;
  @FXML private TextField search, min, max, color;
  @FXML private ComboBox<Choice> brand, category;
  @FXML private ComboBox<String> size;
  @FXML private CheckBox available;
  @FXML private Label count;
  @FXML private Button cartCount;

  @FXML
  public void initialize() {
    Ui.run(
        () -> {
          brand.getItems().add(new Choice(0, "Todas las marcas"));
          category.getItems().add(new Choice(0, "Todas las categorías"));
          for (var x : AppContext.getInstance().catalog.choices("marca"))
            brand
                .getItems()
                .add(
                    new Choice(
                        ((Number) x.get("id_marca")).longValue(), x.get("nombre").toString()));
          for (var x : AppContext.getInstance().catalog.choices("categoria"))
            category
                .getItems()
                .add(
                    new Choice(
                        ((Number) x.get("id_categoria")).longValue(), x.get("nombre").toString()));
          brand.getSelectionModel().selectFirst();
          category.getSelectionModel().selectFirst();
          size.getItems().addAll("Todas", "XS", "S", "M", "L", "XL", "XXL", "Única");
          size.getSelectionModel().selectFirst();
          filter();
        });
  }

  private Long selected(ComboBox<Choice> c) {
    return c.getValue() == null || c.getValue().getId() == 0 ? null : c.getValue().getId();
  }

  @FXML
  public void filter() {
    Ui.run(
        () -> {
          var rows =
              AppContext.getInstance()
                  .catalog
                  .search(
                      search.getText(),
                      selected(brand),
                      selected(category),
                      size.getValue() == null || size.getValue().equals("Todas")
                          ? ""
                          : size.getValue(),
                      color.getText(),
                      min.getText().isBlank() ? null : Money.parse(min.getText()),
                      max.getText().isBlank() ? null : Money.parse(max.getText()),
                      available.isSelected());
          Map<Long, List<ProductoCatalogoDto>> grouped = new LinkedHashMap<>();
          for (var row : rows)
            grouped.computeIfAbsent(row.getIdProducto(), k -> new ArrayList<>()).add(row);
          cards.getChildren().clear();
          for (var variants : grouped.values()) cards.getChildren().add(card(variants));
          count.setText(grouped.size() + " prendas · " + rows.size() + " variantes");
          cartCount.setText(
              "Carrito: "
                  + CartState.lines.stream().mapToInt(x -> x.getCantidad()).sum()
                  + " unidades");
        });
  }

  private VBox card(List<ProductoCatalogoDto> variants) {
    var p = variants.getFirst();
    VBox card = new VBox(10);
    card.getStyleClass().add("product-card");
    card.setPrefWidth(260);
    card.setMaxWidth(260);
    Label brandLabel = new Label(p.getMarca().toUpperCase());
    brandLabel.getStyleClass().add("eyebrow");
    Label name = new Label(p.getNombre());
    name.getStyleClass().add("product-name");
    name.setWrapText(true);
    Label desc = new Label(p.getDescripcion());
    desc.setWrapText(true);
    desc.getStyleClass().add("muted");
    desc.setMinHeight(36);
    Label price = new Label();
    price.getStyleClass().add("price");
    ComboBox<Choice> variant = new ComboBox<>();
    variant.setMaxWidth(Double.MAX_VALUE);
    Label stock = new Label();
    stock.getStyleClass().add("muted");
    for (var v : variants)
      variant.getItems().add(new Choice(v.getIdVariante(), v.getTalla() + " / " + v.getColor()));
    Runnable update =
        () -> {
          var v =
              variants.stream()
                  .filter(x -> x.getIdVariante() == variant.getValue().getId())
                  .findFirst()
                  .orElseThrow();
          price.setText(Money.soles(v.getPrecioVenta()));
          stock.setText(v.getSku() + " · " + v.getStockActual() + " disponibles");
        };
    variant.setOnAction(e -> update.run());
    variant.getSelectionModel().selectFirst();
    update.run();
    Button add = new Button("Agregar al carrito  ＋");
    add.setMaxWidth(Double.MAX_VALUE);
    add.getStyleClass().add("primary");
    add.setOnAction(
        e ->
            Ui.run(
                () -> {
                  var v =
                      variants.stream()
                          .filter(x -> x.getIdVariante() == variant.getValue().getId())
                          .findFirst()
                          .orElseThrow();
                  int inCart =
                      CartState.lines.stream()
                          .filter(l -> l.getVariante() == variant.getValue().getId())
                          .mapToInt(l -> l.getCantidad())
                          .sum();
                  if (inCart >= v.getStockActual())
                    throw new IllegalArgumentException(
                        "No hay más unidades disponibles de esta variante.");
                  CartState.add(variant.getValue().getId(), 1);
                  cartCount.setText(
                      "Carrito: "
                          + CartState.lines.stream().mapToInt(x -> x.getCantidad()).sum()
                          + " unidades");
                  add.setText("Agregado ✓");
                }));
    add.setVisible(!"ALM".equals(SessionManager.getInstance().getRole()));
    add.setManaged(add.isVisible());
    card.getChildren().addAll(brandLabel, name, desc, price, variant, stock, add);
    return card;
  }

  @FXML
  public void cart() {
    if (!"ALM".equals(SessionManager.getInstance().getRole()))
      SysVentas.page("venta", "Carrito y pagos");
  }
}
