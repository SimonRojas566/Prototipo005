package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/**
 * Entidad de la tabla compra_detalle. Las relaciones se identifican mediante sus claves foráneas.
 */
public class CompraDetalle {
  private Long idCompraDetalle = null;
  private Long idCompra = null;
  private Long idVariante = null;
  private BigDecimal pu = BigDecimal.ZERO;
  private Integer cantidad = 0;
  private BigDecimal subtotal = BigDecimal.ZERO;

  public CompraDetalle() {}

  public Long getIdCompraDetalle() {
    return idCompraDetalle;
  }

  public void setIdCompraDetalle(Long idCompraDetalle) {
    this.idCompraDetalle = idCompraDetalle;
  }

  public Long getIdCompra() {
    return idCompra;
  }

  public void setIdCompra(Long idCompra) {
    this.idCompra = idCompra;
  }

  public Long getIdVariante() {
    return idVariante;
  }

  public void setIdVariante(Long idVariante) {
    this.idVariante = idVariante;
  }

  public BigDecimal getPu() {
    return pu;
  }

  public void setPu(BigDecimal pu) {
    this.pu = pu;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public void setCantidad(Integer cantidad) {
    this.cantidad = cantidad;
  }

  public BigDecimal getSubtotal() {
    return subtotal;
  }

  public void setSubtotal(BigDecimal subtotal) {
    this.subtotal = subtotal;
  }
}
