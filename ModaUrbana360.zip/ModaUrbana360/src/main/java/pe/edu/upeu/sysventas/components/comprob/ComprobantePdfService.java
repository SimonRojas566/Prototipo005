package pe.edu.upeu.sysventas.components.comprob;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.awt.Color;
import java.io.OutputStream;
import java.nio.file.*;
import java.time.format.DateTimeFormatter;
import pe.edu.upeu.sysventas.dto.comprobante.*;
import pe.edu.upeu.sysventas.enums.TipoDocumento;
import pe.edu.upeu.sysventas.util.Money;

/** Documento vectorial A4 con filas paginables y cabecera repetida. No contiene imágenes. */
public class ComprobantePdfService {
  private Paragraph paragraph(String text) {
    return paragraph(text, font(10, false, INK));
  }

  private static final Color INK = new Color(45, 38, 55);
  private static final Color PURPLE = new Color(102, 62, 135);
  private static final Color LIGHT = new Color(246, 243, 249);
  private static final Color BORDER = new Color(220, 216, 225);

  private Paragraph paragraph(String text, Font font) {
    return new Paragraph(pe.edu.upeu.sysventas.util.I18n.t(text), font);
  }

  private Font font(int size, boolean bold, Color color) {
    return FontFactory.getFont(
        bold ? FontFactory.HELVETICA_BOLD : FontFactory.HELVETICA, size, color);
  }

  public void exportar(Comprobante comprobante, Path destino) throws Exception {
    try (OutputStream stream = Files.newOutputStream(destino)) {
      exportar(comprobante, stream);
    }
  }

  public void exportar(Comprobante comprobante, OutputStream stream) throws Exception {
    Document document = new Document(PageSize.A4, 36, 36, 36, 42);
    PdfWriter writer = PdfWriter.getInstance(document, stream);
    writer.setPageEvent(
        new PdfPageEventHelper() {
          @Override
          public void onEndPage(PdfWriter pdf, Document doc) {
            ColumnText.showTextAligned(
                pdf.getDirectContent(),
                Element.ALIGN_RIGHT,
                new Phrase(
                    pe.edu.upeu.sysventas.util.I18n.t(
                        "Moda Urbana 360 · Página " + pdf.getPageNumber()),
                    font(8, false, INK)),
                doc.right(),
                22,
                0);
          }
        });
    document.addTitle("Comprobante Moda Urbana 360");
    document.addAuthor("Moda Urbana 360");
    document.open();
    try {
      document.add(header(comprobante));
      document.add(paragraph(" "));
      document.add(
          paragraph(pe.edu.upeu.sysventas.util.I18n.t("DATOS DEL CLIENTE"), font(11, true, INK)));
      PdfPTable client = table(new float[] {1, 4});
      client.addCell(cell("Documento", true, false));
      client.addCell(cell(comprobante.getDocumentoCliente(), false, false));
      client.addCell(cell("Cliente", true, false));
      client.addCell(cell(comprobante.getCliente(), false, false));
      client.addCell(cell("Responsable", true, false));
      client.addCell(cell(comprobante.getResponsable(), false, false));
      document.add(client);
      document.add(paragraph(" "));
      document.add(paragraph(pe.edu.upeu.sysventas.util.I18n.t("DETALLE"), font(11, true, INK)));
      PdfPTable items = table(new float[] {.75f, 2.7f, 1, 1, 1.1f});
      for (String title :
          new String[] {"CANT.", "DESCRIPCIÓN", "P. UNIT.", "DESCUENTO", "SUBTOTAL"})
        items.addCell(cell(title, true, true));
      items.setHeaderRows(1);
      items.setSplitLate(true);
      for (ItemComprobante item : comprobante.getItems()) {
        items.addCell(cell(item.getCantidad().toString(), false, false));
        items.addCell(cell(item.getNombre() + "\nSKU: " + item.getSku(), false, false));
        items.addCell(amount(Money.soles(item.getPrecioUnitario())));
        items.addCell(amount(Money.soles(item.getDescuento())));
        items.addCell(amount(Money.soles(item.getSubtotal())));
      }
      document.add(items);
      document.add(paragraph(" "));
      PdfPTable totals = table(new float[] {3, 1.3f, 1.3f});
      PdfPCell note =
          cell(
              "Estado: "
                  + comprobante.getVenta().getEstado()
                  + "\nMoneda: PEN\nPrecios con impuesto incluido.",
              false,
              false);
      note.setRowspan(4);
      note.setBorder(Rectangle.NO_BORDER);
      totals.addCell(note);
      totals.addCell(cell("Op. gravadas", true, false));
      totals.addCell(amount(Money.soles(comprobante.getVenta().getPrecioBase())));
      totals.addCell(cell("IGV incluido", true, false));
      totals.addCell(amount(Money.soles(comprobante.getVenta().getIgv())));
      totals.addCell(cell("Descuento", true, false));
      totals.addCell(amount(Money.soles(comprobante.getVenta().getDescuentoTotal())));
      totals.addCell(cell("TOTAL", true, true));
      totals.addCell(cell(Money.soles(comprobante.getVenta().getPrecioTotal()), true, true));
      totals.setKeepTogether(true);
      document.add(totals);
      document.add(paragraph(" "));
      document.add(
          paragraph(pe.edu.upeu.sysventas.util.I18n.t("PAGOS DECLARADOS"), font(10, true, INK)));
      for (PagoComprobante pago : comprobante.getPagos())
        document.add(
            paragraph(
                pago.getNombre()
                    + ": "
                    + Money.soles(pago.getMonto())
                    + (pago.getReferencia().isBlank() ? "" : " · " + pago.getReferencia()),
                font(10, false, INK)));
      if (!comprobante.getDevoluciones().isEmpty()) {
        document.add(
            paragraph(
                pe.edu.upeu.sysventas.util.I18n.t("DEVOLUCIONES Y CAMBIOS"), font(10, true, INK)));
        for (DevolucionComprobante item : comprobante.getDevoluciones())
          document.add(
              paragraph(
                  "#"
                      + item.getIdDevolucion()
                      + " · "
                      + item.getTipo()
                      + " · "
                      + item.getCantidad()
                      + " unidades · "
                      + item.getSku(),
                  font(10, false, INK)));
      }
      Paragraph footer =
          paragraph(
              "\n"
                  + "DOCUMENTO DEMOSTRATIVO SIN VALIDEZ TRIBUTARIA\n"
                  + "Aplicación académica local · Sin emisión ante SUNAT",
              font(9, false, INK));
      footer.setAlignment(Element.ALIGN_CENTER);
      document.add(footer);
    } finally {
      document.close();
    }
  }

  private PdfPTable header(Comprobante comprobante) {
    var venta = comprobante.getVenta();
    PdfPTable header = table(new float[] {1, 1});
    PdfPCell emisor =
        cell(
            "MODA URBANA 360\nTienda de ropa\nSistema académico de ventas e inventario",
            true,
            false);
    emisor.setBorder(Rectangle.NO_BORDER);
    header.addCell(emisor);
    PdfPCell document =
        cell(
            TipoDocumento.fromStored(venta.getTipoDoc())
                    .getTitulo()
                    .toUpperCase(java.util.Locale.ROOT)
                + "\nDEMONSTRATIVA\n"
                + venta.getSerie()
                + " - "
                + venta.getNumDoc()
                + "\nFecha: "
                + venta.getFechaGener().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
            true,
            false);
    document.setHorizontalAlignment(Element.ALIGN_CENTER);
    document.setBorderColor(PURPLE);
    document.setBorderWidth(1.5f);
    header.addCell(document);
    return header;
  }

  private PdfPTable table(float[] widths) {
    PdfPTable table = new PdfPTable(widths);
    table.setWidthPercentage(100);
    table.setSpacingBefore(7);
    return table;
  }

  private PdfPCell amount(String value) {
    PdfPCell cell = cell(value, false, false);
    cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    return cell;
  }

  private PdfPCell cell(String text, boolean bold, boolean band) {
    PdfPCell cell =
        new PdfPCell(
            new Phrase(
                pe.edu.upeu.sysventas.util.I18n.t(text), font(10, bold, band ? Color.WHITE : INK)));
    cell.setPadding(8);
    cell.setBorderColor(BORDER);
    cell.setBackgroundColor(band ? PURPLE : LIGHT);
    cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
    return cell;
  }
}
