package pe.edu.upeu.sysventas.repository;

import java.util.*;

public class RepositoryRegistry {
  private final Map<String, AbstractJdbcRepository<?>> repositories = new LinkedHashMap<>();

  public RepositoryRegistry(SqlRepository db) {
    repositories.put("perfil", new PerfilRepository(db));
    repositories.put("usuario", new UsuarioRepository(db));
    repositories.put("nivel_cliente", new NivelClienteRepository(db));
    repositories.put("cliente", new ClienteRepository(db));
    repositories.put("marca", new MarcaRepository(db));
    repositories.put("categoria", new CategoriaRepository(db));
    repositories.put("unid_medida", new UnidMedidaRepository(db));
    repositories.put("genero", new GeneroRepository(db));
    repositories.put("temporada", new TemporadaRepository(db));
    repositories.put("producto", new ProductoRepository(db));
    repositories.put("variante", new VarianteRepository(db));
    repositories.put("proveedor", new ProveedorRepository(db));
    repositories.put("canal_venta", new CanalVentaRepository(db));
    repositories.put("metodo_pago", new MetodoPagoRepository(db));
    repositories.put("promocion", new PromocionRepository(db));
    repositories.put("venta", new VentaRepository(db));
    repositories.put("venta_detalle", new VentaDetalleRepository(db));
    repositories.put("venta_pago", new VentaPagoRepository(db));
    repositories.put("compra", new CompraRepository(db));
    repositories.put("compra_detalle", new CompraDetalleRepository(db));
    repositories.put("devolucion", new DevolucionRepository(db));
    repositories.put("devolucion_detalle", new DevolucionDetalleRepository(db));
    repositories.put("movimiento_stock", new MovimientoStockRepository(db));
    repositories.put("auditoria", new AuditoriaRepository(db));
  }

  public AbstractJdbcRepository<?> get(String table) {
    var repository = repositories.get(table);
    if (repository == null) throw new IllegalArgumentException("Entidad desconocida: " + table);
    return repository;
  }

  public Set<String> tables() {
    return Collections.unmodifiableSet(repositories.keySet());
  }
}
