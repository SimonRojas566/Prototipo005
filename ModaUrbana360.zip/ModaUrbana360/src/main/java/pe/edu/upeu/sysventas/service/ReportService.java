package pe.edu.upeu.sysventas.service;

import java.math.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.*;

/** Contrato de la capa de negocio utilizado por los controladores. */
public interface ReportService {
  pe.edu.upeu.sysventas.dto.comprobante.Comprobante comprobante(long sale);

  public static final List<String> NAMES =
      List.of(
          "Ventas por fecha",
          "Ventas por vendedor",
          "Productos más vendidos",
          "Ventas por marca",
          "Ventas por categoría",
          "Stock disponible",
          "Stock bajo",
          "Compras por proveedor",
          "Movimientos de inventario",
          "Historial de operaciones",
          "Devoluciones y cambios",
          "Ingresos por método de pago");

  List<Map<String, Object>> report(String name, LocalDate from, LocalDate to, Long seller);

  List<Map<String, Object>> details(long sale);

  String receipt(long sale);
}
