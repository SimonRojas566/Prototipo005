package pe.edu.upeu.sysventas.dto;

import java.math.BigDecimal;

/** Proyección del catálogo: datos descriptivos del producto y existencias por variante. */
public class ProductoCatalogoDto {
  private Long idVariante;
  private Long idProducto;
  private String nombre;
  private String descripcion;
  private String marca;
  private String categoria;
  private String talla;
  private String color;
  private String sku;
  private BigDecimal precioVenta;
  private BigDecimal costo;
  private Integer stockActual;
  private Integer stockMinimo;

  public Long getIdVariante() {
    return idVariante;
  }

  public void setIdVariante(Long value) {
    this.idVariante = value;
  }

  public Long getIdProducto() {
    return idProducto;
  }

  public void setIdProducto(Long value) {
    this.idProducto = value;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String value) {
    this.nombre = value;
  }

  public String getDescripcion() {
    return descripcion;
  }

  public void setDescripcion(String value) {
    this.descripcion = value;
  }

  public String getMarca() {
    return marca;
  }

  public void setMarca(String value) {
    this.marca = value;
  }

  public String getCategoria() {
    return categoria;
  }

  public void setCategoria(String value) {
    this.categoria = value;
  }

  public String getTalla() {
    return talla;
  }

  public void setTalla(String value) {
    this.talla = value;
  }

  public String getColor() {
    return color;
  }

  public void setColor(String value) {
    this.color = value;
  }

  public String getSku() {
    return sku;
  }

  public void setSku(String value) {
    this.sku = value;
  }

  public BigDecimal getPrecioVenta() {
    return precioVenta;
  }

  public void setPrecioVenta(BigDecimal value) {
    this.precioVenta = value;
  }

  public BigDecimal getCosto() {
    return costo;
  }

  public void setCosto(BigDecimal value) {
    this.costo = value;
  }

  public Integer getStockActual() {
    return stockActual;
  }

  public void setStockActual(Integer value) {
    this.stockActual = value;
  }

  public Integer getStockMinimo() {
    return stockMinimo;
  }

  public void setStockMinimo(Integer value) {
    this.stockMinimo = value;
  }
}
