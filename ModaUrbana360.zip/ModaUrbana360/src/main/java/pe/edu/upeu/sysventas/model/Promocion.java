package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/** Entidad de la tabla promocion. Las relaciones se identifican mediante sus claves foráneas. */
public class Promocion {
  private Long idPromocion = null;
  private String nombre = null;
  private String tipo = null;
  private BigDecimal valor = BigDecimal.ZERO;
  private LocalDate fechaInicio = null;
  private LocalDate fechaFin = null;
  private Long idCategoria = null;
  private Long idMarca = null;
  private Long idProducto = null;
  private String estado = "Activo";

  public Promocion() {}

  public Long getIdPromocion() {
    return idPromocion;
  }

  public void setIdPromocion(Long idPromocion) {
    this.idPromocion = idPromocion;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public BigDecimal getValor() {
    return valor;
  }

  public void setValor(BigDecimal valor) {
    this.valor = valor;
  }

  public LocalDate getFechaInicio() {
    return fechaInicio;
  }

  public void setFechaInicio(LocalDate fechaInicio) {
    this.fechaInicio = fechaInicio;
  }

  public LocalDate getFechaFin() {
    return fechaFin;
  }

  public void setFechaFin(LocalDate fechaFin) {
    this.fechaFin = fechaFin;
  }

  public Long getIdCategoria() {
    return idCategoria;
  }

  public void setIdCategoria(Long idCategoria) {
    this.idCategoria = idCategoria;
  }

  public Long getIdMarca() {
    return idMarca;
  }

  public void setIdMarca(Long idMarca) {
    this.idMarca = idMarca;
  }

  public Long getIdProducto() {
    return idProducto;
  }

  public void setIdProducto(Long idProducto) {
    this.idProducto = idProducto;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }
}
