package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.Money;

/** Reglas y transacciones de venta. */
public class VentaServiceImpl implements VentaService {
  private final SqlRepository db;
  private final AuthService auth;
  private final MovimientoStockRepository movimientos;

  public VentaServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
    this.movimientos = new MovimientoStockRepository(db);
  }

  public Quote quote(List<CartLine> cart, Long client, BigDecimal manual) {
    return db.read(
        c -> {
          auth.require(c, "ADM", "VEN", "CLI");
          Long actual = clientFor(c, client);
          return calculate(c, cart, actual, manual, false);
        });
  }

  public long sell(
      List<CartLine> cart,
      Long client,
      List<Payment> payments,
      BigDecimal manual,
      TipoDocumento documento) {
    long result =
        db.transaction(
            c -> {
              long user = auth.require(c, "ADM", "VEN", "CLI");
              Long actual = clientFor(c, client);
              Quote q = calculate(c, cart, actual, manual, true);
              if (payments == null || (payments.isEmpty() && q.getTotal().signum() > 0))
                throw new IllegalArgumentException("Registra al menos un pago.");
              BigDecimal paid = Money.ZERO;
              for (Payment p : payments) {
                db.one(
                    c,
                    "SELECT id_metodo_pago FROM metodo_pago WHERE id_metodo_pago=?",
                    p.getMetodo());
                paid = paid.add(p.getMonto());
              }
              if (paid.compareTo(q.getTotal()) != 0)
                throw new IllegalArgumentException(
                    "La suma de pagos debe coincidir con el total actualizado: "
                        + Money.soles(q.getTotal()));
              boolean customer =
                  "CLI".equals(SessionManager.getInstance().getRole())
                      || SessionManager.getInstance().isGuest();
              long channel =
                  ((Number)
                          db.one(
                                  c,
                                  "SELECT id_canal FROM canal_venta WHERE nombre=?",
                                  customer ? "Catálogo escritorio" : "Tienda")
                              .get("id_canal"))
                      .longValue();
              long id =
                  ((Number) db.one(c, "SELECT NEXT VALUE FOR venta_numero AS id").get("id"))
                      .longValue();
              Venta venta = new Venta();
              venta.setIdVenta(id);
              venta.setSerie(
                  java.util.Objects.requireNonNull(documento, "Selecciona el comprobante")
                      .getSerie());
              venta.setNumDoc(String.format("%08d", id));
              venta.setTipoDoc(documento.getValor());
              venta.setPrecioBase(q.getBase());
              venta.setIgv(q.getTax());
              venta.setDescuentoTotal(q.getDiscount());
              venta.setPrecioTotal(q.getTotal());
              venta.setIdCliente(actual);
              venta.setIdUsuario(user);
              venta.setIdCanal(channel);
              venta.setEstado(EstadoOperacion.CONFIRMADA.getCodigo());
              new VentaRepository(db).insert(c, venta);
              for (Detail l : q.getLines()) {
                VentaDetalle detalle = new VentaDetalle();
                detalle.setIdVenta(id);
                detalle.setIdVariante(l.getVariant());
                detalle.setPu(l.getPrice());
                detalle.setCantidad(l.getQuantity());
                detalle.setDescuento(l.getDiscount());
                detalle.setSubtotal(l.getSubtotal());
                detalle.setIdPromocion(l.getPromotion());
                new VentaDetalleRepository(db).insert(c, detalle);
                if (db.update(
                        c,
                        "UPDATE variante SET stock_actual=stock_actual-? WHERE id_variante=? AND"
                            + " stock_actual>=?",
                        l.getQuantity(),
                        l.getVariant(),
                        l.getQuantity())
                    != 1)
                  throw new IllegalArgumentException(
                      "Cambió la disponibilidad. Vuelve a consultar el carrito.");
                movimientos.registrar(
                    c, l.getVariant(), "SALIDA_VENTA", -l.getQuantity(), "VENTA:" + id, user);
              }
              for (Payment p : payments) {
                VentaPago pago = new VentaPago();
                pago.setIdVenta(id);
                pago.setIdMetodoPago(p.getMetodo());
                pago.setMonto(p.getMonto());
                pago.setReferencia(p.getReferencia());
                new VentaPagoRepository(db).insert(c, pago);
              }
              db.audit(
                  c,
                  user,
                  "CONFIRMAR",
                  "venta",
                  id,
                  "Total " + q.getTotal() + "; descuento " + q.getDiscount());
              return id;
            });
    SessionManager.getInstance().rememberGuestSale(result);
    return result;
  }

  public void cancel(long sale, String reason) {
    if (reason == null || reason.trim().length() < 5)
      throw new IllegalArgumentException("Indica el motivo de la anulación.");
    db.transaction(
        c -> {
          long u = auth.require(c, "ADM");
          Venta s = new VentaRepository(db).findByIdForUpdate(c, sale);
          if (!EstadoOperacion.CONFIRMADA.getCodigo().equals(s.getEstado()))
            throw new IllegalArgumentException("La venta ya está anulada.");
          if (!db.query(c, "SELECT id_devolucion FROM devolucion WHERE id_venta=?", sale).isEmpty())
            throw new IllegalArgumentException(
                "La venta ya tiene devoluciones. Gestiona el saldo mediante devolución para evitar"
                    + " una doble reversión.");
          for (var l :
              db.query(
                  c,
                  "SELECT id_variante,cantidad FROM venta_detalle WHERE id_venta=? ORDER BY"
                      + " id_variante",
                  sale)) {
            long v = ((Number) l.get("id_variante")).longValue();
            int n = ((Number) l.get("cantidad")).intValue();
            db.update(
                c, "UPDATE variante SET stock_actual=stock_actual+? WHERE id_variante=?", n, v);
            movimientos.registrar(c, v, "ANULACION_VENTA", n, "VENTA:" + sale, u);
          }
          db.update(c, "UPDATE venta SET estado='Anulada' WHERE id_venta=?", sale);
          db.audit(
              c,
              u,
              "ANULAR",
              "venta",
              sale,
              reason + "; reintegro demostrativo del total " + s.getPrecioTotal());
          return null;
        });
  }

  private Long clientFor(Connection c, Long selected) throws SQLException {
    if (SessionManager.getInstance().isGuest()) return null;
    ClienteRepository clientes = new ClienteRepository(db);
    if (Rol.CLIENTE.getCodigo().equals(SessionManager.getInstance().getRole())) {
      return clientes.findByUsuario(c, SessionManager.getInstance().getUserId()).getIdCliente();
    }
    if (selected != null) clientes.findById(c, selected);
    return selected;
  }

  private Quote calculate(
      Connection c, List<CartLine> cart, Long client, BigDecimal manual, boolean lock)
      throws SQLException {
    if (cart == null || cart.isEmpty())
      throw new IllegalArgumentException("El carrito está vacío.");
    if (manual == null) manual = BigDecimal.ZERO;
    if (manual.signum() < 0 || manual.compareTo(new BigDecimal("100")) > 0)
      throw new IllegalArgumentException("El descuento debe estar entre 0 y 100.");
    if (manual.signum() > 0) auth.require(c, "ADM");
    BigDecimal level = BigDecimal.ZERO;
    if (client != null) {
      Cliente cliente = new ClienteRepository(db).findById(c, client);
      level = new NivelClienteRepository(db).findById(c, cliente.getIdNivel()).getDescuentoPct();
    }
    Map<Long, Integer> quantities = new TreeMap<>();
    for (CartLine line : cart)
      quantities.merge(line.getVariante(), line.getCantidad(), Math::addExact);
    List<Detail> lines = new ArrayList<>();
    BigDecimal total = Money.ZERO, discount = Money.ZERO;
    for (var entry : quantities.entrySet()) {
      VarianteRepository variantes = new VarianteRepository(db);
      Variante v =
          lock
              ? variantes.findByIdForUpdate(c, entry.getKey())
              : variantes.findById(c, entry.getKey());
      Producto producto = new ProductoRepository(db).findById(c, v.getIdProducto());
      int qty = entry.getValue();
      if (!EstadoRegistro.ACTIVO.getCodigo().equals(producto.getEstado())) {
        throw new IllegalArgumentException("El producto está inactivo.");
      }
      if (qty > v.getStockActual()) {
        throw new IllegalArgumentException(
            "Stock insuficiente para " + v.getSku() + ". Disponible: " + v.getStockActual());
      }
      BigDecimal price = v.getPrecioVenta();
      BigDecimal gross = price.multiply(BigDecimal.valueOf(qty));
      BigDecimal best = Money.of(gross.multiply(level.max(manual)).divide(new BigDecimal("100")));
      Long promo = null;
      List<Promocion> promos =
          new PromocionRepository(db)
              .findVigentes(
                  c, producto.getIdProducto(), producto.getIdMarca(), producto.getIdCategoria());
      for (var p : promos) {
        BigDecimal value = p.getValor();
        BigDecimal amount =
            TipoPromocion.PORCENTAJE.getCodigo().equals(p.getTipo())
                ? Money.of(gross.multiply(value).divide(new BigDecimal("100")))
                : value.multiply(BigDecimal.valueOf(qty));
        amount = amount.min(gross);
        if (amount.compareTo(best) > 0) {
          best = amount;
          promo = p.getIdPromocion();
        }
      }
      best = best.min(gross);
      BigDecimal subtotal = gross.subtract(best);
      total = total.add(subtotal);
      discount = discount.add(best);
      lines.add(
          new Detail(
              entry.getKey(), v.getSku(), producto.getNombre(), qty, price, best, subtotal, promo));
    }
    BigDecimal base = Money.base(total);
    return new Quote(List.copyOf(lines), base, total.subtract(base), discount, total);
  }
}
