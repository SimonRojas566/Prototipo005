package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.NivelCliente;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para nivel_cliente. No abre conexiones dentro de una transacción. */
public class NivelClienteRepository extends AbstractJdbcRepository<NivelCliente> {
  public NivelClienteRepository(SqlRepository db) {
    super(db, "nivel_cliente", "id_nivel");
  }

  @Override
  public NivelCliente fromRow(Map<String, Object> row) {
    NivelCliente entity = new NivelCliente();
    if (row.containsKey("id_nivel")) entity.setIdNivel(SqlHelper.longValue(row.get("id_nivel")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    if (row.containsKey("descuento_pct"))
      entity.setDescuentoPct(SqlHelper.decimalValue(row.get("descuento_pct")));
    if (row.containsKey("puntos_minimos"))
      entity.setPuntosMinimos(SqlHelper.integerValue(row.get("puntos_minimos")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(NivelCliente entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_nivel", entity.getIdNivel());
    row.put("nombre", entity.getNombre());
    row.put("descuento_pct", entity.getDescuentoPct());
    row.put("puntos_minimos", entity.getPuntosMinimos());
    return row;
  }
}
