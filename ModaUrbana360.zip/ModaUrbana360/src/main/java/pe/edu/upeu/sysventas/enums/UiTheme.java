package pe.edu.upeu.sysventas.enums;

public enum UiTheme {
  PURPLE("Morado", "moda.css"),
  BLACK("Negro", "black.css"),
  WHITE("Blanco", "white.css"),
  GREEN("Verde", "green.css");
  private final String title;
  private final String css;

  UiTheme(String title, String css) {
    this.title = title;
    this.css = css;
  }

  public String getTitle() {
    return title;
  }

  public String getCss() {
    return "/css/" + css;
  }
}
