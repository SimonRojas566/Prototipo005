package pe.edu.upeu.sysventas.config;

import pe.edu.upeu.sysventas.repository.SqlRepository;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.service.impl.*;

/** Conserva la inyección manual de dependencias de la base de Unidad 1. */
public final class AppContext {
  private static final AppContext INSTANCE = new AppContext();
  public final SqlRepository db = new SqlRepository();
  public final AuthService auth = new AuthServiceImpl(db);
  public final CatalogService catalog = new CatalogServiceImpl(db, auth);
  public final VentaService ventas = new VentaServiceImpl(db, auth);
  public final CompraService compras = new CompraServiceImpl(db, auth);
  public final InventarioService inventario = new InventarioServiceImpl(db, auth);
  public final DevolucionService devoluciones = new DevolucionServiceImpl(db, auth);
  public final TiendaService tienda =
      new TiendaServiceImpl(ventas, compras, inventario, devoluciones);
  public final AdminService admin = new AdminServiceImpl(db, auth);
  public final ReportService reports = new ReportServiceImpl(db, auth);

  private AppContext() {}

  public static AppContext getInstance() {
    return INSTANCE;
  }
}
