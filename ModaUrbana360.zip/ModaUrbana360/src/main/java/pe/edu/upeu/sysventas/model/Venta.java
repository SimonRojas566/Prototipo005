package pe.edu.upeu.sysventas.model;

import java.math.BigDecimal;
import java.time.*;

/** Entidad de la tabla venta. Las relaciones se identifican mediante sus claves foráneas. */
public class Venta {
  private Long idVenta = null;
  private String serie = null;
  private String numDoc = null;
  private String tipoDoc = null;
  private LocalDateTime fechaGener = LocalDateTime.now();
  private BigDecimal precioBase = BigDecimal.ZERO;
  private BigDecimal igv = BigDecimal.ZERO;
  private BigDecimal descuentoTotal = BigDecimal.ZERO;
  private BigDecimal precioTotal = BigDecimal.ZERO;
  private Long idCliente = null;
  private Long idUsuario = null;
  private Long idCanal = null;
  private String estado = "Confirmada";

  public Venta() {}

  public Long getIdVenta() {
    return idVenta;
  }

  public void setIdVenta(Long idVenta) {
    this.idVenta = idVenta;
  }

  public String getSerie() {
    return serie;
  }

  public void setSerie(String serie) {
    this.serie = serie;
  }

  public String getNumDoc() {
    return numDoc;
  }

  public void setNumDoc(String numDoc) {
    this.numDoc = numDoc;
  }

  public String getTipoDoc() {
    return tipoDoc;
  }

  public void setTipoDoc(String tipoDoc) {
    this.tipoDoc = tipoDoc;
  }

  public LocalDateTime getFechaGener() {
    return fechaGener;
  }

  public void setFechaGener(LocalDateTime fechaGener) {
    this.fechaGener = fechaGener;
  }

  public BigDecimal getPrecioBase() {
    return precioBase;
  }

  public void setPrecioBase(BigDecimal precioBase) {
    this.precioBase = precioBase;
  }

  public BigDecimal getIgv() {
    return igv;
  }

  public void setIgv(BigDecimal igv) {
    this.igv = igv;
  }

  public BigDecimal getDescuentoTotal() {
    return descuentoTotal;
  }

  public void setDescuentoTotal(BigDecimal descuentoTotal) {
    this.descuentoTotal = descuentoTotal;
  }

  public BigDecimal getPrecioTotal() {
    return precioTotal;
  }

  public void setPrecioTotal(BigDecimal precioTotal) {
    this.precioTotal = precioTotal;
  }

  public Long getIdCliente() {
    return idCliente;
  }

  public void setIdCliente(Long idCliente) {
    this.idCliente = idCliente;
  }

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public Long getIdCanal() {
    return idCanal;
  }

  public void setIdCanal(Long idCanal) {
    this.idCanal = idCanal;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }
}
