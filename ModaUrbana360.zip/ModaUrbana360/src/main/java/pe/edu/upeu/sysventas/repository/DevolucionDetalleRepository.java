package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.DevolucionDetalle;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/**
 * Persistencia JDBC tipada para devolucion_detalle. No abre conexiones dentro de una transacción.
 */
public class DevolucionDetalleRepository extends AbstractJdbcRepository<DevolucionDetalle> {
  public DevolucionDetalleRepository(SqlRepository db) {
    super(db, "devolucion_detalle", "id_dev_detalle");
  }

  @Override
  public DevolucionDetalle fromRow(Map<String, Object> row) {
    DevolucionDetalle entity = new DevolucionDetalle();
    if (row.containsKey("id_dev_detalle"))
      entity.setIdDevDetalle(SqlHelper.longValue(row.get("id_dev_detalle")));
    if (row.containsKey("id_devolucion"))
      entity.setIdDevolucion(SqlHelper.longValue(row.get("id_devolucion")));
    if (row.containsKey("id_venta_detalle"))
      entity.setIdVentaDetalle(SqlHelper.longValue(row.get("id_venta_detalle")));
    if (row.containsKey("id_variante_devuelta"))
      entity.setIdVarianteDevuelta(SqlHelper.longValue(row.get("id_variante_devuelta")));
    if (row.containsKey("cantidad"))
      entity.setCantidad(SqlHelper.integerValue(row.get("cantidad")));
    if (row.containsKey("id_variante_cambio"))
      entity.setIdVarianteCambio(SqlHelper.longValue(row.get("id_variante_cambio")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(DevolucionDetalle entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_dev_detalle", entity.getIdDevDetalle());
    row.put("id_devolucion", entity.getIdDevolucion());
    row.put("id_venta_detalle", entity.getIdVentaDetalle());
    row.put("id_variante_devuelta", entity.getIdVarianteDevuelta());
    row.put("cantidad", entity.getCantidad());
    row.put("id_variante_cambio", entity.getIdVarianteCambio());
    return row;
  }
}
