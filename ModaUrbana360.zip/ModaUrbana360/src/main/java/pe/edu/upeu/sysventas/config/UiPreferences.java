package pe.edu.upeu.sysventas.config;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Properties;
import pe.edu.upeu.sysventas.enums.*;

/** Preferencias locales independientes de H2, con escritura mediante archivo temporal. */
public final class UiPreferences {
  private final Path file;
  private UiTheme theme = UiTheme.PURPLE;
  private UiLanguage language = UiLanguage.SPANISH;

  public UiPreferences(Path file) {
    this.file = file.toAbsolutePath();
    Properties values = new Properties();
    if (Files.isRegularFile(file))
      try (var reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
        values.load(reader);
      } catch (IOException ignored) {
      }
    try {
      theme = UiTheme.valueOf(values.getProperty("theme", "PURPLE"));
    } catch (IllegalArgumentException ignored) {
    }
    try {
      language = UiLanguage.valueOf(values.getProperty("language", "SPANISH"));
    } catch (IllegalArgumentException ignored) {
    }
  }

  public UiTheme getTheme() {
    return theme;
  }

  public UiLanguage getLanguage() {
    return language;
  }

  public void save(UiTheme selectedTheme, UiLanguage selectedLanguage) {
    Path temporary = null;
    try {
      Files.createDirectories(file.getParent());
      temporary = Files.createTempFile(file.getParent(), "ui-", ".tmp");
      Properties values = new Properties();
      values.setProperty("theme", selectedTheme.name());
      values.setProperty("language", selectedLanguage.name());
      try (var writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
        values.store(writer, "Moda Urbana 360 - UI preferences");
      }
      Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
      theme = selectedTheme;
      language = selectedLanguage;
    } catch (IOException error) {
      throw new IllegalStateException("No se pudieron guardar las preferencias.", error);
    } finally {
      if (temporary != null)
        try {
          Files.deleteIfExists(temporary);
        } catch (IOException ignored) {
        }
    }
  }
}
