package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.UnidMedida;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para unid_medida. No abre conexiones dentro de una transacción. */
public class UnidMedidaRepository extends AbstractJdbcRepository<UnidMedida> {
  public UnidMedidaRepository(SqlRepository db) {
    super(db, "unid_medida", "id_unidad");
  }

  @Override
  public UnidMedida fromRow(Map<String, Object> row) {
    UnidMedida entity = new UnidMedida();
    if (row.containsKey("id_unidad")) entity.setIdUnidad(SqlHelper.longValue(row.get("id_unidad")));
    if (row.containsKey("nombre_medida"))
      entity.setNombreMedida(SqlHelper.textValue(row.get("nombre_medida")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(UnidMedida entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_unidad", entity.getIdUnidad());
    row.put("nombre_medida", entity.getNombreMedida());
    return row;
  }
}
