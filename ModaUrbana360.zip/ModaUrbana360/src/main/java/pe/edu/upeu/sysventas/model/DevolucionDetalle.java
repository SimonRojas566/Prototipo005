package pe.edu.upeu.sysventas.model;

import java.time.*;

/**
 * Entidad de la tabla devolucion_detalle. Las relaciones se identifican mediante sus claves
 * foráneas.
 */
public class DevolucionDetalle {
  private Long idDevDetalle = null;
  private Long idDevolucion = null;
  private Long idVentaDetalle = null;
  private Long idVarianteDevuelta = null;
  private Integer cantidad = 0;
  private Long idVarianteCambio = null;

  public DevolucionDetalle() {}

  public Long getIdDevDetalle() {
    return idDevDetalle;
  }

  public void setIdDevDetalle(Long idDevDetalle) {
    this.idDevDetalle = idDevDetalle;
  }

  public Long getIdDevolucion() {
    return idDevolucion;
  }

  public void setIdDevolucion(Long idDevolucion) {
    this.idDevolucion = idDevolucion;
  }

  public Long getIdVentaDetalle() {
    return idVentaDetalle;
  }

  public void setIdVentaDetalle(Long idVentaDetalle) {
    this.idVentaDetalle = idVentaDetalle;
  }

  public Long getIdVarianteDevuelta() {
    return idVarianteDevuelta;
  }

  public void setIdVarianteDevuelta(Long idVarianteDevuelta) {
    this.idVarianteDevuelta = idVarianteDevuelta;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public void setCantidad(Integer cantidad) {
    this.cantidad = cantidad;
  }

  public Long getIdVarianteCambio() {
    return idVarianteCambio;
  }

  public void setIdVarianteCambio(Long idVarianteCambio) {
    this.idVarianteCambio = idVarianteCambio;
  }
}
