package pe.edu.upeu.sysventas.dto;

import java.math.BigDecimal;
import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class Detail {
  private final long variant;
  private final String sku;
  private final String name;
  private final int quantity;
  private final BigDecimal price;
  private final BigDecimal discount;
  private final BigDecimal subtotal;
  private final Long promotion;

  public Detail(
      long variant,
      String sku,
      String name,
      int quantity,
      BigDecimal price,
      BigDecimal discount,
      BigDecimal subtotal,
      Long promotion) {
    this.variant = variant;
    this.sku = sku;
    this.name = name;
    this.quantity = quantity;
    this.price = price;
    this.discount = discount;
    this.subtotal = subtotal;
    this.promotion = promotion;
  }

  public long getVariant() {
    return variant;
  }

  public String getSku() {
    return sku;
  }

  public String getName() {
    return name;
  }

  public int getQuantity() {
    return quantity;
  }

  public BigDecimal getPrice() {
    return price;
  }

  public BigDecimal getDiscount() {
    return discount;
  }

  public BigDecimal getSubtotal() {
    return subtotal;
  }

  public Long getPromotion() {
    return promotion;
  }
}
