package pe.edu.upeu.sysventas.dto;

import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class Field {
  private final String name;
  private final String type;
  private final boolean required;

  public Field(String name, String type, boolean required) {
    this.name = name;
    this.type = type;
    this.required = required;
  }

  public String getName() {
    return name;
  }

  public String getType() {
    return type;
  }

  public boolean getRequired() {
    return required;
  }
}
