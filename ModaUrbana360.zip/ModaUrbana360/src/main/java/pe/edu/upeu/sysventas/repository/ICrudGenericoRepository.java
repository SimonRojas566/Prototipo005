package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;

/** Contrato sin borrado físico: las operaciones comerciales conservan su historial. */
public interface ICrudGenericoRepository<T> {
  List<T> findAll(Connection connection) throws SQLException;

  T findById(Connection connection, long id) throws SQLException;

  T findByIdForUpdate(Connection connection, long id) throws SQLException;

  long insert(Connection connection, T entity) throws SQLException;

  void update(Connection connection, T entity) throws SQLException;
}
