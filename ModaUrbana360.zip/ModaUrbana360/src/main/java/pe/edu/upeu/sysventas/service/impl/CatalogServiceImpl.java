package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.ProductoCatalogoDto;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.repository.SqlRepository;
import pe.edu.upeu.sysventas.service.*;

public class CatalogServiceImpl implements CatalogService {
  private final SqlRepository db;
  private final AuthService auth;

  public CatalogServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
  }

  public List<ProductoCatalogoDto> search(
      String text,
      Long brand,
      Long category,
      String size,
      String color,
      BigDecimal min,
      BigDecimal max,
      boolean available) {
    if (min != null && min.signum() < 0
        || max != null && max.signum() < 0
        || min != null && max != null && min.compareTo(max) > 0)
      throw new IllegalArgumentException("Revisa el rango de precios.");
    return db.read(
        c -> {
          auth.require(c, "ADM", "VEN", "ALM", "CLI");
          return new CatalogoRepository(db)
              .search(c, text, brand, category, size, color, min, max, available);
        });
  }

  public List<Map<String, Object>> choices(String table) {
    Map<String, String> columns =
        Map.ofEntries(
            Map.entry("marca", "id_marca,nombre"),
            Map.entry("categoria", "id_categoria,nombre"),
            Map.entry("metodo_pago", "id_metodo_pago,nombre"),
            Map.entry("proveedor", "id_proveedor,razon_social AS nombre"),
            Map.entry("cliente", "id_cliente,nombres AS nombre"),
            Map.entry("variante", "id_variante,sku AS nombre"));
    String cols = columns.get(table);
    if (cols == null) throw new IllegalArgumentException("Catálogo no permitido.");
    return db.read(
        c -> {
          auth.require(c, "ADM", "VEN", "ALM", "CLI");
          if (table.equals("proveedor")) auth.require(c, "ADM", "ALM");
          if (table.equals("cliente")) auth.require(c, "ADM", "VEN");
          return db.query(c, "SELECT " + cols + " FROM " + table + " ORDER BY 2");
        });
  }
}
