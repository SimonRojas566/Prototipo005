package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Cliente;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para cliente. No abre conexiones dentro de una transacción. */
public class ClienteRepository extends AbstractJdbcRepository<Cliente> {
  public ClienteRepository(SqlRepository db) {
    super(db, "cliente", "id_cliente");
  }

  @Override
  public Cliente fromRow(Map<String, Object> row) {
    Cliente entity = new Cliente();
    if (row.containsKey("id_cliente"))
      entity.setIdCliente(SqlHelper.longValue(row.get("id_cliente")));
    if (row.containsKey("id_usuario"))
      entity.setIdUsuario(SqlHelper.longValue(row.get("id_usuario")));
    if (row.containsKey("documento"))
      entity.setDocumento(SqlHelper.textValue(row.get("documento")));
    if (row.containsKey("nombres")) entity.setNombres(SqlHelper.textValue(row.get("nombres")));
    if (row.containsKey("celular")) entity.setCelular(SqlHelper.textValue(row.get("celular")));
    if (row.containsKey("correo")) entity.setCorreo(SqlHelper.textValue(row.get("correo")));
    if (row.containsKey("id_nivel")) entity.setIdNivel(SqlHelper.longValue(row.get("id_nivel")));
    if (row.containsKey("puntos_acumulados"))
      entity.setPuntosAcumulados(SqlHelper.integerValue(row.get("puntos_acumulados")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Cliente entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_cliente", entity.getIdCliente());
    row.put("id_usuario", entity.getIdUsuario());
    row.put("documento", entity.getDocumento());
    row.put("nombres", entity.getNombres());
    row.put("celular", entity.getCelular());
    row.put("correo", entity.getCorreo());
    row.put("id_nivel", entity.getIdNivel());
    row.put("puntos_acumulados", entity.getPuntosAcumulados());
    return row;
  }

  public Cliente findByUsuario(Connection c, long user) throws SQLException {
    return fromRow(db.one(c, "SELECT * FROM cliente WHERE id_usuario=?", user));
  }
}
