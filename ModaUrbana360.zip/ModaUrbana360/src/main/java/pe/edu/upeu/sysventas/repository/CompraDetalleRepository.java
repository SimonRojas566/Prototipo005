package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.CompraDetalle;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para compra_detalle. No abre conexiones dentro de una transacción. */
public class CompraDetalleRepository extends AbstractJdbcRepository<CompraDetalle> {
  public CompraDetalleRepository(SqlRepository db) {
    super(db, "compra_detalle", "id_compra_detalle");
  }

  @Override
  public CompraDetalle fromRow(Map<String, Object> row) {
    CompraDetalle entity = new CompraDetalle();
    if (row.containsKey("id_compra_detalle"))
      entity.setIdCompraDetalle(SqlHelper.longValue(row.get("id_compra_detalle")));
    if (row.containsKey("id_compra")) entity.setIdCompra(SqlHelper.longValue(row.get("id_compra")));
    if (row.containsKey("id_variante"))
      entity.setIdVariante(SqlHelper.longValue(row.get("id_variante")));
    if (row.containsKey("pu")) entity.setPu(SqlHelper.decimalValue(row.get("pu")));
    if (row.containsKey("cantidad"))
      entity.setCantidad(SqlHelper.integerValue(row.get("cantidad")));
    if (row.containsKey("subtotal"))
      entity.setSubtotal(SqlHelper.decimalValue(row.get("subtotal")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(CompraDetalle entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_compra_detalle", entity.getIdCompraDetalle());
    row.put("id_compra", entity.getIdCompra());
    row.put("id_variante", entity.getIdVariante());
    row.put("pu", entity.getPu());
    row.put("cantidad", entity.getCantidad());
    row.put("subtotal", entity.getSubtotal());
    return row;
  }
}
