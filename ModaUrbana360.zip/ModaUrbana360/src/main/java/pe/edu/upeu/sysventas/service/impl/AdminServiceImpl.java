package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.repository.SqlRepository;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.Passwords;

public class AdminServiceImpl implements AdminService {

  private final SqlRepository db;
  private final AuthService auth;

  public AdminServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
  }

  private void allowed(Connection c, String table) throws SQLException {
    if (!TABLES.contains(table)) throw new SecurityException("Entidad no editable.");
    if (table.equals("cliente")) auth.require(c, "ADM", "VEN");
    else if (table.equals("proveedor")) auth.require(c, "ADM", "ALM");
    else auth.require(c, "ADM");
  }

  public List<Field> fields(String table) {
    return db.read(
        c -> {
          allowed(c, table);
          return schema(c, table);
        });
  }

  private List<Field> schema(Connection c, String table) throws SQLException {
    List<Field> fields = new ArrayList<>();
    for (var row :
        db.query(
            c,
            "SELECT column_name,data_type,is_nullable FROM information_schema.columns WHERE"
                + " table_schema=current_schema() AND table_name=? ORDER BY ordinal_position",
            table)) {
      String n = row.get("column_name").toString();
      if (n.equals(PK.get(table))
          || n.equals("hash_clave")
          || n.equals("stock_actual")
          || n.equals("url_imagen")) continue;
      fields.add(
          new Field(n, row.get("data_type").toString(), row.get("is_nullable").equals("NO")));
    }
    if (table.equals("usuario")) fields.add(new Field("password", "password", false));
    return fields;
  }

  public List<Map<String, Object>> list(String table) {
    return db.read(
        c -> {
          allowed(c, table);
          String cols =
              table.equals("usuario") ? "id_usuario,nombre_usuario,estado,id_perfil" : "*";
          String query =
              switch (table) {
                case "producto" ->
                    "SELECT p.id_producto,p.codigo,p.nombre,m.nombre AS marca,ca.nombre AS"
                        + " categoria,p.estado,p.descripcion,p.url_imagen,p.id_marca,p.id_categoria,p.id_unidad,p.id_genero,p.id_temporada"
                        + " FROM producto p JOIN marca m ON m.id_marca=p.id_marca JOIN categoria ca"
                        + " ON ca.id_categoria=p.id_categoria ORDER BY p.id_producto";
                case "variante" ->
                    "SELECT v.id_variante,v.sku,p.nombre AS"
                        + " producto,v.talla,v.color,v.precio_venta,v.stock_actual,v.stock_minimo,v.costo,v.id_producto"
                        + " FROM variante v JOIN producto p ON p.id_producto=v.id_producto ORDER BY"
                        + " v.id_variante";
                case "usuario" ->
                    "SELECT u.id_usuario,u.nombre_usuario,p.nombre AS perfil,u.estado,u.id_perfil"
                        + " FROM usuario u JOIN perfil p ON p.id_perfil=u.id_perfil WHERE"
                        + " u.nombre_usuario<>'__invitado_sistema' ORDER BY u.id_usuario";
                case "cliente" ->
                    "SELECT cl.id_cliente,cl.documento,cl.nombres,u.nombre_usuario AS"
                        + " usuario,n.nombre AS"
                        + " nivel,cl.celular,cl.correo,cl.puntos_acumulados,cl.id_usuario,cl.id_nivel"
                        + " FROM cliente cl JOIN usuario u ON u.id_usuario=cl.id_usuario JOIN"
                        + " nivel_cliente n ON n.id_nivel=cl.id_nivel ORDER BY cl.id_cliente";
                default -> "SELECT " + cols + " FROM " + table + " ORDER BY " + PK.get(table);
              };
          return db.query(c, query);
        });
  }

  public List<Choice> lookup(String field) {
    Map<String, String> targets =
        Map.ofEntries(
            Map.entry("id_marca", "marca"),
            Map.entry("id_categoria", "categoria"),
            Map.entry("id_unidad", "unid_medida"),
            Map.entry("id_genero", "genero"),
            Map.entry("id_temporada", "temporada"),
            Map.entry("id_nivel", "nivel_cliente"),
            Map.entry("id_usuario", "usuario"),
            Map.entry("id_perfil", "perfil"),
            Map.entry("id_producto", "producto"));
    String table = targets.get(field);
    if (table == null) return List.of();
    String label =
        table.equals("unid_medida")
            ? "nombre_medida"
            : table.equals("usuario") ? "nombre_usuario" : "nombre";
    return db.read(
        c -> {
          auth.require(c, "ADM", "VEN", "ALM");
          List<Choice> out = new ArrayList<>();
          String condition =
              table.equals("usuario")
                  ? " WHERE id_perfil=(SELECT id_perfil FROM perfil WHERE codigo='CLI') AND"
                      + " nombre_usuario<>'__invitado_sistema'"
                  : field.equals("id_perfil")
                      ? " WHERE codigo IN ('ADM','VEN','ALM')"
                  : "";
          for (var r :
              db.query(
                  c,
                  "SELECT "
                      + field
                      + ", "
                      + label
                      + " AS label FROM "
                      + table
                      + condition
                      + " ORDER BY 2"))
            out.add(new Choice(((Number) r.get(field)).longValue(), r.get("label").toString()));
          return out;
        });
  }

  public long save(String table, Long id, Map<String, String> input) {
    return db.transaction(
        c -> {
          allowed(c, table);
          if (table.equals("usuario")) {
            if (input.getOrDefault("nombre_usuario", "").startsWith("__"))
              throw new IllegalArgumentException("Ese nombre está reservado para el sistema.");
            if (id != null
                && new UsuarioRepository(db).findById(c, id).getNombreUsuario().startsWith("__"))
              throw new SecurityException(
                  "La cuenta técnica de invitados no se modifica desde este formulario.");
          }

          long user = SessionManager.getInstance().getUserId();
          List<Field> fields = schema(c, table);
          List<String> names = new ArrayList<>();
          List<Object> values = new ArrayList<>();
          for (Field f : fields) {
            String value = input.getOrDefault(f.getName(), "").trim();
            if (f.getName().equals("password")) {
              if (value.isBlank() && id != null) continue;
              names.add("hash_clave");
              values.add(Passwords.hash(value));
              continue;
            }
            if (value.isBlank() && f.getRequired())
              throw new IllegalArgumentException("Completa el campo " + f.getName() + ".");
            Object parsed = null;
            if (!value.isBlank())
              try {
                parsed =
                    switch (f.getType()) {
                      case "bigint" -> Long.parseLong(value);
                      case "integer" -> Integer.parseInt(value);
                      case "numeric" -> {
                        BigDecimal d = new BigDecimal(value.replace(',', '.'));
                        if (d.scale() > 2) throw new NumberFormatException();
                        yield d;
                      }
                      case "date" -> LocalDate.parse(value);
                      default -> value;
                    };
              } catch (Exception ex) {
                throw new IllegalArgumentException(
                    "Revisa el formato de "
                        + f.getName()
                        + ". Fechas: AAAA-MM-DD. Importes: hasta dos decimales.");
              }
            names.add(f.getName());
            values.add(parsed);
          }
          if (table.equals("usuario") && id != null && id == user) {
            var current = db.one(c, "SELECT id_perfil FROM usuario WHERE id_usuario=?", id);
            if (!"Activo".equals(input.get("estado"))
                || !current.get("id_perfil").toString().equals(input.get("id_perfil")))
              throw new IllegalArgumentException(
                  "No puedes desactivar tu propia cuenta ni cambiar tu perfil durante la sesión.");
          }
          if (table.equals("cliente")) {
            long uid = Long.parseLong(input.get("id_usuario"));
            var role =
                db.one(
                    c,
                    "SELECT p.codigo FROM usuario u JOIN perfil p ON p.id_perfil=u.id_perfil WHERE"
                        + " id_usuario=?",
                    uid);
            if (!role.get("codigo").equals("CLI"))
              throw new IllegalArgumentException(
                  "La cuenta del cliente debe tener perfil Cliente.");
          }
          if (table.equals("usuario") && id != null) {
            boolean linked =
                !db.query(c, "SELECT id_cliente FROM cliente WHERE id_usuario=?", id).isEmpty();
            if (linked
                && !"CLI"
                    .equals(
                        db.one(
                                c,
                                "SELECT codigo FROM perfil WHERE id_perfil=?",
                                Long.parseLong(input.get("id_perfil")))
                            .get("codigo")))
              throw new IllegalArgumentException(
                  "Una cuenta asociada a cliente debe conservar su perfil Cliente.");
          }
          long result = new RepositoryRegistry(db).get(table).saveForm(c, id, names, values);
          db.audit(
              c,
              user,
              id == null ? "CREAR" : "EDITAR",
              table,
              result,
              "Campos actualizados: "
                  + String.join(",", names.stream().filter(n -> !n.equals("hash_clave")).toList()));
          return result;
        });
  }

  public void deactivate(String table, long id) {
    if (!Set.of("producto", "usuario", "promocion").contains(table))
      throw new IllegalArgumentException("Este catálogo se conserva para mantener su historial.");
    var current =
        list(table).stream()
            .filter(r -> ((Number) r.get(PK.get(table))).longValue() == id)
            .findFirst()
            .orElseThrow();
    Map<String, String> values = new HashMap<>();
    current.forEach((k, v) -> values.put(k, v == null ? "" : v.toString()));
    values.put("estado", "Inactivo");
    save(table, id, values);
  }
}
