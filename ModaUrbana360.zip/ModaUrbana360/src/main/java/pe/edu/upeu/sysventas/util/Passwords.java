package pe.edu.upeu.sysventas.util;

import java.security.*;
import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class Passwords {
  private Passwords() {}

  public static String hash(String password) {
    if (password == null || password.length() < 10)
      throw new IllegalArgumentException("Usa una contraseña de al menos 10 caracteres.");
    byte[] salt = new byte[16];
    new SecureRandom().nextBytes(salt);
    return encode(password, salt, 210000);
  }

  private static String encode(String pass, byte[] salt, int rounds) {
    PBEKeySpec spec = new PBEKeySpec(pass.toCharArray(), salt, rounds, 256);
    try {
      byte[] key =
          SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
      return "pbkdf2$"
          + rounds
          + "$"
          + Base64.getEncoder().encodeToString(salt)
          + "$"
          + Base64.getEncoder().encodeToString(key);
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException(e);
    } finally {
      spec.clearPassword();
    }
  }

  public static boolean verify(String password, String encoded) {
    try {
      String[] parts = encoded.split("\\$");
      if (parts.length != 4 || !parts[0].equals("pbkdf2")) return false;
      int rounds = Integer.parseInt(parts[1]);
      if (rounds < 100000 || rounds > 1000000) return false;
      return MessageDigest.isEqual(
          encoded.getBytes(java.nio.charset.StandardCharsets.UTF_8),
          encode(password, Base64.getDecoder().decode(parts[2]), rounds)
              .getBytes(java.nio.charset.StandardCharsets.UTF_8));
    } catch (Exception e) {
      return false;
    }
  }
}
