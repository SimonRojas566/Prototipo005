package pe.edu.upeu.sysventas.dto.comprobante;

import java.math.BigDecimal;
import java.util.*;

/** Proyección tipada utilizada para consultar y presentar un comprobante. */
public final class ItemComprobante {
  private final String sku;
  private final String nombre;
  private final Integer cantidad;
  private final BigDecimal precioUnitario;
  private final BigDecimal descuento;
  private final BigDecimal subtotal;

  public ItemComprobante(
      String sku,
      String nombre,
      Integer cantidad,
      BigDecimal precioUnitario,
      BigDecimal descuento,
      BigDecimal subtotal) {
    this.sku = sku;
    this.nombre = nombre;
    this.cantidad = cantidad;
    this.precioUnitario = precioUnitario;
    this.descuento = descuento;
    this.subtotal = subtotal;
  }

  public String getSku() {
    return sku;
  }

  public String getNombre() {
    return nombre;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public BigDecimal getPrecioUnitario() {
    return precioUnitario;
  }

  public BigDecimal getDescuento() {
    return descuento;
  }

  public BigDecimal getSubtotal() {
    return subtotal;
  }
}
