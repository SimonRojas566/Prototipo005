package pe.edu.upeu.sysventas.controller;

import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import pe.edu.upeu.sysventas.SysVentas;
import pe.edu.upeu.sysventas.dto.SessionManager;
import pe.edu.upeu.sysventas.util.Ui;

public class MainguiController {
  @FXML private MenuBar navigation;
  @FXML private StackPane content;
  @FXML private Label person, role, section;

  @FXML
  public void initialize() {
    var s = SessionManager.getInstance();
    person.setText(s.getUserName());
    role.setText(s.getUserPerfil());
    String r = s.getRole();
    nav("Principal", "dashboard", "Tu tienda, de un vistazo");
    nav("Productos", "catalogo", "Colección urbana");
    if (!r.equals("ALM"))
      nav(
          "Venta",
          "venta",
          (r.equals("CLI") || s.isGuest()) ? "Tu próxima compra" : "Registrar venta");
    if (r.equals("ADM") || r.equals("ALM")) nav("Compras", "compra", "Recepción de mercadería");
    if (r.equals("ADM") || r.equals("VEN") || r.equals("ALM"))
      nav("Administración", "admin", "Gestión de registros");
    nav(
        "Consultas",
        "reportes",
        (r.equals("CLI") || s.isGuest()) ? "Mis compras" : "Consultas y reportes");
    pe.edu.upeu.sysventas.components.AppearanceMenu.addTo(navigation);
    open("dashboard", "Tu tienda, de un vistazo");
  }

  private void nav(String label, String fxml, String title) {
    Menu menu = new Menu(label);
    MenuItem item = new MenuItem(title);
    item.setOnAction(event -> open(fxml, title));
    menu.getItems().add(item);
    navigation.getMenus().add(menu);
  }

  public void open(String fxml, String title) {
    Ui.run(
        () -> {
          try {
            Parent p = FXMLLoader.load(getClass().getResource("/fxml/" + fxml + ".fxml"));
            if (p instanceof javafx.scene.layout.Region r) r.setMinHeight(690);
            ScrollPane scroll = new ScrollPane(p);
            scroll.setFitToWidth(true);
            scroll.setFitToHeight(true);
            pe.edu.upeu.sysventas.util.I18n.apply(p);
            content.getChildren().setAll(scroll);
            section.setText(title);
          } catch (java.io.IOException e) {
            throw new IllegalStateException("No se pudo abrir la sección " + title, e);
          }
        });
  }

  @FXML
  public void logout() {
    if (!CartState.lines.isEmpty()
        && !Ui.confirm("El carrito de esta sesión se vaciará. ¿Cerrar sesión?")) return;
    CartState.clear();
    SysVentas.login();
  }
}
