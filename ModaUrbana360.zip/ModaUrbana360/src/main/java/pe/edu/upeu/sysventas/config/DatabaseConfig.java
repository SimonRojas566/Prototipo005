package pe.edu.upeu.sysventas.config;

import com.zaxxer.hikari.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.Properties;
import org.h2.tools.RunScript;

/** H2 embebido, como la referencia docente. Crea las tablas y semillas solo en una base vacía. */
public final class DatabaseConfig {
  private static HikariDataSource pool;
  private static final Properties props = loadProperties();

  private DatabaseConfig() {}

  public static Path home() {
    return Path.of(System.getProperty("moda.home", ".")).toAbsolutePath().normalize();
  }

  private static Properties loadProperties() {
    Properties values = new Properties();
    Path file =
        Path.of(
            System.getProperty(
                "moda.config", home().resolve("config/database.properties").toString()));
    if (Files.exists(file))
      try (var reader = Files.newBufferedReader(file)) {
        values.load(reader);
      } catch (IOException ex) {
        throw new IllegalStateException("No se puede leer la configuración H2.", ex);
      }
    return values;
  }

  public static String setting(String key, String fallback) {
    return props.getProperty(key, fallback);
  }

  public static synchronized Connection getConnection() throws SQLException {
    if (pool == null) {
      String base = home().resolve("data/moda_urbana").toString().replace('\\', '/');
      String url =
          System.getProperty(
              "moda.db.url",
              "jdbc:h2:file:"
                  + base
                  + ";MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH;LOCK_TIMEOUT=15000");
      if (!url.startsWith("jdbc:h2:"))
        throw new IllegalArgumentException("Esta edición utiliza H2 embebido.");
      try {
        Files.createDirectories(home().resolve("data"));
      } catch (IOException ex) {
        throw new SQLException("La carpeta del proyecto no permite guardar datos.", ex);
      }
      HikariConfig cfg = new HikariConfig();
      cfg.setJdbcUrl(url);
      cfg.setUsername(setting("db.username", "sa"));
      cfg.setPassword(setting("db.password", ""));
      cfg.setDriverClassName("org.h2.Driver");
      cfg.setMaximumPoolSize(5);
      cfg.setConnectionTimeout(15000);
      cfg.setPoolName("ModaUrbana-H2");
      HikariDataSource candidate = new HikariDataSource(cfg);
      try (Connection connection = candidate.getConnection()) {
        initialize(connection);
      } catch (Exception ex) {
        candidate.close();
        throw new SQLException(
            "No se pudo preparar la base H2. Conserva la carpeta data y revisa el error.", ex);
      }
      pool = candidate;
    }
    return pool.getConnection();
  }

  private static void initialize(Connection c) throws SQLException, IOException {
    int tables;
    try (Statement st = c.createStatement();
        ResultSet rs =
            st.executeQuery(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'")) {
      rs.next();
      tables = rs.getInt(1);
    }
    if (tables == 0) {
      script(c, "h2_schema.sql");
      script(c, "h2_demo.sql");
    } else if (tables != 24) {
      throw new SQLException(
          "La base H2 está incompleta: se esperaban 24 tablas. No se reiniciaron tus datos.");
    }
  }

  private static void script(Connection c, String name) throws SQLException, IOException {
    try (InputStream in = DatabaseConfig.class.getResourceAsStream("/db/" + name)) {
      if (in == null) throw new IOException("Falta el recurso " + name);
      RunScript.execute(c, new InputStreamReader(in, StandardCharsets.UTF_8));
    }
  }

  public static synchronized void shutdown() {
    if (pool != null) {
      pool.close();
      pool = null;
    }
  }
}
