package pe.edu.upeu.sysventas.dto;

import java.math.BigDecimal;
import java.util.*;

/** Datos de transferencia entre la vista y los servicios; no representa una tabla. */
public final class PurchaseLine {
  private final long variante;
  private final int cantidad;
  private final BigDecimal costo;

  public PurchaseLine(long variante, int cantidad, BigDecimal costo) {
    if (variante < 1 || cantidad < 1 || costo == null || costo.signum() < 0 || costo.scale() > 2)
      throw new IllegalArgumentException(
          "Revisa variante, cantidad y costo (máximo dos decimales).");
    this.variante = variante;
    this.cantidad = cantidad;
    this.costo = costo;
  }

  public long getVariante() {
    return variante;
  }

  public int getCantidad() {
    return cantidad;
  }

  public BigDecimal getCosto() {
    return costo;
  }
}
