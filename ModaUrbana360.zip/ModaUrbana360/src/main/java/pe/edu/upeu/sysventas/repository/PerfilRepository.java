package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.Perfil;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para perfil. No abre conexiones dentro de una transacción. */
public class PerfilRepository extends AbstractJdbcRepository<Perfil> {
  public PerfilRepository(SqlRepository db) {
    super(db, "perfil", "id_perfil");
  }

  @Override
  public Perfil fromRow(Map<String, Object> row) {
    Perfil entity = new Perfil();
    if (row.containsKey("id_perfil")) entity.setIdPerfil(SqlHelper.longValue(row.get("id_perfil")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    if (row.containsKey("codigo")) entity.setCodigo(SqlHelper.textValue(row.get("codigo")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(Perfil entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_perfil", entity.getIdPerfil());
    row.put("nombre", entity.getNombre());
    row.put("codigo", entity.getCodigo());
    return row;
  }
}
