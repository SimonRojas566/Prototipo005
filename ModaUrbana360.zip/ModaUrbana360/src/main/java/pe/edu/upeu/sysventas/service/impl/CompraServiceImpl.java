package pe.edu.upeu.sysventas.service.impl;

import java.math.*;
import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.dto.*;
import pe.edu.upeu.sysventas.enums.*;
import pe.edu.upeu.sysventas.model.*;
import pe.edu.upeu.sysventas.repository.*;
import pe.edu.upeu.sysventas.service.*;
import pe.edu.upeu.sysventas.util.Money;

/** Reglas y transacciones de compra. */
public class CompraServiceImpl implements CompraService {
  private final SqlRepository db;
  private final AuthService auth;
  private final MovimientoStockRepository movimientos;

  public CompraServiceImpl(SqlRepository db, AuthService auth) {
    this.db = db;
    this.auth = auth;
    this.movimientos = new MovimientoStockRepository(db);
  }

  public long buy(
      long supplier,
      String serie,
      String document,
      java.time.LocalDate date,
      List<PurchaseLine> lines) {
    if (serie == null
        || serie.isBlank()
        || document == null
        || document.isBlank()
        || date == null
        || date.isAfter(java.time.LocalDate.now())
        || lines == null
        || lines.isEmpty())
      throw new IllegalArgumentException(
          "Completa proveedor, documento, fecha válida y productos.");
    return db.transaction(
        c -> {
          long user = auth.require(c, "ADM", "ALM");
          db.one(c, "SELECT id_proveedor FROM proveedor WHERE id_proveedor=?", supplier);
          Set<Long> seen = new HashSet<>();
          BigDecimal total = Money.ZERO;
          for (PurchaseLine l : lines) {
            if (!seen.add(l.getVariante()))
              throw new IllegalArgumentException(
                  "Agrupa la cantidad de cada SKU en una sola línea.");
            total = total.add(l.getCosto().multiply(BigDecimal.valueOf(l.getCantidad())));
          }
          BigDecimal base = Money.base(total);
          Compra compra = new Compra();
          compra.setSerie(serie.trim());
          compra.setNumDoc(document.trim());
          compra.setTipoDoc("Factura");
          compra.setFechaComp(date);
          compra.setFechaReg(java.time.LocalDate.now());
          compra.setPrecioBase(base);
          compra.setIgv(total.subtract(base));
          compra.setPrecioTotal(total);
          compra.setIdProveedor(supplier);
          compra.setIdUsuario(user);
          long id = new CompraRepository(db).insert(c, compra);
          for (PurchaseLine l :
              lines.stream().sorted(Comparator.comparingLong(PurchaseLine::getVariante)).toList()) {
            db.one(
                c,
                "SELECT id_variante FROM variante WHERE id_variante=? FOR UPDATE",
                l.getVariante());
            CompraDetalle detalle = new CompraDetalle();
            detalle.setIdCompra(id);
            detalle.setIdVariante(l.getVariante());
            detalle.setPu(l.getCosto());
            detalle.setCantidad(l.getCantidad());
            detalle.setSubtotal(l.getCosto().multiply(BigDecimal.valueOf(l.getCantidad())));
            new CompraDetalleRepository(db).insert(c, detalle);
            db.update(
                c,
                "UPDATE variante SET stock_actual=stock_actual+?,costo=? WHERE id_variante=?",
                l.getCantidad(),
                l.getCosto(),
                l.getVariante());
            movimientos.registrar(
                c, l.getVariante(), "ENTRADA_COMPRA", l.getCantidad(), "COMPRA:" + id, user);
          }
          db.audit(c, user, "CONFIRMAR", "compra", id, "Total " + total);
          return id;
        });
  }
}
