package pe.edu.upeu.sysventas.model;

import java.time.*;

/** Entidad de la tabla devolucion. Las relaciones se identifican mediante sus claves foráneas. */
public class Devolucion {
  private Long idDevolucion = null;
  private Long idVenta = null;
  private LocalDateTime fecha = LocalDateTime.now();
  private String motivo = null;
  private String tipo = null;
  private Long idUsuario = null;
  private String estado = "Confirmada";

  public Devolucion() {}

  public Long getIdDevolucion() {
    return idDevolucion;
  }

  public void setIdDevolucion(Long idDevolucion) {
    this.idDevolucion = idDevolucion;
  }

  public Long getIdVenta() {
    return idVenta;
  }

  public void setIdVenta(Long idVenta) {
    this.idVenta = idVenta;
  }

  public LocalDateTime getFecha() {
    return fecha;
  }

  public void setFecha(LocalDateTime fecha) {
    this.fecha = fecha;
  }

  public String getMotivo() {
    return motivo;
  }

  public void setMotivo(String motivo) {
    this.motivo = motivo;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public Long getIdUsuario() {
    return idUsuario;
  }

  public void setIdUsuario(Long idUsuario) {
    this.idUsuario = idUsuario;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }
}
