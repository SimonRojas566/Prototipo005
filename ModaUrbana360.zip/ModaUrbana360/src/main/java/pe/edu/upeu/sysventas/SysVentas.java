package pe.edu.upeu.sysventas;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;
import pe.edu.upeu.sysventas.config.*;
import pe.edu.upeu.sysventas.controller.MainguiController;

public class SysVentas extends Application {
  private static Stage stage;
  private static MainguiController shell;

  @Override
  public void start(Stage primary) throws Exception {
    stage = primary;
    stage.setTitle("Moda Urbana 360");
    stage.setMinWidth(1080);
    stage.setMinHeight(720);
    login();
    stage.show();
  }

  public static void login() {
    AppContext.getInstance().auth.logout();
    shell = null;
    scene("login", 1220, 800);
  }

  public static void home() {
    scene("maingui", 1360, 900);
  }

  private static void scene(String name, int width, int height) {
    try {
      FXMLLoader loader = new FXMLLoader(SysVentas.class.getResource("/fxml/" + name + ".fxml"));
      Parent root = loader.load();
      Scene s = new Scene(root, width, height);
      pe.edu.upeu.sysventas.util.UiSettings.apply(s);
      stage.setScene(s);
      stage.centerOnScreen();
      if (name.equals("maingui")) shell = loader.getController();
    } catch (Exception e) {
      throw new IllegalStateException("No se pudo cargar la pantalla " + name, e);
    }
  }

  public static void page(String name, String title) {
    if (shell != null) shell.open(name, title);
  }

  public static Stage stage() {
    return stage;
  }

  @Override
  public void stop() {
    AppContext.getInstance().auth.logout();
    DatabaseConfig.shutdown();
  }
}
