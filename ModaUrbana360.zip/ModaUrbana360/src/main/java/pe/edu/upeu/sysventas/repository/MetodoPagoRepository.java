package pe.edu.upeu.sysventas.repository;

import java.sql.*;
import java.util.*;
import pe.edu.upeu.sysventas.model.MetodoPago;
import pe.edu.upeu.sysventas.repository.helper.SqlHelper;

/** Persistencia JDBC tipada para metodo_pago. No abre conexiones dentro de una transacción. */
public class MetodoPagoRepository extends AbstractJdbcRepository<MetodoPago> {
  public MetodoPagoRepository(SqlRepository db) {
    super(db, "metodo_pago", "id_metodo_pago");
  }

  @Override
  public MetodoPago fromRow(Map<String, Object> row) {
    MetodoPago entity = new MetodoPago();
    if (row.containsKey("id_metodo_pago"))
      entity.setIdMetodoPago(SqlHelper.longValue(row.get("id_metodo_pago")));
    if (row.containsKey("nombre")) entity.setNombre(SqlHelper.textValue(row.get("nombre")));
    return entity;
  }

  @Override
  public Map<String, Object> toRow(MetodoPago entity) {
    Map<String, Object> row = new LinkedHashMap<>();
    row.put("id_metodo_pago", entity.getIdMetodoPago());
    row.put("nombre", entity.getNombre());
    return row;
  }
}
